package com.Atlys;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;

import org.sikuli.script.Button;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass.Read_Prop;

public class SS_Atlys extends Read_Prop {


	public SS_Atlys() throws IOException
	{
		super();
		
	}
	
	
/*@BeforeTest
public void Atlys_Login() throws FindFailed, InterruptedException, IOException{
	String path = DataProviderClient.getPathFromExcel();
	Initialization(path);

}*/
@DataProvider
public Iterator<Object[]> getTestData() throws IOException
{
	ArrayList<Object[]> testData = DataDriven.getDataFromExcel();
	return testData.iterator();
	} 
	


@Test(dataProvider="getTestData")
public void Atlys_SS(String Linha, String TYPE) throws FindFailed, InterruptedException, IOException{
	
	
	Screen s = new Screen();
	//Pattern atlys = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\atlys.png");
		// s.wait(atlys.similar((float) 0.80), 10).click();
		Thread.sleep(2000);
		
		s.type(Linha);
		Pattern ref = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ssref.png");
		s.wait(ref.similar((float) 0.70), 60);
		Region reg1 = s.find(ref).grow(1, 50, 50, 1);
		//reg1.highlight(1);
		Pattern pesquisar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\pesquisar.png");
		reg1.wait(pesquisar.similar((float) 0.70), 60).click();
		Pattern ref1 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ssref1.png");
		s.wait(ref1.similar((float) 0.90), 30);
		Thread.sleep(2000);
		//TestUtil.TakeSS(Linha);
		//File imgScreen= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//FileUtils.copyFile(imgScreen, new File("C:\\Chandigarh_Automation\\Atlys_Evidence\\"+Linha.toString()+"\\1.png"));
		
		BufferedImage imgScreen = s.capture().getImage();
		//ImageIO.write(imgScreen,"png" , new File("C:\\Users\\Telefonica\\Documents\\Atlys_SS\\11999712966\\1.png"));
		File outputFile = new File("C:\\Chandigarh_Automation\\Atlys_Evidence\\"+Linha.toString()+"\\1.png");
		outputFile.getParentFile().mkdirs();
		ImageIO.write(imgScreen, "png", outputFile);
		 Pattern visualizar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\visualizar.png");
		 s.wait(visualizar.similar((float) 0.90), 30).click();
		 Pattern ref2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\refconta.png");
			s.wait(ref2.similar((float) 0.90), 180);
			
			 Region reg6 =s.find(ref2).grow(1, 950, 5, 600);
		        reg6.highlight(1);
		        if(TYPE.equalsIgnoreCase("POSTPAID"))
		        {
		        	
			Pattern funcoesconta = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\funcoesconta.png");
			 Pattern credito = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\credito.png");
			 s.hover(funcoesconta);
			s.mouseDown(Button.LEFT);
			 s.wait(credito.similar((float) 0.80), 100);
			 s.dropAt(credito);
			 s.type(Key.TAB);
			 s.type("PESSOA FISICA");
			 s.type(Key.TAB);
			 s.type(Key.ENTER);
			 Pattern ref20 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref20.png");
			 s.wait(ref20.similar((float) 0.80), 30);
			 s.type(Key.ENTER);
			 Pattern checkpoint = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\checkpoint.png");
			 reg6.wait(checkpoint.similar((float) 0.70), 90);
		        }
		        
			
			BufferedImage imgScreen1 = s.capture().getImage();
			File outputFile1 = new File("C:\\Chandigarh_Automation\\Atlys_Evidence\\"+Linha.toString()+"\\2.png");
			outputFile1.getParentFile().mkdirs();
			ImageIO.write(imgScreen1, "png", outputFile1);
			
			Thread.sleep(2000);
			Pattern Fechar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Fechar.png");
			Pattern funcoes = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\funcoesassinatura.png");
			s.wait(funcoes.similar((float) 0.70), 60).click();
			Thread.sleep(2000);
			s.type(Key.DOWN);
		     s.type(Key.ENTER);
			/*Pattern mundanca = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\mundanca.png");
			s.wait(mundanca.similar((float) 0.70), 5);
			if(s.exists(mundanca, 5)!=null){
				Thread.sleep(3000);
				s.wait(Fechar.similar((float) 0.80), 60).click();
				s.type(Key.ENTER);
				s.type(Key.DOWN);
				s.type(Key.ENTER);
			}*/
			Pattern ref3 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\configuracaoref.png");
			s.wait(ref3.similar((float) 0.90), 180);
			Thread.sleep(3000);
			BufferedImage imgScreen2 = s.capture().getImage();
			File outputFile2 = new File("C:\\Chandigarh_Automation\\Atlys_Evidence\\"+Linha.toString()+"\\3.png");
			outputFile2.getParentFile().mkdirs();
			ImageIO.write(imgScreen2, "png", outputFile2);
			
			s.type(Key.F4);
			
			
			s.wait(Fechar.similar((float) 0.80), 60).click();
			s.type(Key.F4);
			 Pattern maximize = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\maximize.png");
				s.wait(maximize.similar((float) 0.90), 20).click();
			
	
}
}
