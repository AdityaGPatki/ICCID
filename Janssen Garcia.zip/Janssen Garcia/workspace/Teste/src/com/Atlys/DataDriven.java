package com.Atlys;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataDriven {
	static int rowCount;
	public static ArrayList<Object[]> getDataFromExcel() throws IOException
    {           
          ArrayList<Object[]> myData= new ArrayList<Object[]>();
          
          File src =new  File("C:\\Users\\Janssen Garcia\\workspace\\Teste\\src\\com\\Atlys\\Screenshot_Linha.xlsx");
            
                FileInputStream fis = new FileInputStream(src);
          //  FileOutputStream fos= new FileOutputStream(src);
            
                
          XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            XSSFSheet sheet1= wb.getSheet("Global");
            
            DataFormatter formatter = new DataFormatter();
            
            rowCount = sheet1.getLastRowNum();
           System.out.println("Total rows are "+ rowCount);
            
           
          // FileOutputStream fos= new FileOutputStream(src);
           //wb.write(fos);
           
            for ( int i = 1 ;i<= rowCount ;i++)
            {
                 
                  String Linha= formatter.formatCellValue(sheet1.getRow(i).getCell(0));
                  String TYPE= formatter.formatCellValue(sheet1.getRow(i).getCell(1));
                  System.out.println(Linha+" "+ TYPE);
                //String Type = formatter.formatCellValue(sheet1.getRow(i).getCell(1));
                   //Object ob[]={Username,Password,Linha};
                   Object ob[]={Linha,TYPE};
                   myData.add(ob);
            
            }
            fis.close();
            return myData;
    }

	
	
		

}
