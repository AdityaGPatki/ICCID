package com.NginApp;

import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;


import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.DataDriven.DataProviderExcel;
import com.baseclass.ReadProp;

public class Ngin_Line_With_SS extends ReadProp {
	public static int i;
	
	public Ngin_Line_With_SS() throws IOException
	{
		super();
	
		}	

@BeforeTest
public void Ngin_Login() {
	
	Initialization();

}

@BeforeMethod
public void increment()
{
	i=i+1;
	}

@DataProvider
public Iterator<Object[]> getTestData() throws IOException
{
	ArrayList<Object[]> testData = DataProviderExcel.getClientFromExcel();
	return testData.iterator();
}

@Test(dataProvider="getTestData")
public void NGIN_Client(String DDD, String PREFIX, String ICCID,String IMEI, String REFRESHCOUNT) throws InterruptedException, FindFailed, IOException
   {
	driver.switchTo().defaultContent();
	driver.switchTo().frame("menu");
	driver.findElement(By.xpath("//span[contains(text(),'R�pido')]")).click();
	driver.findElement(By.xpath("//a[contains(text(),'Habilita��o Avulsa')]")).click();
	driver.switchTo().defaultContent();
	driver.switchTo().frame("body");
	driver.findElement(By.xpath("//input[@id='selectMsisdnFilter_ddd']")).sendKeys(DDD);
	driver.findElement(By.id("selectMsisdnFilter_prefix")).sendKeys(PREFIX);
	driver.findElement(By.xpath("//input[contains(@onclick,'selectMsisdnFilter_search()')]")).click();
	new Select(driver.findElement(By.id("selectMsisdnFilter_cellularList"))).selectByIndex(0);
	String Line =driver.findElement(By.xpath("//select[@id='selectMsisdnFilter_cellularList']//option[1]")).getText();
	System.out.println(Line);
	//SS
	File Select_Line = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	//Now you can do whatever you need to do with it, for example copy somewhere
	FileUtils.copyFile(Select_Line, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_1" + ".png"));	
	
	driver.findElement(By.id("bt_next")).click();
	new Select(driver.findElement(By.id("selectProfile"))).selectByIndex(1);
	new Select(driver.findElement(By.id("selectEquipmentFilter_selectTechnology"))).selectByIndex(2);
	new Select(driver.findElement(By.id("selectEquipmentFilter_selectBrand"))).selectByVisibleText("ERICSSON");
	driver.findElement(By.id("selectEquipmentFilter_btSearch")).click();
	new Select(driver.findElement(By.id("selectEquipmentFilter_modelList"))).selectByIndex(2);
	
	//SS
	File Select_Device = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Select_Device, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_2" + ".png"));	
	
	
	driver.findElement(By.id("bt_next")).click();
	driver.findElement(By.xpath("//input[@name='iccid']")).clear();
	driver.findElement(By.xpath("//input[@name='iccid']")).sendKeys(ICCID);
	driver.findElement(By.xpath("//input[@name='imei']")).sendKeys(IMEI);
	new Select(driver.findElement(By.id("selectDealerFilter_configurationArea"))).selectByIndex(8);
	//new Select(driver.findElement(By.id("selectDealerFilter_configurationArea"))).selectByVisibleText("VIVO-SP");
	driver.findElement(By.id("selectDealerFilter_name")).sendKeys("%");
	driver.findElement(By.id("selectDealerFilter_btSearch")).click();
	new Select(driver.findElement(By.id("selectDealerFilter_dealerList"))).selectByVisibleText("11060-Sandro Bonucci - Me");
	
	//ss
	File Enter_ICCID = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Enter_ICCID, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_3" + ".png"));	
	
	driver.findElement(By.id("bt_next")).click();
	new Select(driver.findElement(By.id("reasonCode"))).selectByIndex(1);
	
	//SS
	File Motivo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Motivo, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_4" + ".png"));
	
	Thread.sleep(1000);
	//driver.findElement(By.xpath("//input[@value='Avan�ar']")).sendKeys(Keys.ENTER);
	driver.findElement(By.id("bt_next")).sendKeys(Keys.ENTER);
	//driver.findElement(By.xpath("//input[contains(@id,'bt_next')]")).click();
	
	//SS
	File Concluir = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Concluir, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_5" + ".png"));
	
	Thread.sleep(5000);
	driver.findElement(By.id("bt_finish")).sendKeys(Keys.ENTER);
	
	//SS
	File Submetido = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Submetido, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_6" + ".png"));
	
	
	Thread.sleep(3000);		
	driver.findElement(By.id("yui-gen0")).click();
	/*driver.findElement(By.xpath("//span[contains(text(),'O pedido foi submetido.']")).click();
	driver.findElement(By.xpath("//span[contains(text(),'O pedido foi submetido.']")).sendKeys(Keys.TAB);
	driver.findElement(By.xpath("//span[contains(text(),'O pedido foi submetido.']")).sendKeys(Keys.ENTER);*/
	
	//SS
	File Sucesso = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Sucesso, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_7" + ".png"));
	
	
	
	driver.findElement(By.xpath("//table[@class='detailTable']//td//input")).click();
	
	
	//SS
	
	File Pre_Ativo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Pre_Ativo, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
			+ Line.toString() + "_SS\\" + Line.toString()
			+ "_NGIN_8" + ".png"));
	
	//read line number
	//String Line = driver.findElement(By.xpath("//table[@class='detailTable']//tbody//tr//td[2]")).getText();
	
	//Correct One
	//driver.switchTo().defaultContent();
	//driver.switchTo().frame("topFrame");
	//String Line = driver.findElement(By.xpath("//table[@background='/CustomerCare/images/background_top.gif']//tbody//tr[2]//td[1]//table//tbody//tr[1]/td[2]//span[2]")).getText();
	//System.out.println(Line);
	
	/*driver.switchTo().defaultContent();
	driver.switchTo().frame("topFrame");
	String Line = driver.findElement(By.xpath("//table[@background='/CustomerCare/images/background_top.gif']/tbody/tr[2]/td[1]/table/tbody/tr[1]/td[2]/span[2]")).getText();*/
	
	
	DataProviderExcel.writeDataInExcel(Line, i);

	

	//Opening putty with the help of Sikuli
	
	String putty = "C:\\Users\\Public\\Desktop\\putty.exe";
	
	App.open(putty);
	
   Screen s = new Screen();
	
	Pattern puttyref = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\PuttyObjects\\puttyref");
	s.wait(puttyref.similar((float) 0.70), 20);
	//s.type("10.129.230.5");
	s.type("10.129.180.233");
	
	Pattern open = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\PuttyObjects\\open");
	s.wait(open.similar((float) 0.70), 20).click();
	

	Pattern loginref = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\PuttyObjects\\loginref");
	s.wait(loginref.similar((float) 0.80), 20);
	s.keyDown(KeyEvent.VK_WINDOWS);
	s.keyDown(KeyEvent.VK_UP);
	s.keyUp(KeyEvent.VK_WINDOWS);
	
	s.keyUp(KeyEvent.VK_UP);
	s.type("techteste");
	s.type(Key.ENTER);
	
	Pattern passwordref = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\PuttyObjects\\passwordref");
	s.wait(passwordref.similar((float) 0.80), 20);
	
	//Thread.sleep(1000);
	s.type("Ready4All");
	s.type(Key.ENTER);
	
	Pattern techtesteref = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\PuttyObjects\\ssh_techtesteref");
	s.wait(techtesteref.similar((float) 0.80), 20);
	s.type("ssh techteste@10.129.230.5");
	s.type(Key.ENTER);
	
	Thread.sleep(2000);
	s.type("sudo su - mediation");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("./consumo.sh");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("1");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("1");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type(Line);
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("n");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("11995054523");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("1");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("60");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type("11");
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type(Key.ENTER);
	
	Thread.sleep(1000);
	s.type(Key.ENTER);
	
	
	Pattern finalizadoref = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\PuttyObjects\\finalizadoref");
	s.wait(finalizadoref.similar((float) 0.80), 1000);
	Thread.sleep(2000);
	
	
BufferedImage imgScreen = s.capture().getImage();
ImageIO.write(imgScreen,"png" , new
File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
		+ Line.toString() + "_SS\\" + Line.toString()
		+ "_Putty_Activation" + ".png"));
		 

		//App.close(putty);
	s.keyDown(KeyEvent.VK_ALT);
	s.keyDown(KeyEvent.VK_F4);
	s.keyUp(KeyEvent.VK_ALT);
	s.keyUp(KeyEvent.VK_F4);
	s.type(Key.ENTER);
	//DataProviderExcel.writeDataInExcel(Line,i);
	
	//Active Line SS
	//String Line_Status = driver.findElement(By.xpath("//table[@class='detailTable']//tr[7]//td[2]")).getText();
	driver.switchTo().defaultContent();
	driver.switchTo().frame("topFrame");
	driver.findElement(By.name("value")).clear();
	driver.findElement(By.name("value")).sendKeys(Line);
	driver.findElement(By.xpath("//img[1]")).click();
	
	
	 String count = REFRESHCOUNT;
	 int refreshcount =  Integer.parseInt(count);
	 
	// WebElement ativ = driver.findElement(By.xpath("//table[@class = 'detailTable']//tbody//tr[7]//td[2]"));
	 
	 
	 outerloop:
		 for(int i=1; i<refreshcount; i++){
			 driver.switchTo().defaultContent();
			 driver.switchTo().frame("body");
			 String active = driver.findElement(By.xpath("//table[@class = 'detailTable']//tbody//tr[7]//td[2]")).getText();
			 //System.out.println(active);
			 if(active.equalsIgnoreCase("ATIVO"))
			 {
				 //SS
				System.out.println("Passed");
				
				 File Ativo = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(Ativo, new File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\Line_creation_SS\\"
							+ Line.toString() + "_SS\\" + Line.toString()
							+ "_NGIN_9" + ".png"));
					//String status = driver.findElement(By.xpath("//table[@class = 'detailTable']//tbody//tr[7]//td[2]")).getText();	
					break outerloop;
			 } 
			 
			 else{
				 //keep refreshing
				 
				 	
					/*List<WebElement> detalhar = driver.findElements(By.xpath("//input[@value = 'Detalhar']"));
					System.out.println(detalhar.size());
					detalhar.get(0).click();*/
				 driver.switchTo().defaultContent();
				 driver.switchTo().frame("topFrame");
				 driver.findElement(By.name("value")).clear();
				// driver.findElement(By.name("value")).sendKeys("11999991653");//Ativo line
				driver.findElement(By.name("value")).sendKeys(Line);
				WebElement ele = driver.findElement(By.xpath("//img[1]"));
				ele.click();
			 }
			 
		 }
		 System.out.println("Line Activated");

	}
	 
}