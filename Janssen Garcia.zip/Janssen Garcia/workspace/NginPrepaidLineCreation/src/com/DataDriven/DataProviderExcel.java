package com.DataDriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataProviderExcel {
	

	
	static int rowCount;
	public static ArrayList<Object[]> getClientFromExcel() throws IOException
    {           
          ArrayList<Object[]> myData= new ArrayList<Object[]>();
          
          File src =new  File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\src\\com\\DataDriven\\Ngin_Line.xlsx");
            
                FileInputStream fis = new FileInputStream(src);
          //  FileOutputStream fos= new FileOutputStream(src);
            
                
          XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            XSSFSheet sheet1= wb.getSheetAt(0);
            
            DataFormatter formatter = new DataFormatter();
            
            rowCount = sheet1.getLastRowNum();
           System.out.println("Total rows are " + rowCount);
            
           
          // FileOutputStream fos= new FileOutputStream(src);
           //wb.write(fos);
           
            for ( int i = 1 ;i<= rowCount ;i++)
            {
                 
                  String DDD= formatter.formatCellValue(sheet1.getRow(i).getCell(0));
                  String PREFIX = formatter.formatCellValue(sheet1.getRow(i).getCell(1));
                  String ICCID= formatter.formatCellValue(sheet1.getRow(i).getCell(2));
                  String IMEI= formatter.formatCellValue(sheet1.getRow(i).getCell(3));
                  String REFRESHCOUNT = formatter.formatCellValue(sheet1.getRow(i).getCell(4));
                 // String ICCID= formatter.formatCellValue(sheet1.getRow(i).getCell(7));
               
               //   String PATH= formatter.formatCellValue(sheet1.getRow(i).getCell(9));
                 //x System.out.println(Linha);
                //String Type = formatter.formatCellValue(sheet1.getRow(i).getCell(1));
                   //Object ob[]={Username,Password,Linha};
                   Object ob[]={DDD,PREFIX,ICCID,IMEI, REFRESHCOUNT};

                   myData.add(ob);
            
            }
            fis.close();
            return myData;
    }

	
	public static void writeDataInExcel(String Line, int i) throws IOException
    {           

          File src =new  File("C:\\Users\\Janssen Garcia\\workspace\\NginPrepaidLineCreation\\src\\com\\DataDriven\\Ngin_Line.xlsx");
          FileInputStream fis = new FileInputStream(src);
     // FileOutputStream fos= new FileOutputStream(src);
            
                
           XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            XSSFSheet sheet1= wb.getSheet("Sheet1");
            
          //  DataFormatter formatter = new DataFormatter();
            
            rowCount = sheet1.getLastRowNum();
           // fis.close();
          
             sheet1.getRow(0).createCell(5).setCellValue("FINAL_LINE");
           
             
           //sheet1.getRow(0).createCell(10).setCellValue("Conta");
           FileOutputStream fos= new FileOutputStream(src);
       // wb.write(fos);
           
           for ( i=i ;i<= rowCount ;i++)
            {
                 if(sheet1.getRow(i).createCell(5).getCellTypeEnum()== CellType.BLANK)          
                 {
                  sheet1.getRow(i).createCell(5).setCellValue(Line);
                 
                  break;
                 }
                 
      
            }
            
            wb.write(fos);
            fos.close();
                return;
    
    }

	public static String getPATHFromExcel() throws IOException {
		// TODO Auto-generated method stub
		 
        File src =new  File("D:/Selenium work/FirstSelenium/src/OopsConcept/Atlys_Line.xlsx");
          
              FileInputStream fis = new FileInputStream(src);
        //  FileOutputStream fos= new FileOutputStream(src);
          
              
        XSSFWorkbook wb = new XSSFWorkbook(fis);
          
          XSSFSheet sheet1= wb.getSheet("Sheet1");
          
          DataFormatter formatter = new DataFormatter();
          
          rowCount = sheet1.getLastRowNum();
         System.out.println("Total rows are "+ rowCount);
          
         
        // FileOutputStream fos= new FileOutputStream(src);
         //wb.write(fos);
         
         String PATH= formatter.formatCellValue(sheet1.getRow(1).getCell(0));
        // String URL = formatter.formatCellValue(sheet1.getRow(1).getCell(1));
         

          fis.close();
			return PATH;
		
	}


}



