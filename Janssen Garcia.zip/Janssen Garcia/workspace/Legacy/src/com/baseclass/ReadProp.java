package com.baseclass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class ReadProp {
	

	// TODO Auto-generated method stub
//how to read properties file
	//Properties class is already available in java we just need to create the object 
	public static WebDriver driver ;
	public static Properties prop;//Global variable
	
	public ReadProp() throws IOException
	{
		try{
    prop= new Properties();
	FileInputStream ip = new FileInputStream("C:/Users/Janssen Garcia/workspace/Legacy/src/com/baseclass/config.properties");
	prop.load(ip);
	}
	catch(FileNotFoundException e){
		e.printStackTrace();
	}catch(IOException e){
		e.printStackTrace();
	}
	}
	public static void initialization()
	{
		System.out.println(prop.getProperty("browser"));
		String browserName= prop.getProperty("browser");
	
	if(browserName.equals("IE"))
	{
		System.setProperty("webdriver.ie.driver","C:\\Chandigarh_Automation\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		
	}
	else if(browserName.equals("Chrome"))
	{
		System.setProperty("webdriver.chrome.driver","C:\\Chandigarh_Automation\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	else
	{
		System.out.println("no browser value is given");
	}
	
  
    driver.manage().window().maximize();
    driver.manage().deleteAllCookies();
    driver.manage().timeouts().implicitlyWait(80,TimeUnit.SECONDS);
    driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
   
	
}

}
