
package com.MeuVivo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.DataDriven.DataProviderExcel;
import com.baseclass.ReadProp;

public class Meu_CPF_Reg_Datadriven extends ReadProp{
	public static int i;

	public Meu_CPF_Reg_Datadriven() throws IOException 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	@BeforeTest
	public void Meu_Vivo_Login() {
		
		Initialization();

	}
	
	@BeforeMethod
	public void increment()
	{
		i=i+1;
		}

	@DataProvider
	public Iterator<Object[]> getTestData() throws IOException
	{
		ArrayList<Object[]> testData = DataProviderExcel.getClientFromExcel();
		return testData.iterator();
	}
	
	
	@Test(dataProvider="getTestData")
	public void Meu_Vivo_Registeration(String cpf,String name,String nickname,String email,String password,String line) throws InterruptedException, FindFailed, IOException
	{
		// TODO Auto-generated method stub
		
		
		
		
		
        
        driver.findElement(By.id("input_cpf_cadastro")).sendKeys(cpf);
        driver.findElement(By.id("input_nome_cadastro")).sendKeys(name);
        driver.findElement(By.id("input_como_chamado_cadastro")).sendKeys(nickname);
        driver.findElement(By.id("input_cep_cadastro")).sendKeys("01010000");
        driver.findElement(By.id("input_email_cadastro")).sendKeys(email);
        driver.findElement(By.id("input_confirme_email_cadastro")).sendKeys(email);
        driver.findElement(By.id("input_senha_cadastro")).sendKeys(password);
        driver.findElement(By.id("input_confirma_senha_cadastro")).sendKeys(password);
        driver.findElement(By.id("input_loginPF_termos_vivo")).click();
        driver.findElement(By.id("loginPF_btn_cadastrar")).click();
        driver.findElement(By.id("input_telefone")).sendKeys(line);
        driver.findElement(By.xpath("//a[@id = 'loginPF_btn_continuar']//p")).click();
        //String OTP = driver.findElement(By.xpath("//label[contains(text(),'C�digo OTP')]")).getText();
        String codigo = driver.findElement(By.xpath("//label[contains(text(),'C�digo OTP')]")).getText();
        //System.out.println(OTP);
        String otp = codigo.split(": ")[1];
        System.out.println(otp);
        driver.findElement(By.id("input_otp")).sendKeys(otp);
       driver.findElement(By.xpath("//a[@id = 'loginPF_btn_confirmar_otp']//p")).click();
       
      driver.findElement(By.xpath("//button[@id = 'btnFechar' and @class = 'titulo fecharAlert png_bg' and @onclick = 'fechaPopUp();']")).click();
       driver.findElement(By.xpath("//a[@id = 'perfilContasTitle']")).click();
     //driver.findElement(By.xpath("//a[@title = 'Sair']")).sendKeys(Keys.ENTER);
       Thread.sleep(1000);
     driver.findElement(By.xpath("//a[@title = 'Sair']")).click();
     Thread.sleep(14000);
     //driver.findElement(By.id("btnSim")).sendKeys(Keys.ENTER);
     //driver.findElement(By.xpath("//div[@id= 'frmLogout']//input[1]")).sendKeys(Keys.ENTER);
     Screen s = new Screen();
 	
 	Pattern logoutref = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\Meu_Vivo_CPF_Reg\\MeuVivoObjects\\logoutref");
 	s.wait(logoutref.similar((float) 0.70), 20);
 	
 	
 	Pattern sim = new Pattern("C:\\Users\\Janssen Garcia\\workspace\\Meu_Vivo_CPF_Reg\\MeuVivoObjects\\sim");
 	s.wait(sim.similar((float) 0.70), 20).click();
     //driver.findElement(By.xpath("//input[@id = 'btnSim' and @class = 'botSim']")).sendKeys(Keys.ENTER);
     driver.findElement(By.linkText("Cadastre-se")).click();
     DataProviderExcel.writeDataInExcel("Line Registered", i);
        }
        
	}
