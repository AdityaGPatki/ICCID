package com.baseclass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class ReadProp {
	
	public static WebDriver driver ;
	public static Properties prop;//Global variable
	
	public ReadProp() throws IOException
	{
		try{
    prop= new Properties();
	FileInputStream ip = new FileInputStream("C:\\Users\\Janssen Garcia\\workspace\\Meu_Vivo_CPF_Reg\\src\\com\\baseclass\\config.properties");
	prop.load(ip);
	}
	catch(FileNotFoundException e){
		e.printStackTrace();
	}catch(IOException e){
		e.printStackTrace();
	}
	}
	public static void Initialization()
	{
		
		System.out.println(prop.getProperty("browser"));
		
	
		System.setProperty("webdriver.chrome.driver","C:\\Chandigarh_Automation\\chromedriver.exe");
		driver = new ChromeDriver();
	
	
    driver.manage().window().maximize();
    driver.manage().deleteAllCookies();
    driver.manage().timeouts().implicitlyWait(500,TimeUnit.SECONDS);
    driver.manage().timeouts().pageLoadTimeout(500, TimeUnit.SECONDS);
  //  String URL  = DataProvider.getURLFromExcel();
	driver.get(prop.getProperty("url"));
	driver.findElement(By.id("campoRegional")).sendKeys("S�o Paulo");
	driver.findElement(By.xpath("//li[@role = 'menuitem']//a//strong")).click();
	driver.findElement(By.xpath("//div[@style='display: block;']//a")).click();
	driver.findElement(By.xpath("//a[@class='bt_novo' and @value = 'Cadastre-se agora']")).click();
	//driver.findElement(By.name("userId")).sendKeys(prop.getProperty("userID"));
	//driver.findElement(By.name("passwd")).sendKeys(prop.getProperty("password"));
	//driver.findElement(By.className("botao")).click();
	
   
	
}
	
	
	
				
		

}
