package com.Linecreation;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class Testing {

	public static void main(String[] args) throws FindFailed {
		// TODO Auto-generated method stub
Screen s = new Screen();

Pattern ok2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok2.png");
/*Pattern ref8 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref8.png");
s.wait(ref8.similar((float) 0.70), 120);
s.wait(ref8.similar((float) 0.70), 30);
Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
reg8a.highlight(1);
reg8a.wait(ok2.similar((float) 0.90), 30).click();
Pattern ref19 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref19.png");
s.wait(ref19.similar((float) 0.80), 180);
Region reg9 = s.find(ref19).grow(1, 100, 1, 330);
reg9.highlight(1);

reg9.wait(ok2.similar((float) 0.70), 30).click();*/
Pattern ref20 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref20.png");
s.wait(ref20.similar((float) 0.80), 180);
Region reg9a = s.find(ref20).grow(1, 100, 1, 300);
reg9a.highlight(1);
reg9a.wait(ok2.similar((float) 0.70), 30).click();
Pattern ref17 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref17.png");
s.wait(ref17.similar((float) 0.80), 180);

Region reg10 = s.find(ref17).grow(1, 100, 1, 250);
reg10.highlight(1);
Pattern ok5 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok5.png");
reg10.wait(ok5.similar((float) 0.80), 180).click();
	}

}
