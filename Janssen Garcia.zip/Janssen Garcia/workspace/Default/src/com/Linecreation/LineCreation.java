package com.Linecreation;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class LineCreation {

	public static void main(String[] args) throws FindFailed, InterruptedException {
		Screen s = new Screen();

		Pattern Adicionar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Adicionarcliente.png");
		s.wait(Adicionar.similar((float) 0.90), 10).click();
		Pattern ref1 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref1.png");
		s.wait(ref1.similar((float) 0.90), 30);
		         Region reg1 = s.find(ref1).grow(5, 680, 5, 1000);     
		       reg1.highlight(1);
		Pattern cpf = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\cpf.png");
		reg1.wait(cpf.similar((float) 0.90), 5).click();
		reg1.type("84459970929");
		Thread.sleep(2000);
		reg1.type("PESSOA FISICA");
		Pattern pessoafisica = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\pessoafisica.png");
		reg1.wait(pessoafisica.similar((float) 0.80), 180);
		Thread.sleep(2000);
		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		reg1.type("SPOCENTRO");
		Pattern csa = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\csa.png");
		reg1.wait(csa.similar((float) 0.80), 100);
		//Thread.sleep(3000);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type("CHAMADA");
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type("EVENTOSER");
		Pattern cep = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Adicionarcep.png");
		reg1.wait(cep.similar((float) 0.80), 10).click();
		Pattern cep2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\cep2.png");
		reg1.wait(cep2.similar((float) 0.80), 20).click();
		reg1.type("06278300");
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(1000);
		reg1.type("12");
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(2000);
		Pattern Avaliar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Avaliarcredito.png");
		reg1.wait(Avaliar.similar((float) 0.90), 20).click();
		
		Pattern suspender = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\suspenderverificao.png");
		reg1.wait(suspender.similar((float) 0.80), 30).click();
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(3000);
		Pattern Demograficos = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Demograficos.png");
		reg1.wait(Demograficos.similar((float) 0.90), 90).click();
		Pattern ref = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref2.png");
		reg1.wait(ref.similar((float) 0.90), 30);
		         Region reg2 = s.find(ref).grow(10, 330, 5, 350);     
		       reg2.highlight(1);
		         Pattern nascimento = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\nascimento.png");
		  reg2.wait(nascimento.similar((float) 0.90), 50).click();
		  reg2.type("17031996");
		  Thread.sleep(1000);
		  Pattern ok2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok2.png");
		reg2.wait(ok2.similar((float) 0.90), 30).click();
		Pattern Attributos = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Attributos.png");
		s.wait(Attributos.similar((float) 0.90), 60).click();
		//Thread.sleep(5000);
		Pattern pesquisar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\pesquisar.png");
		s.wait(pesquisar.similar((float) 0.60), 60).click();
		
		Pattern ref9 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref9.png");
		s.wait(ref9.similar((float) 0.90), 30);
		 Region reg3 = s.find(ref9).grow(1, 430, 5, 250); 
		 
		 reg3.highlight(1);
			Pattern nome = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\nome.png");
			reg3.wait(nome.similar((float) 0.90), 30).click();
			reg3.type("ATLYS");
			reg3.type(Key.TAB);
			reg3.type(Key.TAB);
			reg3.type(Key.ENTER);
			Pattern ref10 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref10.png");
			s.wait(ref10.similar((float) 0.90), 30);
			 Region reg4 = s.find(ref10).grow(1, 430, 5, 250);     
		       reg4.highlight(1);
			reg4.wait(ok2.similar((float) 0.70), 30).click();
			Pattern ref11 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref11.png");
			s.wait(ref11.similar((float) 0.90), 30);
			 Region reg5 = s.find(ref11).grow(1, 80, 5, 100);     
		       reg5.highlight(1);
			reg5.wait(ok2.similar((float) 0.70), 30).click();
			//s.wait(ok2.similar((float) 0.80), 30).click();
			//Pattern ok3 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok3.png");
			reg1.wait(ok2.similar((float) 0.90), 30).click();
			
			Pattern conta = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Adiconta.png");
	        s.wait(conta.similar((float) 0.80), 30).click();
	        Pattern ref2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\refconta.png");
	              s.wait(ref2.similar((float) 0.80), 180);
	        Region reg6 =s.find(ref2).grow(1, 950, 5, 600);
	        reg6.highlight(1);
	        
	        Pattern funcoes = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\funcoesassinatura.png");
	                    s.wait(funcoes.similar((float) 0.70), 60).click();
	                    Thread.sleep(3000);
	                    s.type(Key.DOWN);
	                    
	                    s.type(Key.ENTER);
	                    Pattern refplan = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\refplan.png");
	                    s.wait(refplan.similar((float) 0.90), 180);
	                    s.type("NOVOS PLANOS E VANTAGENS POS");
	                    Thread.sleep(4000);
	                    s.type(Key.TAB);
	                    s.type("VIVO_POS 9GB");
	                    s.type(Key.TAB);
	                    s.type(Key.DOWN);
	                    s.type(Key.TAB);
	                    s.type(Key.ENTER);
	                    
	                    Pattern selectplan = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\selectplan.png");
	                    s.wait(selectplan.similar((float) 0.70), 10);
	                    Region plan1 = s.find(selectplan).offset(9, 69);
	                    plan1.highlight(1);
	                    Thread.sleep(2000);
	                    plan1.click();
	                    Thread.sleep(1000);
	                    Pattern addplan = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\addplan.png");
	                    s.wait(addplan.similar((float) 0.70), 30).click();
	                    Pattern ref14 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref14.png");
	                    if(s.exists(ref14, 90)!=null){
	                          Region regx = s.find(ref14).grow(1, 100, 1, 300);
	                          regx.highlight(1);
	                         // Pattern ok2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok2.png");
	                          regx.wait(ok2.similar((float) 0.90), 90).click();
	                    }else{
	                          System.out.println("Pattern not found");
	                    }
	                    
	                    Pattern ref8 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref8.png");
	                    s.wait(ref8.similar((float) 0.70), 120);
	                    Region reg8 = s.find(ref8).grow(1, 200, 1, 300);
	                    reg8.highlight(1);
	                    //Pattern ok2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok2.png");
	                    reg8.wait(ok2.similar((float) 0.90), 90).click();
	                    Thread.sleep(2000);
	                    
	                    Pattern reftipo = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\reftipo.png");
	                    s.wait(reftipo.similar((float) 0.80), 30);
	                    Region fatura = s.find(reftipo).offset(60, 30);
	                    //fatura.highlight(1);
	                    fatura.doubleClick();
	                    s.type("Tipo De Fatura");

	                    s.type(Key.TAB);
	                    s.type(Key.TAB);
	                    s.type(Key.TAB);
	                    Thread.sleep(2000);
	                    s.type(Key.ENTER);
	                    Thread.sleep(2000);
	                    //plan1.highlight(1);
	                    //Thread.sleep(2000);
	                    plan1.click();
	                    
	                    s.wait(addplan.similar((float) 0.70), 30).click();
	                    Thread.sleep(2000);
	                    s.wait(ok2.similar((float) 0.90), 30).click();
	                    Thread.sleep(5000);
	                    //Pattern cmparef = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\cmparef.png");
	                    //s.dragDrop(cmparef, plan1);
	                    
	                    Pattern cmpa = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\cmpa.png");
	                    s.wait(cmpa.similar((float) 0.70), 40).click();
	                    s.type(Key.TAB);
	                    Thread.sleep(3000);
	                    s.type(Key.ENTER);
	                    Thread.sleep(5000);
	                    Pattern ref3 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\configuracaoref.png");
	                    s.wait(ref3.similar((float) 0.90), 180);
	                    s.wait(ok2.similar((float) 0.50), 30).click();
	                    //Pattern ref15 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref15.png");
	                    Pattern continuar = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\continuar.png");
	                    s.wait(continuar.similar((float) 0.70), 180).click();
	                    Pattern Nao = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Nao.png");
	                    s.wait(Nao.similar((float) 0.80), 90).click();
	                    Pattern Servicoref = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\Servicoref.png");
	                    s.wait(Servicoref.similar((float) 0.80), 150);
	                    Pattern iccid = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\iccid.png");
	                    s.wait(iccid.similar((float) 0.80), 90).click();
	                    s.type("89551010303000097487");
	                    Thread.sleep(2000);
	                    s.type(Key.TAB);
	                    s.type(Key.ENTER);
	                    Pattern ref13 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref13.png");
	                    s.wait(ref13.similar((float) 0.80), 180);
	                    s.wait(ok2.similar((float) 0.50), 30).click();
	                    
	                    s.wait(continuar.similar((float) 0.80), 90).click();
	                    Pattern lineref = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\lineref.png");
	                    s.wait(lineref.similar((float) 0.80), 180);
	                   Thread.sleep(1000);
	                   s.type("11999006875");
	                    s.type(Key.TAB);
	                    s.wait(ok2.similar((float) 0.50), 30).click();

	                  
	                    s.wait(ref8.similar((float) 0.70), 90);
	                    Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
	                    reg8a.highlight(1);
	                    reg8a.wait(ok2.similar((float) 0.90), 30).click();
	                    Pattern ref19 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref19.png");
	                    s.wait(ref19.similar((float) 0.80), 180);
	                    Region reg9 = s.find(ref19).grow(1, 100, 1, 330);
	                    reg9.highlight(1);
	                   // Pattern ok2 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok2.png");
	                    reg9.wait(ok2.similar((float) 0.70), 30).click();
	                    Pattern ref20 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref20.png");
	                    s.wait(ref20.similar((float) 0.80), 180);
	                    Region reg9a = s.find(ref20).grow(1, 100, 1, 150);
	                    reg9a.highlight(1);
	                    reg9a.wait(ok2.similar((float) 0.70), 30).click();
	                    Pattern ref17 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ref17.png");
	                    s.wait(ref17.similar((float) 0.80), 180);

	                    Region reg10 = s.find(ref17).grow(1, 100, 1, 200);
	                    reg10.highlight(1);
	                    Pattern ok5 = new Pattern("C:\\Users\\Telefonica\\Documents\\Atlys\\ok5.png");
	                    reg10.wait(ok5.similar((float) 0.70), 180).click();		

	}
}