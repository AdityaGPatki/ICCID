package com.iccid;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BuscarIccidDBConnection {

	// static String region;
	PreparedStatement  smt;
	
	ArrayList<String> dataValue = new ArrayList<>();

	public BuscarIccidDBConnection() throws ClassNotFoundException, SQLException {
	    Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded...");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//10.129.229.178:1521/slrc", "cpm", "7aveiro");
		System.out.println("Connected....");
		//smt = conn.createStatement();
		smt = conn.prepareStatement("SELECT ICCID, IMSI FROM GSIM.SIMCARD@GSIM G WHERE 1=1 AND ID_HLR =11 AND STATUS_CODE = '07' AND KIT_TYPE = 0 AND MSISDN = '000000000000' AND NOT EXISTS (SELECT IMSI FROM slr_clients S WHERE S.IMSI = G.IMSI) LIMIT 1000");
	
	}

	public ResultSet getBuscalccid(int x, int y) throws SQLException {

		ResultSet resultsetIccid = smt.executeQuery();
		
		//ResultSet resultsetIccid = smt.executeQuery("SELECT ICCID, IMSI FROM GSIM.SIMCARD@GSIM G WHERE 1=1 AND ID_HLR =" + y + " AND STATUS_CODE = '07' AND KIT_TYPE = 0 AND MSISDN = '000000000000' AND NOT EXISTS (SELECT IMSI FROM slr_clients S WHERE S.IMSI = G.IMSI)");
		return resultsetIccid;
		
	}
	  
	
	
}
