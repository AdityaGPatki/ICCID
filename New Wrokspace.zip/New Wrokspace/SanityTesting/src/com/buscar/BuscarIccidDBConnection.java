package com.buscar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class BuscarIccidDBConnection extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	ArrayList<String> dataValue = new ArrayList<>();

	public BuscarIccidDBConnection() throws ClassNotFoundException {
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded");
	}

	public ResultSet getslr_btn(int regional_Name, long quantidade) throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//10.129.229.178:1521/slrc", "cpm", "7aveiro");
		System.out.println("Connected");
		PreparedStatement pstmt2 = conn.prepareStatement("SELECT ICCID, IMSI FROM GSIM.SIMCARD@GSIM G WHERE 1=1 AND ID_HLR =" + regional_Name + "  AND STATUS_CODE = '07' AND KIT_TYPE = 0 AND MSISDN = '000000000000' "
						+ "AND NOT EXISTS (SELECT IMSI FROM slr_clients S WHERE S.IMSI = G.IMSI) AND ROWNUM <="
						+ quantidade);
		ResultSet resultsetIccid = pstmt2.executeQuery();

		return resultsetIccid;
	}

	public ResultSet getgsimqa_btn(int regional_Name, long quantidade) throws SQLException, ClassNotFoundException {
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//10.129.179.49:1521/GSIMQA", "hml_vivo","vivo2012");
		System.out.println("Connected");
		PreparedStatement pstmt2 = conn
				.prepareStatement("select ICCID, IMSI from GSIM.SIMCARD where status_code ='07'and ID_HLR="+ regional_Name + " AND ROWNUM <=" + quantidade);
		// pstmt2.setLong(1, regional_Name);
		ResultSet resultsetIccid2 = pstmt2.executeQuery();

		return resultsetIccid2;

	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

}
