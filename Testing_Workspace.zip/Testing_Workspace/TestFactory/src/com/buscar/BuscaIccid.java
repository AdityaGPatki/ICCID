package com.buscar;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class BuscaIccid {
	public static void main(String args[]) {
		new FormDetails();

	}
}

class FormDetails extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	// Components of thregional_Name_txfe Form
	private Container c;
	private JLabel regional_Name_lbl;
	private JLabel quantidade_lbl;

	private JTextField quantidade_txf;
	private JTextField regional_Name_txf;

	private JButton buscar_btn;
	private JRadioButton gsimqa_rbtn;
	private JRadioButton slr_rbtn;
	private JButton copiar_btn;
	private JTable table;
	private DefaultTableModel model;
	private JScrollPane scrollPane;
	private JPanel panel;

	//private ArrayList<String> icValue = new ArrayList<>();
	//private ArrayList<String> ibValue = new ArrayList<>();
	private String radiovalue;

	public FormDetails() {

		setTitle("Busca Iccid");
		setBounds(200, 80, 700, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);

		c = getContentPane();
		c.setLayout(null);

		regional_Name_lbl = new JLabel("Regional:");
		regional_Name_lbl.setFont(new Font("Arial", Font.PLAIN, 20));
		regional_Name_lbl.setSize(100, 20);
		regional_Name_lbl.setLocation(40, 100);
		c.add(regional_Name_lbl);

		regional_Name_txf = new JTextField();
		regional_Name_txf.setFont(new Font("Arial", Font.PLAIN, 15));
		regional_Name_txf.setSize(450, 30);
		regional_Name_txf.setLocation(200, 100);
		c.add(regional_Name_txf);

		((AbstractDocument) regional_Name_txf.getDocument()).setDocumentFilter(new DocumentFilter() {
			Pattern regEx = Pattern.compile("\\d*");

			@Override
			public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
					throws BadLocationException {
				Matcher matcher = regEx.matcher(text);
				if (!matcher.matches()) {
					return;
				}
				super.replace(fb, offset, length, text, attrs);
			}
		});

		quantidade_lbl = new JLabel("Quantidade:");
		quantidade_lbl.setFont(new Font("Arial", Font.PLAIN, 20));
		quantidade_lbl.setSize(170, 20);
		quantidade_lbl.setLocation(40, 150);
		c.add(quantidade_lbl);

		quantidade_txf = new JTextField();
		quantidade_txf.setFont(new Font("Arial", Font.PLAIN, 15));
		quantidade_txf.setSize(450, 30);
		quantidade_txf.setLocation(200, 150);
		c.add(quantidade_txf);

		((AbstractDocument) quantidade_txf.getDocument()).setDocumentFilter(new DocumentFilter() {
			Pattern regEx = Pattern.compile("\\d*");

			@Override
			public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
					throws BadLocationException {
				Matcher matcher = regEx.matcher(text);
				if (!matcher.matches()) {
					return;
				}
				super.replace(fb, offset, length, text, attrs);
			}
		});

		buscar_btn = new JButton("BUSCAR");
		buscar_btn.setFont(new Font("Arial", Font.PLAIN, 15));
		buscar_btn.setSize(100, 20);
		buscar_btn.setLocation(500, 200);
		buscar_btn.addActionListener(this);
		c.add(buscar_btn);

		gsimqa_rbtn = new JRadioButton("GSIMQA");
		gsimqa_rbtn.setFont(new Font("Arial", Font.PLAIN, 15));
		gsimqa_rbtn.setSize(100, 20);
		gsimqa_rbtn.setLocation(40, 200);
		gsimqa_rbtn.addActionListener(this);
		c.add(gsimqa_rbtn);

		slr_rbtn = new JRadioButton("SLR");
		slr_rbtn.setFont(new Font("Arial", Font.PLAIN, 15));
		slr_rbtn.setSize(100, 20);
		slr_rbtn.setLocation(145, 200);
		slr_rbtn.addActionListener(this);
		c.add(slr_rbtn);

		ButtonGroup editableGroup = new ButtonGroup();
		editableGroup.add(gsimqa_rbtn);
		editableGroup.add(slr_rbtn);

		table = new JTable();
		Object[] columnsName = new Object[2];
		columnsName[0] = "ICCID";
		columnsName[1] = "IMSI";
		model = new DefaultTableModel();
		panel = new JPanel();
		panel.setSize(600, 200);
		panel.setLocation(40, 240);
		model.setColumnIdentifiers(columnsName);

		table.setModel(model);
		panel.setLayout(new BorderLayout());
		scrollPane = new JScrollPane(table);
		panel.add(scrollPane, BorderLayout.CENTER);
		c.add(panel);

		copiar_btn = new JButton("Baixar");
		copiar_btn.setFont(new Font("Arial", Font.PLAIN, 15));
		copiar_btn.setSize(100, 20);
		copiar_btn.setLocation(550, 480);
		copiar_btn.addActionListener(this);
		c.add(copiar_btn);

		setVisible(true);

		gsimqa_rbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				radiovalue = "gsimqa_rbtn";
			}
		});

		slr_rbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				radiovalue = "slr_rbtn";
			}
		});
	}

	public void actionPerformed(ActionEvent ae) {

		int rowCount = 0;
		

		if (ae.getSource() == copiar_btn) {
			JFileChooser fileChooser = new JFileChooser();
			int retval = fileChooser.showSaveDialog(copiar_btn);
			if (retval == JFileChooser.APPROVE_OPTION) {
				File file = fileChooser.getSelectedFile();
				if (file != null) {
					if (!file.getName().toLowerCase().endsWith(".xls")) {
						file = new File(file.getParentFile(), file.getName() + ".xls");
					}
					try {
						ExcelExporter exp = new ExcelExporter();
						exp.exportTable(table, file);

						Desktop.getDesktop().open(file);
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();

					} catch (FileNotFoundException e) {
						e.printStackTrace();
						System.out.println("not found");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (ae.getSource() == buscar_btn) {
			ResultSet dbValues = null;
			ResultSet dbValues2 = null;
			 ArrayList<String> icValue =new ArrayList<>();
			 ArrayList<String> ibValue =new ArrayList<>();
			 icValue.clear();
			 ibValue.clear();
			 model.fireTableDataChanged();
			  model.setRowCount(0);
			

			switch (radiovalue) {
			case "gsimqa_rbtn":
				try {
					BuscarIccidDBConnection BuscarIccidDBConnectionobj = new BuscarIccidDBConnection();
					 dbValues2 = BuscarIccidDBConnectionobj.getgsimqa_btn(
							Integer.parseInt(regional_Name_txf.getText()), Long.parseLong(quantidade_txf.getText()));

					while (dbValues2.next()) {
						String iccidDBValue = dbValues2.getString("ICCID");
						String imsiDBValue = dbValues2.getString("IMSI");
						icValue.add(iccidDBValue);
						ibValue.add(imsiDBValue);
						++rowCount;
					}

					Object[] rowData = new Object[4];

					for (int i = 0; i < rowCount; i++) {
						rowData[0] = icValue.get(i);
						rowData[1] = ibValue.get(i);
						model.addRow(rowData);
					}
				}

				catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			case "slr_rbtn":
				try {
					BuscarIccidDBConnection BuscarIccidDBConnectionobj = new BuscarIccidDBConnection();
					 dbValues = BuscarIccidDBConnectionobj.getslr_btn(
							Integer.parseInt(regional_Name_txf.getText()), Long.parseLong(quantidade_txf.getText()));

					while (dbValues.next()) {
						String iccidDBValue = dbValues.getString("ICCID");
						String imsiDBValue = dbValues.getString("IMSI");
						icValue.add(iccidDBValue);
						ibValue.add(imsiDBValue);
						++rowCount;

					}

					Object[] rowData = new Object[4];

					for (int i = 0; i < rowCount; i++) {
						rowData[0] = icValue.get(i);
						rowData[1] = ibValue.get(i);
						model.addRow(rowData);
					}

				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}
}