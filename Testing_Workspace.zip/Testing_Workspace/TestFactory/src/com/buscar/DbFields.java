package com.buscar;

public class DbFields {

	public String iccidDBValue;
	public String imsiDBValue;

	public String getIccidDBValue() {
		return iccidDBValue;
	}

	public void setIccidDBValue(String iccidDBValue) {
		this.iccidDBValue = iccidDBValue;
	}

	public String getImsiDBValue() {
		return imsiDBValue;
	}

	public void setImsiDBValue(String imsiDBValue) {
		this.imsiDBValue = imsiDBValue;
	}
}
