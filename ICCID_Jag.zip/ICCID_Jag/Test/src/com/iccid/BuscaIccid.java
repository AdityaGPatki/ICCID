package com.iccid;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

  public class BuscaIccid {
	public static void main(String args[]) {
		new FormDetails();

	}
}

class FormDetails extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	// Components of thregional_Name_txfe Form
	private Container c;
	private JLabel regional_Name_lbl;
	private JTextField regional_Name_txf;
	private JButton buscar_btn;
	private JButton copiar_btn;
	private JTable table;
	private DefaultTableModel model;
	private JScrollPane scrollPane;
	private JPanel panel;

	

	public FormDetails() {

		setTitle("Busca Iccid");
		setBounds(200, 80, 700, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);

		c = getContentPane();
		c.setLayout(null);

		regional_Name_lbl = new JLabel("Regional:");
		regional_Name_lbl.setFont(new Font("Arial", Font.PLAIN, 20));
		regional_Name_lbl.setSize(100, 20);
		regional_Name_lbl.setLocation(40, 100);
		c.add(regional_Name_lbl);

		regional_Name_txf = new JTextField();
		regional_Name_txf.setFont(new Font("Arial", Font.PLAIN, 15));
		regional_Name_txf.setSize(450, 30);
		regional_Name_txf.setLocation(200, 100);
		c.add(regional_Name_txf);

		((AbstractDocument) regional_Name_txf.getDocument()).setDocumentFilter(new DocumentFilter() {
			Pattern regEx = Pattern.compile("\\d*");

			@Override
			public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
					throws BadLocationException {
				Matcher matcher = regEx.matcher(text);
				if (!matcher.matches()) {
					return;
				}
				super.replace(fb, offset, length, text, attrs);
			}
		});

		buscar_btn = new JButton("Buscar");
		buscar_btn.setFont(new Font("Arial", Font.PLAIN, 15));
		buscar_btn.setSize(100, 20);
		buscar_btn.setLocation(550, 200);
		buscar_btn.addActionListener(this);
		c.add(buscar_btn);

		table = new JTable();
		Object[] columnsName = new Object[2];
		columnsName[0] = "ICCID";
		columnsName[1] = "IMSI";
		model = new DefaultTableModel();
		panel = new JPanel();
		panel.setSize(600, 200);
		panel.setLocation(40, 240);
		model.setColumnIdentifiers(columnsName);

		table.setModel(model);
		panel.setLayout(new BorderLayout());
		scrollPane = new JScrollPane(table);
		panel.add(scrollPane, BorderLayout.CENTER);
		c.add(panel);

		copiar_btn = new JButton("Baixar");
		copiar_btn.setFont(new Font("Arial", Font.PLAIN, 15));
		copiar_btn.setSize(100, 20);
		copiar_btn.setLocation(550, 480);
		copiar_btn.addActionListener(this);
		c.add(copiar_btn);

		setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {

		int rowCount = 0;
		ResultSet dbValues = null;
		 ArrayList<String> icValue =new ArrayList<>();
		 ArrayList<String> ibValue =new ArrayList<>();
		 icValue.clear();
		 ibValue.clear();
		
       model.setRowCount(0);
      
		if (ae.getSource() == copiar_btn) {
			JFileChooser fileChooser = new JFileChooser();
			int retval = fileChooser.showSaveDialog(copiar_btn);
			if (retval == JFileChooser.APPROVE_OPTION) {
				File file = fileChooser.getSelectedFile();

				if (file != null) {
					if (!file.getName().toLowerCase().endsWith(".xls")) {
						file = new File(file.getParentFile(), file.getName() + ".xls");
					}
					try {
						ExcelExporter exp = new ExcelExporter();
						exp.exportTable(table, file);

						Desktop.getDesktop().open(file);
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();

					} catch (FileNotFoundException e) {
						e.printStackTrace();
						System.out.println("not found");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

			}
		}
		if (ae.getSource() == buscar_btn) {
			try {
				BuscarIccidDBConnection BuscarIccidDBConnectionobj = new BuscarIccidDBConnection();
				 dbValues = BuscarIccidDBConnectionobj.getBuscalccid(Integer.parseInt(regional_Name_txf.getText()));
				while (dbValues.next()) {
					String iccidDBValue = dbValues.getString("ICCID");
					String imsiDBValue = dbValues.getString("IMSI");
					icValue.add(iccidDBValue);
					ibValue.add(imsiDBValue);
					++rowCount;
				}
				Object[] rowData = new Object[2];

				for (int i = 0; i < rowCount; i++) {
					rowData[0] = icValue.get(i);
					rowData[1] = ibValue.get(i);
					model.addRow(rowData);
					
				}

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}


