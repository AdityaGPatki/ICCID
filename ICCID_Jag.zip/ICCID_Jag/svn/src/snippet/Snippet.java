package snippet;

public class Snippet {
	Description	Resource	Path	Location	Type
	Unbound classpath container: 'JRE System Library [JavaSE-12]' in project 'Testingtables'	Testingtables		Build path	Build Path Problem
	
}

