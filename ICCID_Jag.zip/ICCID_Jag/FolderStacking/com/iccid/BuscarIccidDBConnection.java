package com.iccid;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class BuscarIccidDBConnection extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	// static String region;
	Statement smt;
	
	ArrayList<String> dataValue = new ArrayList<>();

	public BuscarIccidDBConnection() throws ClassNotFoundException, SQLException {
	    Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded...");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//10.129.229.178:1521/slrc", "cpm", "7aveiro");
		System.out.println("Connected....");
		smt = conn.createStatement();
	
	}

	public ResultSet getBuscalccid(int x, int y) throws SQLException {

		ResultSet resultsetIccid = smt.executeQuery("SELECT ICCID, IMSI FROM GSIM.SIMCARD@GSIM G WHERE 1=1 AND ID_HLR =" + y + " AND STATUS_CODE = '07' AND KIT_TYPE = 0 AND MSISDN = '000000000000' AND NOT EXISTS (SELECT IMSI FROM slr_clients S WHERE S.IMSI = G.IMSI)");
		return resultsetIccid;
		
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}
	  
}
