package com.linux;


import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import net.sf.expectit.*;
import net.sf.expectit.matcher.Matchers;

public class LineActivation {

	public static void main(String[] args) throws JSchException, IOException, InterruptedException {
		// TODO Auto-generated method stub
		
		JSch jsch = new JSch();
		String user = "techteste";
		String password = "Ready4All";
		String host = "10.129.180.233";
		int port =22;
		
		Session session = jsch.getSession(user, host, port);
		System.out.println("Session created");
		
		session.setPassword(password);
		session.setConfig("StrictHostKeyChecking", "no");
		session.connect();
		System.out.println("Connected");
		
		Channel channel = session.openChannel("shell");
		
		 Expect expect = new ExpectBuilder().withOutput(channel.getOutputStream())
         .withInputs(channel.getInputStream(), channel.getExtInputStream())
         .withEchoOutput(System.out)
         .withEchoInput(System.err)
 //        .withInputFilters(removeColors(), removeNonPrintable())
         .withExceptionOnFailure()
         .build();
		 
		// InputStream in = channel.getInputStream();
	//	 OutputStream out = channel.getOutputStream();
		 channel.connect();
		 expect.sendLine("ssh techteste@10.129.230.5");
		 Thread.sleep(2000);
		 expect.sendLine("sudo su - mediation");
		 System.out.println("Session Connected");
		 expect.sendLine("./consumo.sh");
		 expect.expect(Matchers.contains("ESCOLHA UMA"));
		 expect.sendLine("1");
		 
		 expect.expect(Matchers.contains("chamadas a serem processadas"));
		 expect.sendLine("1");
		
		 
		 expect.expect(Matchers.contains("Numero de A"));
		 expect.sendLine("11996019929");
		 
		 expect.expect(Matchers.contains("(Y,N)"));
		 expect.sendLine("N");

		 expect.expect(Matchers.contains("Numero de B"));
		 expect.sendLine("11995859022");
		 
		 expect.expect(Matchers.contains("tipo da chamada"));
		 expect.sendLine("1");
		
		 expect.expect(Matchers.contains("duracao"));
		 expect.sendLine("60");
		 Thread.sleep(2000);
		
		 expect.expect(Matchers.contains("Originador"));
		 expect.sendLine("11");
		 
		 expect.expect(Matchers.contains("EOT do"));
		 expect.sendLine("");
		 
		 expect.expect(Matchers.contains("utilizado"));
		 expect.sendLine("");
		 
		 System.out.println("Call successfull");
		 
		 expect.expect(Matchers.contains("PRE-PROD"));
		 
		 
		 channel.disconnect();
		 session.disconnect();
		 
		 
		 System.out.println("Channel Disconnected");
		 
		 
		
		
		
		

	}

}
