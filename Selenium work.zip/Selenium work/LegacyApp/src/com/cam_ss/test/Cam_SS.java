package com.cam_ss.test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass.ReadProp;
import com.baseclass.TestUtil;

public class Cam_SS extends ReadProp {
	
	
	public static String actualTitle;
	//public static String status ;
	public static int i;
	//public static String status1;
	public Cam_SS() throws IOException {
		super();
		
		// TODO Auto-generated constructor stub
	}

@BeforeTest
public void LaunchUrl()
{
	initialization();
		driver.get(prop.getProperty("url1"));
	 	driver.switchTo().frame("main");
		driver.findElement(By.name("userId")).sendKeys(prop.getProperty("username1"));
		driver.findElement(By.name("passwd")).sendKeys(prop.getProperty("password1"));
		driver.findElement(By.name("cmdlogin")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("contents");
		driver.findElement(By.xpath("//*[contains(@name,'img1')]")).click();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("main");
		driver.findElement(By.linkText("Search service orders")).click();
		WebElement ele = driver.findElement(By.xpath("//select[@name='ddlb_acc_channels']"));
		Select sel= new Select(ele);
		sel.selectByVisibleText("ATLYS");
		driver.findElement(By.name("cmd_next")).click();

	}

@DataProvider
public Iterator<Object[]> getTestData() throws IOException
{

	ArrayList<Object[]> testData = TestUtil.getDataFromExcel();
	return testData.iterator();
}

@BeforeMethod
public void Increment()
{
	i=i+1;
	}

@Test(priority = 0,dataProvider="getTestData")
	static public void CAM_Login_Test(String Linha, String Type) throws IOException
{
	 String status= "Passed";
	int j=0;
	driver.switchTo().defaultContent();
	driver.switchTo().frame("main");
	Actions act = new Actions(driver); 	
	act.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
	act.keyDown(Keys.CONTROL).release().perform();
	driver.findElement(By.xpath("//input[@name='FROM_SUBID_6']")).clear();
	driver.findElement(By.name("FROM_SUBID_6")).sendKeys(Linha);
	//driver.findElement(By.name("FROM_SUBID_6")).sendKeys(prop.getProperty("linha1"));
	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	// Now you can do whatever you need to do with it, for example copy somewhere
	FileUtils.copyFile(scrFile, new File("D:\\Chandigarh Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_CAM"+j+".png"));
	j++;
	driver.findElement(By.name("btnSearchFSDOrder")).click();
	File scrFile1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	// Now you can do whatever you need to do with it, for example copy somewhere
	FileUtils.copyFile(scrFile1, new File("D:\\Chandigarh Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_CAM"+j+".png"));
	j++;
	driver.findElement(By.xpath("//*[contains(@name,'image1')]")).click();
	File scrFile3 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	// Now you can do whatever you need to do with it, for example copy somewhere
	FileUtils.copyFile(scrFile3, new File("D:\\Chandigarh Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_CAM"+j+".png"));
	actualTitle = driver.findElement(By.xpath("//a[contains(text(),'Return to Order summaries page')]")).getText();
	System.out.println("Title is "+ actualTitle);
//	WebElement ele= driver.findElement(By.xpath("/html[1]/body[1]/table[8]/tbody[1]/tr[1]/td[1]/table[1]/tbody[1]/tr[3]/td[1]/span[1]"));
//	String conta= ele.getText();
//	System.out.println(conta);
	/*try
	{
	status =driver.findElement(By.xpath("//span[@class='tableDataInb']//parent::td//parent::tr//parent::tbody//tr[8]//td[6]")).getText();
	}
	catch(Exception e)
	{
		System.out.println(status);
		TestUtil.writeDataInExcel1(status, i);
	}*/
	//driver.findElement(By.xpath("//a[contains(text(),'Return to Order summaries page')]")).click();
	//driver.findElement(By.xpath("//a[contains(text(),'<<Return to order search page')]")).click();
	driver.navigate().back();
	driver.navigate().back();
	TestUtil.writeDataInExcel1(status, i);
}

@AfterTest
 public static void teardown()
{
	driver.close();
}

}
