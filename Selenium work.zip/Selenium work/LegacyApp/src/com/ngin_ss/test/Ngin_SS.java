package com.ngin_ss.test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass.ReadProp;
import com.baseclass.TestUtil;

import com.baseclass.ReadProp;
import com.baseclass.TestUtil;

public class Ngin_SS extends ReadProp {
	
	public static int j=0;
	public static int i=0;
	
	
	
	public Ngin_SS() throws IOException {
		super();//Initialize a super class constructor to initialize the property before intialization method.
		// TODO Auto-generated constructor stub
		
	}
	
@BeforeTest
public void setExtent()
{
	
	//System.setProperty("webdriver.chrome.driver","D:\\Selenium\\chromedriver.exe");
////	driver = new ChromeDriver();
////	System.out.println("launch Ngin url");
////	driver.get("http://10.129.174.30:8004/CustomerCare");
////	driver.manage().window().maximize();
////	driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
////	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
}

@DataProvider
public Iterator<Object[]> getTestData() throws IOException
{
	ArrayList<Object[]> testData = TestUtil.getDataFromExcel();
	return testData.iterator();
	}

@BeforeMethod
public void Ngin_login()
{
	initialization();
	driver.get(prop.getProperty("url"));
	driver.findElement(By.name("userId")).sendKeys(prop.getProperty("username"));
	driver.findElement(By.name("passwd")).sendKeys(prop.getProperty("password"));
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	j=j+1;
	}


@Test(priority = 0,dataProvider="getTestData")
public void Ngin_Linha_Test(String Linha, String Type) throws IOException, InterruptedException 
{   
	
	String Ngin_Plan = null;
	String status = "failed";
	if(Type.equalsIgnoreCase("Postpaid"))
	{
		//driver.switchTo().defaultContent();
		driver.switchTo().frame("topFrame");
		WebElement ele=driver.findElement(By.xpath("//select[@name='criteria']"));
		Select sel= new Select(ele);
		sel.selectByVisibleText("N.� linha");
		driver.findElement(By.xpath("//input[@type='text']")).clear();
		driver.findElement(By.name("value")).sendKeys(Linha);
		//driver.findElement(By.name("value")).sendKeys(prop.getProperty("linha1"));
		WebElement img=driver.findElement(By.xpath("//img[1]"));
		img.click();
		try
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame("body");
			driver.findElement(By.xpath("//td[contains(text(),'Estado:')]")).isDisplayed();
		}

		catch(Exception e)
		{
			e.toString();
			status="failed";
			System.out.println(status);
			TestUtil.writeDataInExcelNG(j, status,Ngin_Plan);
			//driver.close();
		}
		
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, new File("D:\\Chandigarh_Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_NGIN"+i+".png"));
		i++;
		String Str = driver.findElement(By.xpath("//td[contains(text(),'Estado:')]")).getText();
		System.out.println("Estado is" + "" + Str);
		Assert.assertEquals(Str,"Estado:");
	    Ngin_Plan = driver.findElement(By.xpath("//div[@class='centered']//table//tr[5]//td[contains(text(),'Plano:')]//following-sibling::td")).getText();
		System.out.println(Ngin_Plan);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("topFrame");
			driver.findElement(By.xpath("//input[contains(@onclick,'displayBalances')]")).click();
			File scrFile1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// Now you can do whatever you need to do with it, for example copy somewhere
			FileUtils.copyFile(scrFile1, new File("D:\\Chandigarh_Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_NGIN"+i+".png"));
			i++;
			driver.switchTo().defaultContent();
			driver.switchTo().frame("menu");
			driver.findElement(By.xpath("//span[contains(text(),'Linha')]")).click();
			driver.findElement(By.xpath("//span[contains(text(),'Consultas')]")).click();
			driver.findElement(By.xpath("//a[contains(text(),'Servi�os Contratados')]")).click();
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			driver.switchTo().frame("body");
			driver.findElement(By.xpath("//div[contains(text(),'B�sicos')]")).click();
				Actions act = new Actions(driver); 	
				act.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
				act.keyDown(Keys.CONTROL).release().perform();
			File scrFile2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// Now you can do whatever you need to do with it, for example copy somewhere
			FileUtils.copyFile(scrFile2, new File("D:\\Chandigarh_Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_NGIN"+i+".png"));
			status="passed";
			System.out.println(status);
			TestUtil.writeDataInExcelNG(j, status,Ngin_Plan);
			//TestUtil.writeDataInExcelNgin(i, status,Ngin_Plan);
	}
	else if(Type.equalsIgnoreCase("Controle"))
	{
		     driver.switchTo().defaultContent();
		     driver.switchTo().frame("topFrame");
	        boolean present;
	        try
	        {
	        	driver.findElement(By.xpath("//a[contains(text(),'P�s-pago')]")).click();
	        	present=true;
	        }
	        catch(NoSuchElementException e)
	        {
	        	present=false;
	        }
		     //driver.findElement(By.xpath("//a[contains(text(),'P�s-pago')]")).click();
			 WebElement ele=driver.findElement(By.xpath("//select[@name='criteria']"));
			 Select sel= new Select(ele);
			 sel.selectByVisibleText("N.� linha");
			 driver.findElement(By.xpath("//input[@type='text']")).clear();
			 driver.findElement(By.name("value")).sendKeys(Linha);
			 Thread.sleep(2000);
			 WebElement img=driver.findElement(By.xpath("//img[1]"));
			 img.click();
			 driver.switchTo().defaultContent();
			 driver.switchTo().frame("body");
			
//            List<WebElement> size = driver.findElements(By.xpath("//*[contains(text(),'N�mero de linha inexistente')]"));
//            System.out.println(size.size());
//            
//            if(size.size() != 0){
//                  System.out.println("Failed");
//                  
//            }else{
//                  System.out.println("Passed");
//                  
//            }

			try
			{
				driver.findElement(By.xpath("//td[contains(text(),'Estado:')]"));
				//driver.findElement(By.id("backButton")).click();
				//driver.findElement(By.xpath("//b[contains(text(),' N�mero de linha inexistente. ')]")).isDisplayed();
			}

			catch(Exception e)
			{
				e.toString();
				status="failed";
				System.out.println(status);
				TestUtil.writeDataInExcelNG(i, status,Ngin_Plan);
				//driver.close();
			}
	      	
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, new File("D:\\Chandigarh_Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_NGIN"+i+".png"));
		i++;
		driver.switchTo().defaultContent();
		driver.switchTo().frame("body");
		 driver.switchTo().defaultContent();
		 driver.switchTo().frame("body");
		 String Str = driver.findElement(By.xpath("//td[contains(text(),'Estado:')]")).getText();
//		System.out.println("Estado is" + "" + Str);
		Assert.assertEquals(Str,"Estado:");
			Ngin_Plan = driver.findElement(By.xpath("//div[@class='centered']//table//tr[5]//td[contains(text(),'Plano:')]//following-sibling::td")).getText();
			System.out.println(Ngin_Plan);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("topFrame");
			driver.findElement(By.xpath("//input[contains(@onclick,'displayBalances')]")).click();
			File scrFile1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// Now you can do whatever you need to do with it, for example copy somewhere
			FileUtils.copyFile(scrFile1, new File("D:\\Chandigarh_Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_NGIN"+i+".png"));
			i++;
			driver.switchTo().defaultContent();
			driver.switchTo().frame("menu");
			driver.findElement(By.xpath("//span[contains(text(),'Linha')]")).click();
			driver.findElement(By.xpath("//span[contains(text(),'Consultas')]")).click();
			driver.findElement(By.xpath("//a[contains(text(),'Servi�os Contratados')]")).click();
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			driver.switchTo().frame("body");
			driver.findElement(By.xpath("//div[contains(text(),'B�sicos')]")).click();
			Thread.sleep(2000);
				Actions act = new Actions(driver); 	
				act.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
				act.keyDown(Keys.CONTROL).release().perform();
				status="passed";
				System.out.println(status);
			File scrFile2 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// Now you can do whatever you need to do with it, for example copy somewhere
			FileUtils.copyFile(scrFile2, new File("D:\\Chandigarh_Automation\\Legacy_Evidence\\"+Linha.toString()+"_SS\\"+Linha.toString()+"_NGIN"+i+".png"));
			TestUtil.writeDataInExcelNG(i, status,Ngin_Plan);
			 }
			 
	
	 }


@AfterMethod
public void teardown()
{
driver.close();	
}

}
