package com.baseclass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cam_ss.test.Cam_SS;

public class TestUtil extends Cam_SS {
	
public TestUtil() throws IOException {
		
		// TODO Auto-generated constructor stub
	}
	static XSSFReader reader;
	static int i=0;
	static int rowCount=0;
	public static String status1;
	
	public static ArrayList<Object[]> getDataFromExcel() throws IOException
	{		 
		ArrayList<Object[]> myData= new ArrayList<Object[]>();
		
		 File src =new  File("D:\\Selenium work\\LegacyApp\\src\\com\\baseclass\\Linha.xlsx");
	        
	       	FileInputStream fis = new FileInputStream(src);
	       // FileOutputStream fos= new FileOutputStream(src);
	        
	       	
	        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        
	        XSSFSheet sheet1= wb.getSheet("Global");
	        
	        DataFormatter formatter = new DataFormatter();
	        
	        rowCount = sheet1.getLastRowNum();
	       
	        
	       
	      // FileOutputStream fos= new FileOutputStream(src);
	      // wb.write(fos);
	       
	        for ( i =1 ;i<= rowCount ;i++)
	        {
	              String Linha= formatter.formatCellValue(sheet1.getRow(i).getCell(0));
	              String Type = formatter.formatCellValue(sheet1.getRow(i).getCell(1));
	               //Object ob[]={Username,Password,Linha};
	               Object ob[]={Linha,Type};
	              myData.add(ob);
	        }
	        fis.close();
	        return myData;
	}
	
	public static void writeDataInExcel1(String status, int i) throws IOException
	{		 

		File src =new  File("D:\\Selenium work\\LegacyApp\\src\\com\\baseclass\\Linha.xlsx");
	       	FileInputStream fis = new FileInputStream(src);
       // FileOutputStream fos= new FileOutputStream(src);
	        
	       	
        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        
	        XSSFSheet sheet1= wb.getSheet("Global");
	        
	      //  DataFormatter formatter = new DataFormatter();
	        
	        rowCount = sheet1.getLastRowNum();
	       // fis.close();
	      
	         sheet1.getRow(0).createCell(4).setCellValue("Status_CAM");
	         sheet1.getRow(0).createCell(10).setCellValue("Status_Vivo");
	       //sheet1.getRow(0).createCell(6).setCellValue("Conta");
	       FileOutputStream fos= new FileOutputStream(src);
         // wb.write(fos);
	       
	       for ( i=i ;i<= rowCount ;i++)
	        {
	             if(sheet1.getRow(i).createCell(1).getCellType()== CellType.BLANK)          
	             {
	              sheet1.getRow(i).createCell(4).setCellValue(status);
	              sheet1.getRow(i).createCell(10).setCellValue(status);
	              break;
	             }
	           
//	       
	        }
	        
	        wb.write(fos);
	        fos.close();
			return;
	
	}
	
    public static void writeDataInExcel(int i,String Type, String Name ,String Plan, String CPF,String conta, String status) throws IOException
    {           

          File src =new  File("D:\\Selenium work\\LegacyApp\\src\\com\\baseclass\\Linha.xlsx");
            
                FileInputStream fis = new FileInputStream(src);
          // FileOutputStream fos= new FileOutputStream(src);
            
                
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            XSSFSheet sheet1= wb.getSheet("Global");
            
          //  DataFormatter formatter = new DataFormatter();
            
            rowCount = sheet1.getLastRowNum();
           // fis.close();
            
           sheet1.getRow(0).createCell(5).setCellValue("Name");
           sheet1.getRow(0).createCell(6).setCellValue("Plan"); 
           sheet1.getRow(0).createCell(7).setCellValue("CPF");
           sheet1.getRow(0).createCell(8).setCellValue("Conta");
           sheet1.getRow(0).createCell(9).setCellValue("Status");
          // sheet1.getRow(0).createCell(8).setCellValue("Tipo de Pessoa");
           
           FileOutputStream fos= new FileOutputStream(src);
          // wb.write(fos);
           
           
           
           for ( i=i ;i<= rowCount ;i++)
            {
        	   
                 if(sheet1.getRow(i).createCell(1).getCellType()== CellType.BLANK )
           
                 {
                  sheet1.getRow(i).createCell(1).setCellValue(Type);
                  sheet1.getRow(i).createCell(5).setCellValue(Name);
                  sheet1.getRow(i).createCell(6).setCellValue(Plan);
                  sheet1.getRow(i).createCell(7).setCellValue(CPF);
                  sheet1.getRow(i).createCell(8).setCellValue(conta);
                  sheet1.getRow(i).createCell(9).setCellValue(status);
                 // sheet1.getRow(i).createCell(8).setCellValue(Type);
                  
                  break;
                  
                 }
                 
                 else
                 {
                     //  sheet1.getRow(1).createCell(1).setCellValue(Type);
                       
                 }
            }
            
            wb.write(fos);
            fos.close();
                return;
        
    }
    public static void writeDataInExcelNG(int j, String status,String Ngin_Plan) throws IOException
    {           

          File src =new  File("D:\\Selenium work\\LegacyApp\\src\\com\\baseclass\\Linha.xlsx");
            
                FileInputStream fis = new FileInputStream(src);
          // FileOutputStream fos= new FileOutputStream(src);
            
                
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            XSSFSheet sheet1= wb.getSheet("Global");
            
          //  DataFormatter formatter = new DataFormatter();
            
            rowCount = sheet1.getLastRowNum();
           // fis.close();
            
            sheet1.getRow(0).createCell(2).setCellValue("Plano_NGIN");
           sheet1.getRow(0).createCell(3).setCellValue("Ngin_Status");
          // sheet1.getRow(0).createCell(8).setCellValue("Tipo de Pessoa");
           
           FileOutputStream fos= new FileOutputStream(src);
          // wb.write(fos);
           
           
           
           for ( i=j ;i<= rowCount ;i++)
            {
        	   
                 if(sheet1.getRow(i).createCell(1).getCellType()== CellType.BLANK )
           
                 {
                	sheet1.getRow(i).createCell(2).setCellValue(Ngin_Plan);
                  sheet1.getRow(i).createCell(3).setCellValue(status);
                 // sheet1.getRow(i).createCell(8).setCellValue(Type);
                  
                  break;
                  
                 }
                 
                 else
                 {
                     //  sheet1.getRow(1).createCell(1).setCellValue(Type);
                       
                 }
            }
            
            wb.write(fos);
            fos.close();
                return;
        
    }
    public static void writeDataInExcelNgin(int i,String status,String Ngin_Plan) throws IOException
    {           
          //ArrayList<Object[]> myData= new ArrayList<Object[]>();
          File src =new  File("D:\\Selenium work\\LegacyApp\\src\\com\\baseclass\\Linha.xlsx");
            
                FileInputStream fis = new FileInputStream(src);
          // FileOutputStream fos= new FileOutputStream(src);
            
                
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            XSSFSheet sheet1= wb.getSheet("Global");
            
          //  DataFormatter formatter = new DataFormatter();
            
            rowCount = sheet1.getLastRowNum();
           // fis.close();
            
            sheet1.getRow(0).createCell(2).setCellValue("Plano_NGIN");
            sheet1.getRow(0).createCell(3).setCellValue("Ngin_Status");
           FileOutputStream fos= new FileOutputStream(src);
           
          for(i=i;i<= rowCount;i++)
           {
        	   if(sheet1.getRow(i).createCell(1).getCellType()== CellType.BLANK)
       	   {
           
        		   sheet1.getRow(i).createCell(2).setCellValue(Ngin_Plan);
        		   sheet1.getRow(i).createCell(3).setCellValue(status);
        	   }
        	   
       	   }
            
            wb.write(fos);
            fos.close();
                return;
        
    }

}
