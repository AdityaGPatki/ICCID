package com.Vivo.ss.test;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.baseclass.ReadProp;
import com.baseclass.TestUtil;



public class Vivo_SS extends ReadProp{
	 public static int i=0;
	 public static String status = "failed";
	 static String actualTitle;
	 public Vivo_SS() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	@BeforeTest
	public void LaunchUrl() throws InterruptedException
	{
			initialization();
			driver.get(prop.getProperty("url3"));
			driver.findElement(By.id("usuarioTextBox")).sendKeys(prop.getProperty("Usar"));												
			driver.findElement(By.id("senhaTextBox")).sendKeys(prop.getProperty("Senha"));
			driver.findElement(By.id("loginButton")).click();
			driver.switchTo().frame("__frame0");
			WebElement ele2 = driver.findElement(By.xpath("//button[@id='continuarButton']"));
			//button[contains(@id,'continuarButton'
			ele2.click();
			//clickElementByJS(driver, ele2);
			driver.navigate().refresh();
			WebElement ele = driver.findElement(By.xpath("//select[@id='grupoListBox']"));
			Select sel= new Select(ele);
			sel.selectByVisibleText("GERENTE_PRE_VIVO360");
			WebElement ele1 = driver.findElement(By.xpath("//select[@id='codigoCanalListBox']"));
			Select sel1= new Select(ele1);
			sel1.selectByVisibleText("99937");
			Thread.sleep(6000);
			driver.findElement(By.xpath("//img[contains(@id,'changePerfilImage')]")).click();
			Thread.sleep(2000);

		}
	@DataProvider
	public Iterator<Object[]> getTestData() throws IOException
	{

		ArrayList<Object[]> testData = TestUtil.getDataFromExcel();
		return testData.iterator();
	}
	@BeforeMethod
	public void Increment()
	{
	i=i+1;		
	}
	@Test(dataProvider ="getTestData")
	public void VIVO_Login_SS(String Linha, String Type) throws InterruptedException, IOException
	{
		int j=0;
		driver.switchTo().defaultContent();	
		Thread.sleep(8000);
		driver.findElement(By.xpath("//input[@class='portalLojaHeaderListBox' and @id ='_mask_1']")).sendKeys(Linha);
		Thread.sleep(8000);
		driver.findElement(By.xpath("//button[@id='buscarButton']")).click();
		Thread.sleep(40000); 
         try
        {
             driver.findElement(By.xpath("//div[@class='FeaturedLabel' and @id ='nome']"));
        		//driver.findElement(By.xpath("//div[@class='crux-MessageBox']//div[@class='message']")).getText();
        }
        
           catch(Exception e){ 
        	   status = "failed";
        	   System.out.println(status);
        	   TestUtil.writeDataInExcel1(status, i);
        	   //driver.close();
           }
      
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// now copy the  screenshot to desired location using copyFile //method
		FileUtils.copyFile(src, new File("D:\\Chandigarh_Automation\\Legacy_Evidence//"+Linha+"_SS"+"//"+Linha.toString()+"_VIVO"+j+".png"));
		j++;
		String Plan = driver.findElement(By.xpath("//div[@class='gwt-Label' and @id ='plano']")).getText();//*[@id="innerPanelHeaderCliente"]/tbody/tr[2]/td[3]
		System.out.println(Plan);
		String CPF = driver.findElement(By.xpath("//div[@class='gwt-Label' and @id ='documentoCliente']")).getText();
		System.out.println(CPF);
		String Name = driver.findElement(By.xpath("//div[@class='FeaturedLabel' and @id ='nome']")).getText();
		System.out.println(Name);
		driver.switchTo().frame("MAIN_TAB_RESUMO_CLIENTE.window");
		driver.switchTo().frame("idTabResumo.window");
		String conta = driver.findElement(By.xpath("//div[@id='_crux_slidingTabMainPanel']//div[@id='slidingTabMainPanel']//table//table[@id='tabelaPaineisCimaResumo']//table[@id='panelCreditoConta']//table//table[@id='vPanelDadosCredito']//table[@id='dadosCredito']//table[@id='pNumeroConta']//preceding-sibling::td//following-sibling::td//span[@id='numeroContaValue']")).getText();
		System.out.println(conta);
		String Dob = driver.findElement(By.xpath("//div[@id='_crux_slidingTabMainPanel']//div[@id='slidingTabMainPanel']//table//table[@id='tabelaPaineisCimaResumo']//table[@id='panelUsuario']//table//table[@id='vPanelDadosUsuario']//table//table[@id='pDataNascimento']//div[@id='dataNascimentoValue']")).getText();
		System.out.println(Dob);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("//*[contains(text(),'DETALHES')]")).click();
		Thread.sleep(30000);
		driver.switchTo().frame(1);
		Thread.sleep(2000);
		status="pass";
		TestUtil.writeDataInExcel(i, Type, Name,Plan, CPF, conta,status);
		File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src1, new File("D:\\Chandigarh_Automation\\Legacy_Evidence//"+Linha+"_SS"+"//"+Linha.toString()+"_VIVO_"+j+".png"));
		
	}
	public static void clickElementByJS(WebDriver driver, WebElement ele2)
	{
		JavascriptExecutor js = ((JavascriptExecutor)driver);
		js.executeScript("argument[0].innerHTML;", ele2).toString();
	

}}
