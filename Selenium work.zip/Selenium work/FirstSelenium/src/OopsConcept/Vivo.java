package OopsConcept;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Vivo {

	static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","D:\\Jagdeep\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://vivo360-preprod-qa.redecorp.br/vivo360/pages/crux/login/login.html");
		Thread.sleep(5000);
		driver.findElement(By.id("usuarioTextBox")).sendKeys("c_qneto"); // c_lpinho
		driver.findElement(By.id("senhaTextBox")).sendKeys("jogador252"); // Vivo@15
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(8000);
		driver.switchTo().frame(1);
		WebElement ele2 = driver.findElement(By
				.xpath("//button[@id='continuarButton']"));
		// button[contains(@id,'continuarButton'
		ele2.click();
		// clickElementByJS(driver, ele2);
		driver.navigate().refresh();
		Thread.sleep(15000);
		WebElement ele = driver.findElement(By
				.xpath("//select[@id='grupoListBox']"));
		Select sel = new Select(ele);
		sel.selectByVisibleText("GERENTE_PRE_VIVO360");
		WebElement ele1 = driver.findElement(By
				.xpath("//select[@id='codigoCanalListBox']"));
		Select sel1 = new Select(ele1);
		sel1.selectByVisibleText("99937");
		Thread.sleep(8000);
		driver.findElement(By.xpath("//img[contains(@id,'changePerfilImage')]"))
				.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		Thread.sleep(8000);
		driver.findElement(
				By.xpath("//input[@class='portalLojaHeaderListBox' and @id ='_mask_1']"))
				.sendKeys("11999209855");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@id='buscarButton']")).click();
		Thread.sleep(20000);
		driver.switchTo().defaultContent();

		// WebElement frame =
		// driver.findElement(By.xpath("//iframe[contains(@id,'idTabResumo.window')]"));
		// System.out.println(driver.findElements(By.tagName("iframe")).size());

		// driver.switchTo().frame(1);
		// Thread.sleep(5000);
		List<WebElement> size = driver.findElements(By.tagName("table"));
		System.out.println(size.size());
		// driver.findElements(By.tagName("table")).size();
		// System.out.println(driver.findElements(By.tagName("table")).size());
		// WebDriverWait wait = new WebDriverWait(driver, 10);
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@id='tipoLinhaTituloPos']"))).getText();
		// WebElement ele3 =
		// driver.findElement(By.xpath("//table[@id='pNumeroConta']/tbody[1]/tr[1]/td[2]/span[1]"));
		/*
		 * WebElement table1 =
		 * driver.findElement(By.xpath("//table[@id='portalVPanel']"));
		 * WebElement table2 =
		 * table1.findElement(By.xpath("//table[@id='bodyHPanel']")); WebElement
		 * table3 = table2.findElement(By.xpath("//table[@id='bodyVPanel']"));
		 * WebElement table4 =
		 * table3.findElement(By.xpath("//table[@id='mainDynaTabs']"));
		 */
		driver.switchTo().defaultContent();
		driver.switchTo().frame("MAIN_TAB_RESUMO_CLIENTE.window");
		driver.switchTo().frame("idTabResumo.window");
		// List<WebElement> size1 = driver.findElements(By.tagName("table"));
		// System.out.println(size1.size());
		// WebElement table5 =
		// driver.findElement(By.xpath("//table[@id='tabelaTituloTela']"));
		// WebElement table6 =
		// table5.findElement(By.xpath("//table[@id='consultaClienteDynaTabs']"));
		WebElement table7 = driver.findElement(By
				.xpath("//*[@id='slidingTabMainPanel']/table"));
		WebElement table8 = table7.findElement(By.tagName("table"));
		WebElement table9 = table8.findElement(By.tagName("table"));
		WebElement table10 = table9.findElement(By
				.xpath("//*[@id='panelCreditoConta']/tbody/tr[2]/td/table"));
		WebElement table11 = table10.findElement(By
				.xpath("//*[@id='vPanelDadosCredito']"));
		WebElement table12 = table11.findElement(By
				.xpath("//*[@id='dadosCredito']"));
		WebElement table13 = table12.findElement(By.tagName("table"));
		WebElement conta = table13.findElement(By
				.xpath("//*[@id='numeroContaValue']"));
		System.out.println(conta.getText());
		// System.out.println(ele3.getText());;

		/*
		 * driver.findElement(By.xpath("//*[contains(text(),'DETALHES')]")).click
		 * (); Thread.sleep(30000); List<WebElement> frames =
		 * driver.findElements(By.tagName("iframe"));
		 * System.out.println(frames.size()); for(int i=0; i<frames.size(); i++)
		 * 
		 * { String names = frames.get(i).getText(); System.out.println(names);
		 * }
		 */
	}

}
