package OopsConcept;

public class Telefonica {
	String resource;
	int band;

	public static void main(String[] args) {

		Telefonica a = new Telefonica(); // object is on the right side of =
		Telefonica b = new Telefonica();// on the left side is object reference
										// variable
		Telefonica c = new Telefonica();// a,b,c is the object reference
										// variable

		/* Telefonica d = new Telefonica(); */

		a.resource = "Jagdeep";
		a.band = 12;

		b.resource = "Mukul";
		b.band = 14;

		c.resource = "Isha";
		c.band = 14;

		System.out.println("before assignment");

		System.out.println(a.resource);
		System.out.println(b.band);

		System.out.println("after assignment");
		a = b;
		b = c;
		c = a;

		a.band = 20;
		System.out.println(a.band);
		c.band = 200;
		System.out.println(a.band);

	}

}
