package OopsConcept;

public class Functions {

	public static void main(String[] args) {

		Functions a = new Functions();
		int y = a.abc();
		int x = a.division(10, 2);
		System.out.println(y);
		System.out.println(x);

	}

	// non static methods
	public void test() {// no input,no output
		System.out.println("test method");
	}

	public int abc() {// no input,some output
		int a = 10;
		int b = 12;
		int c = a + b;
		return c;

	}// x,y are input arguments or parameters

	public int division(int x, int y) {
		int d = x / y;
		return d;// return type of d is int

	}

}
