package com.Ngin_tc;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class MothersName {
 static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\Jagdeep\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://10.129.163.11/vivo360/pages/crux/login/login.html");
		Thread.sleep(5000);
		driver.findElement(By.id("usuarioTextBox")).sendKeys("c_lpinho"); // c_qneto
		driver.findElement(By.id("senhaTextBox")).sendKeys("Vivo@15"); // jogador252
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(8000);//
		driver.switchTo().frame(1);
		WebElement ele2 = driver.findElement(By
				.xpath("//button[@id='continuarButton']"));
		// button[contains(@id,'continuarButton'
		ele2.click();
		// clickElementByJS(driver, ele2);
		driver.navigate().refresh();
		Thread.sleep(30000);
		WebElement ele = driver.findElement(By
				.xpath("//select[@id='grupoListBox']"));
		Select sel = new Select(ele);
		sel.selectByVisibleText("GERENTE_PRE_VIVO360");
		WebElement ele1 = driver.findElement(By
				.xpath("//select[@id='codigoCanalListBox']"));
		Select sel1 = new Select(ele1);
		sel1.selectByVisibleText("99937");
		Thread.sleep(8000);
		driver.findElement(By.xpath("//img[contains(@id,'changePerfilImage')]"))
				.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		Thread.sleep(15000);
		driver.findElement(By.xpath("//input[@class='portalLojaHeaderListBox' and @id ='_mask_1']")).sendKeys("11999007078");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@id='buscarButton']")).click();
		Thread.sleep(20000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("MAIN_TAB_RESUMO_CLIENTE.window");
		driver.findElement(By.xpath("//*[@id='_consultaclientedynatabs_idtabdetalhes']/tbody/tr/td[2]/table/tbody/tr/td/div")).click();
		Thread.sleep(30000);
		driver.switchTo().frame("idTabDetalhes.window");
		WebElement alterar = driver.findElement(By.xpath("//*[@id='alterarDadosGeraisButton']"));
		
		boolean a = false;
		if(alterar.isEnabled()!=a) {
			alterar.click();
		}
	    Thread.sleep(5000);
	    driver.switchTo().defaultContent();
	   /* try{
		driver.findElement(By.xpath("//button[contains(text(),'Ok')]")).click();
	    }
		catch(Exception e){
			 e.printStackTrace();
		 }*/
		Thread.sleep(2000);
		try{
	    driver.switchTo().defaultContent();
		driver.switchTo().frame("__frame0");
	
		 WebElement ele4 =  driver.findElement(By.xpath("//input[@id='gwt-uid-1']"));
	 
	  
	  if(ele4.isSelected()!=true) {
		  ele4.click();
	  }
	  
		driver.findElement(By.xpath("//*[@id='gravarButton']")).click();

	    System.out.println("Popup Accepted");
	    Thread.sleep(2000);
	 } catch(Exception e){
		 e.printStackTrace();
	 }
	    
	 /* List<WebElement> List =  driver.findElements(By.tagName("table"));
	   System.out.println(List.size());*/
	  /*  WebElement table = driver.findElement(By.tagName("table"));//1st table
	    WebElement table1 = table.findElement(By.tagName("table"));//2nd table
	    WebElement table2 = table1.findElement(By.tagName("table"));//3rd table
	    WebElement table3 = table2.findElement(By.tagName("table"));//4th table
	    WebElement table4 = table3.findElement(By.tagName("table"));
	    WebElement table5 = table4.findElement(By.tagName("table"));
	    WebElement table6 = table5.findElement(By.tagName("table"));
	    WebElement table7 = table6.findElement(By.tagName("table"));
	  //  WebElement table8 = table7.findElement(By.id("manterDadosNomeMaeMainPanel"));
	   // WebElement table9 = table8.findElement(By.id("manterDadosNomeMaePanel"));  */
	    driver.switchTo().defaultContent();
		driver.switchTo().frame("MAIN_TAB_RESUMO_CLIENTE.window");
		driver.switchTo().frame("idTabDetalhes.window");
	       driver.findElement(By.xpath("//*[@id='nomeMaeText']")).sendKeys("maria");
	       
	          driver.findElement(By.xpath("//button[@id='gravarDadosGeraisButton']")).click();
	          Thread.sleep(3000);
	          driver.switchTo().defaultContent();
	          driver.findElement(By.xpath("//button[contains(text(),'Ok')]")).click();
		// TODO Auto-generated method stub
		

	}

}

