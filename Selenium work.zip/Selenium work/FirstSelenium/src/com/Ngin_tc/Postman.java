package com.Ngin_tc;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import org.sikuli.script.App;

public class Postman {
   public static  String x="";
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		 /* FileReader fr = new FileReader("D:\\Work\\Sample.txt");
		  
		  
		  BufferedReader br= new BufferedReader(fr);
		  
		  
		  while((x=br.readLine()) != null) 
		  { 
			  System.out.println(x); 
			  
		  }
		  
		  br.close();*/
		 

		// DesktopOptions obj = new DesktopOptions();
		// String path =
		// "C:\\Users\\js00570831\\Downloads\\apache-jmeter-2.13\\apache-jmeter-2.13\\apache-jmeter-2.13\\bin\\ApacheJMeter.jar";
		// App.open(path);
		// WiniumDriver dv = new WiniumDriver(new URL("http://localhost:9999"),
		// obj);

		String path = "C:\\Users\\js00570831\\Downloads\\apache-jmeter-2.13\\apache-jmeter-2.13\\apache-jmeter-2.13\\bin\\ApacheJMeter.jar";
		ProcessBuilder pb = new ProcessBuilder("java", "-jar", path);
		
		Process p = pb.start();

	

	}

}
