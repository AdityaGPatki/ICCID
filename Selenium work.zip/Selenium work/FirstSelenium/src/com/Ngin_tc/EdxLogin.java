package com.Ngin_tc;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class EdxLogin {
	
	static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\Work\\Jars\\Drivers\\chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize(); // maximize browser window
		driver.manage().deleteAllCookies(); // delete cookies
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get("https://www.edx.org/");
		
		System.out.println("URL is opened");
		
		driver.findElement(By.linkText("Sign In")).click();
		
		driver.findElement(By.id("login-email")).sendKeys("sainijagdeep19@gmail.com");
		
		driver.findElement(By.id("login-password")).sendKeys("6601.royal");
		
          Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		

	}

}
