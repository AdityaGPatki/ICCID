package com.putty;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ClearIccid {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded");
			
		//Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.129.230.7:1521/pcdba", "adminprov2_10", "adminpro");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.129.179.49:1521/GSIMQA", "hml_vivo", "vivo2012");
		System.out.println("Connected");
	
		BigInteger y = new BigInteger("89551011102000529674"); 
		int x = y.intValue();
		
		int  b = 07;
		
		Statement smt=conn.createStatement();
		String qry = "{Call EXEC GSIM.PR_QA_AT_STATUS_POR_ICCID (?, �?�)}";
		CallableStatement cstmt = null;
		
		try {
		    cstmt = conn.prepareCall(qry);
		    cstmt.setInt(1, x);
		    cstmt.setInt(2, b);
		    cstmt.executeUpdate();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		
  //	smt.executeQuery("EXEC GSIM.PR_QA_AT_STATUS_POR_ICCID (89551011304000228410, �07�)");
	conn.commit();
	System.out.println("Cleared");

	}

}
