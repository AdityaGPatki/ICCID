package com.putty;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded");
			
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.129.230.7:1521/pcdba", "adminprov2_10", "adminpro");
		System.out.println("Connected");
		
		Statement smt=conn.createStatement();
		
		String querry = "Insert into adminprov2_10.inv_nbr_pool( msisdn, min_msisdn, dig7, area_code, status_number, id_parcel,date_import, date_status_change, category_msisdn, nbr_internal)Values('11995056222','11995056222', 0, 11, 0, -999999999,TO_DATE('03/12/2009 13:24:39','MM/DD/YYYY HH24:MI:SS'),TO_DATE('03/20/2009 12:20:03','MM/DD/YYYY HH24:MI:SS'),3,'Y')";
	//	String commit = "commit";
		conn.setAutoCommit(false);
		int count = smt.executeUpdate(querry);
		//int count1 =  smt.executeUpdate(commit);
		 System.out.println("Updated queries: "+count);
		 conn.commit();
		 System.out.println("Commit Completed");
		// System.out.println("Commit Completed: "+ count1 );
		

	}

}
