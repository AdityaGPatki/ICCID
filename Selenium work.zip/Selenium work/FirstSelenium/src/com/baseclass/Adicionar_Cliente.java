package com.baseclass;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import OopsConcept.DataProviderClient;

public class Adicionar_Cliente {

	public static void Criar_Cliente() throws IOException, FindFailed,
			InterruptedException {

		Iterator<Object[]> lst = DataProviderClient.getClientFromExcel()
				.iterator();

		String CPF = lst.next().toString();
		String TYPE = lst.next().toString();
		String PRENOME = lst.next().toString();
		String SOBERNOME = lst.next().toString();
		String CSA = lst.next().toString();

		Screen s = new Screen();

		Pattern Adicionar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Adicionarcliente.png");
		s.wait(Adicionar.similar((float) 0.90), 100).click();
		Pattern ref1 = new Pattern("D:\\LearnSelenium\\Atlys\\ref1.png");
		s.wait(ref1.similar((float) 0.90), 30);
		Region reg1 = s.find(ref1).grow(5, 700, 5, 1000);
		reg1.highlight(2);
		Pattern cpf = new Pattern("D:\\LearnSelenium\\Atlys\\cpf.png");
		reg1.wait(cpf.similar((float) 0.90), 5).click();
		// Thread.sleep(5000);
		reg1.type(CPF);
		Thread.sleep(3000);
		// s.type(Key.TAB);
		reg1.type(TYPE);
		if (TYPE.equalsIgnoreCase("CONTROLE PF")) {
			// reg1.type(TYPE);
			Pattern controlepf = new Pattern(
					"D:\\LearnSelenium\\Atlys\\controlepf.png");
			reg1.wait(controlepf.similar((float) 0.80), 180);
			Thread.sleep(2000);
		}

		else if (TYPE.equalsIgnoreCase("PESSOA FISICA")) {
			// reg1.type(TYPE);
			Pattern pessoafisica = new Pattern(
					"D:\\LearnSelenium\\Atlys\\pessoafisica.png");
			reg1.wait(pessoafisica.similar((float) 0.80), 90);
			Thread.sleep(2000);
		}

		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		reg1.type(CSA);

		Pattern csa = new Pattern("D:\\LearnSelenium\\Atlys\\csa.png");
		reg1.wait(csa.similar((float) 0.50), 30);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(PRENOME);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(SOBERNOME);
		Pattern cep = new Pattern("D:\\LearnSelenium\\Atlys\\Adicionarcep.png");
		reg1.wait(cep.similar((float) 0.80), 10).click();
		Pattern cep2 = new Pattern("D:\\LearnSelenium\\Atlys\\cep2.png");
		reg1.wait(cep2.similar((float) 0.80), 30);
		reg1.type("06278300");
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(5000);
		reg1.type("12");
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(2000);
		Pattern Avaliar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Avaliarcredito.png");
		reg1.wait(Avaliar.similar((float) 0.90), 20).click();
		Pattern duplicate = new Pattern(
				"D:\\LearnSelenium\\Atlys\\duplicate.png");
		// reg1.wait(duplicate.similar((float) 0.90), 5);

		if (reg1.exists(duplicate, 5) != null) {
			Pattern ignorar = new Pattern(
					"D:\\LearnSelenium\\Atlys\\ignorar.png");
			reg1.wait(ignorar.similar((float) 0.90), 20).click();
		} else {
			System.out.println("Name is ok");
		}
		Pattern suspender = new Pattern(
				"D:\\LearnSelenium\\Atlys\\suspenderverificao.png");
		reg1.wait(suspender.similar((float) 0.80), 30).click();
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(4000);
		Pattern Demograficos = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Demograficos.png");
		reg1.wait(Demograficos.similar((float) 0.90), 90).click();
		Pattern ref = new Pattern("D:\\LearnSelenium\\Atlys\\ref2.png");
		reg1.wait(ref.similar((float) 0.90), 30);
		Region reg2 = s.find(ref).grow(10, 330, 5, 350);
		reg2.highlight(2);
		Pattern nascimento = new Pattern(
				"D:\\LearnSelenium\\Atlys\\nascimento.png");
		reg2.wait(nascimento.similar((float) 0.90), 50).click();
		reg2.type("17031996");
		Thread.sleep(1000);
		Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
		reg2.wait(ok2.similar((float) 0.90), 30).click();
		Pattern Attributos = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Attributos.png");
		s.wait(Attributos.similar((float) 0.90), 60).click();
		// Thread.sleep(5000);
		Pattern pesquisar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\pesquisar.png");
		s.wait(pesquisar.similar((float) 0.60), 60).click();
		Thread.sleep(2000);
		Pattern ref9 = new Pattern("D:\\LearnSelenium\\Atlys\\ref9.png");
		s.wait(ref9.similar((float) 0.90), 30);
		Region reg3 = s.find(ref9).grow(1, 430, 5, 250);

		reg3.highlight(1);
		reg3.type(Key.TAB);
		// Pattern nome = new Pattern("D:\\LearnSelenium\\Atlys\\nome.png");
		// reg3.wait(nome.similar((float) 0.90), 30).click();
		reg3.type("ATLYS");
		reg3.type(Key.TAB);
		reg3.type(Key.TAB);
		reg3.type(Key.ENTER);
		Pattern ref10 = new Pattern("D:\\LearnSelenium\\Atlys\\ref10.png");
		s.wait(ref10.similar((float) 0.90), 30);
		Region reg4 = s.find(ref10).grow(1, 430, 5, 250);
		reg4.highlight(2);
		reg4.wait(ok2.similar((float) 0.70), 30).click();
		Pattern ref11 = new Pattern("D:\\LearnSelenium\\Atlys\\ref11.png");
		s.wait(ref11.similar((float) 0.90), 30);
		Region reg5 = s.find(ref11).grow(1, 80, 5, 100);
		reg5.highlight(2);
		reg5.wait(ok2.similar((float) 0.70), 30).click();
		// s.wait(ok2.similar((float) 0.80), 30).click();
		// Pattern ok3 = new Pattern("D:\\LearnSelenium\\Atlys\\ok3.png");
		reg1.wait(ok2.similar((float) 0.90), 30).click();
	}

}
