package com.baseclass;

import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import OopsConcept.DataProviderClient;

public class Read_Prop {
	public static Properties prop = new Properties();

	public static Screen s = new Screen();

	public Read_Prop() throws IOException {

		FileInputStream ip = new FileInputStream(
				"D:\\Selenium work\\FirstSelenium\\src\\OopsConcept\\configAtlysproperties");
		prop.load(ip);
	}

	public void Initialization(String path) throws InterruptedException,
			FindFailed, IOException {
		// TODO Auto-generated method stub
		Screen s = new Screen();
		String Atlys = DataProviderClient.getPathFromExcel();
		// String Atlys =
		// "C:\\Atlys_ProdCert_L10.65A.0.3\\BCC\\p2kenv.atbru2.vivo.bat";
		App.open(Atlys);
		Pattern reflogin = new Pattern("D:\\LearnSelenium\\Atlys\\reflogin.png");
		s.wait(reflogin.similar((float) 0.70), 100);
		s.type("C_RSOARE");
		s.type(Key.TAB);
		s.type("Vivo@15");
		s.type(Key.ENTER);
		System.out.println("App Opened");

		Pattern ok = new Pattern("D:\\LearnSelenium\\Atlys\\ok.png");
		s.wait(ok.similar((float) 0.80), 600).click();
		Thread.sleep(3000);
		s.keyDown(KeyEvent.VK_WINDOWS);
		s.keyDown(KeyEvent.VK_UP);
		s.keyUp(KeyEvent.VK_WINDOWS);
		s.keyUp(KeyEvent.VK_UP);
		s.type(Key.F4);
		Thread.sleep(2000);
		s.keyDown(KeyEvent.VK_ALT);
		s.keyDown(KeyEvent.VK_MINUS);
		s.keyUp(KeyEvent.VK_ALT);
		s.keyUp(KeyEvent.VK_MINUS);
		s.type("x");
		// Pattern maximize = new
		// Pattern("D:\\LearnSelenium\\Atlys\\maximize.png");
		// s.wait(maximize.similar((float) 0.90), 10).click();

	}

}
