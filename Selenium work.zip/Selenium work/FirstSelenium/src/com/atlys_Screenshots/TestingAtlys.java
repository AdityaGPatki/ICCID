package com.atlys_Screenshots;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.sikuli.script.Button;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class TestingAtlys {

	public static void main(String[] args) throws FindFailed,
			InterruptedException, UnsupportedFlavorException, IOException {
		Screen s = new Screen();
		Pattern detalhada = new Pattern(
				"D:\\LearnSelenium\\Atlys\\detalhada.png");
		try {
			s.wait(detalhada.similar((float) 0.70), 5);
		} catch (Exception e) {
			System.out.println(" warning statement in try block");
		}
		if (s.exists(detalhada, 7) != null) {
			s.type(Key.ENTER);
		}

		Pattern Nao = new Pattern("D:\\LearnSelenium\\Atlys\\Nao.png");
		s.wait(Nao.similar((float) 0.80), 90).click();

	}
}
// "C:\\Atlys_ProdCert_L10.65A.0.3\\BCC\\p2kenv.atbru2.vivo.bat"