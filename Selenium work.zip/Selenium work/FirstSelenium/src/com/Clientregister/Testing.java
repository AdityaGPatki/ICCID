package com.Clientregister;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.openqa.selenium.By;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import com.DataDriven.DataProviderFuncionario;
import com.DataDriven.DataProviderMultivivo;

import OopsConcept.DataProviderClient;
 
public class Testing {
	public static int i;
	static Screen s = new Screen();
    static Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
	static Pattern ref8 = new Pattern("D:\\LearnSelenium\\Atlys\\ref8.png");
	
	public static void increment() {
		i = i + 1;
	}
	public static void Client_Register(String TYPE,String CPF, String PRENOME,String SOBERNOME, String CSA) throws FindFailed, InterruptedException{
		

		Pattern Adicionar = new Pattern("D:\\LearnSelenium\\Atlys\\Adicionarcliente.png");
		s.wait(Adicionar.similar((float) 0.90), 100).click();
		Pattern ref1 = new Pattern("D:\\LearnSelenium\\Atlys\\ref1.png");
		s.wait(ref1.similar((float) 0.90), 30);
		Region reg1 = s.find(ref1).grow(5, 700, 5, 1000);
		reg1.highlight(2);
		Pattern cpf = new Pattern("D:\\LearnSelenium\\Atlys\\cpf.png");
		reg1.wait(cpf.similar((float) 0.90), 5).click();
		// Thread.sleep(5000);
		reg1.type(CPF);
		Thread.sleep(2000);
		 reg1.type(TYPE);
		
		if (TYPE.equalsIgnoreCase("CONTROLE PF")) {
			// reg1.type(TYPE);
			Pattern controlepf = new Pattern(
					"D:\\LearnSelenium\\Atlys\\controlepf.png");
			reg1.wait(controlepf.similar((float) 0.80), 180);
			Thread.sleep(2000);
		}

		else if (TYPE.equalsIgnoreCase("PESSOA FISICA")) {
			// reg1.type(TYPE);
			Pattern pessoafisica = new Pattern(
					"D:\\LearnSelenium\\Atlys\\pessoafisica.png");
			reg1.wait(pessoafisica.similar((float) 0.80), 290);
			Thread.sleep(2000);
		}

		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		reg1.type(CSA);

		Pattern csa = new Pattern("D:\\LearnSelenium\\Atlys\\csa.png");
		reg1.wait(csa.similar((float) 0.50), 30);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(PRENOME);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(SOBERNOME);
		Pattern cep = new Pattern("D:\\LearnSelenium\\Atlys\\Adicionarcep.png");
		reg1.wait(cep.similar((float) 0.80), 10).click();
		Pattern cep2 = new Pattern("D:\\LearnSelenium\\Atlys\\cep2.png");
		reg1.wait(cep2.similar((float) 0.80), 30);
		reg1.type("06278300");
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(5000);
		reg1.type("12");
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(2000);
		Pattern Avaliar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Avaliarcredito.png");
		reg1.wait(Avaliar.similar((float) 0.90), 20).click();
		Pattern duplicate = new Pattern(
				"D:\\LearnSelenium\\Atlys\\duplicate.png");
		// reg1.wait(duplicate.similar((float) 0.90), 5);

		if (reg1.exists(duplicate, 5) != null) {
			Pattern ignorar = new Pattern(
					"D:\\LearnSelenium\\Atlys\\ignorar.png");
			reg1.wait(ignorar.similar((float) 0.90), 20).click();
		} else {
			System.out.println("Name is ok");
		}
		Pattern suspender = new Pattern(
				"D:\\LearnSelenium\\Atlys\\suspenderverificao.png");
		reg1.wait(suspender.similar((float) 0.80), 30).click();
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(4000);
		Pattern Demograficos = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Demograficos.png");
		reg1.wait(Demograficos.similar((float) 0.90), 90).click();
		Pattern ref = new Pattern("D:\\LearnSelenium\\Atlys\\ref2.png");
		reg1.wait(ref.similar((float) 0.90), 30);
		Region reg2 = s.find(ref).grow(10, 330, 5, 350);
		reg2.highlight(2);
		Pattern nascimento = new Pattern(
				"D:\\LearnSelenium\\Atlys\\nascimento.png");
		reg2.wait(nascimento.similar((float) 0.90), 50).click();
		reg2.type("17031996");
		Thread.sleep(1000);
		
		reg2.wait(ok2.similar((float) 0.90), 30).click();
		Pattern Attributos = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Attributos.png");
		s.wait(Attributos.similar((float) 0.90), 60).click();
		// Thread.sleep(5000);
		Pattern pesquisar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\pesquisar.png");
		s.wait(pesquisar.similar((float) 0.60), 60).click();
		Thread.sleep(2000);
		Pattern ref9 = new Pattern("D:\\LearnSelenium\\Atlys\\ref9.png");
		s.wait(ref9.similar((float) 0.90), 30);
		Region reg3 = s.find(ref9).grow(1, 430, 5, 250);

		reg3.highlight(1);
		reg3.type(Key.TAB);
		// Pattern nome = new Pattern("D:\\LearnSelenium\\Atlys\\nome.png");
		// reg3.wait(nome.similar((float) 0.90), 30).click();
		reg3.type("ATLYS");
		reg3.type(Key.TAB);
		reg3.type(Key.TAB);
		reg3.type(Key.ENTER);
		Pattern ref10 = new Pattern("D:\\LearnSelenium\\Atlys\\ref10.png");
		s.wait(ref10.similar((float) 0.90), 30);
		Region reg4 = s.find(ref10).grow(1, 430, 5, 250);
		reg4.highlight(2);
		reg4.wait(ok2.similar((float) 0.70), 30).click();
		Pattern ref11 = new Pattern("D:\\LearnSelenium\\Atlys\\ref11.png");
		s.wait(ref11.similar((float) 0.90), 30);
		Region reg5 = s.find(ref11).grow(1, 80, 5, 100);
		reg5.highlight(2);
		reg5.wait(ok2.similar((float) 0.70), 30).click();
		// s.wait(ok2.similar((float) 0.80), 30).click();
		// Pattern ok3 = new Pattern("D:\\LearnSelenium\\Atlys\\ok3.png");
		reg1.wait(ok2.similar((float) 0.90), 30).click();
		
		
	}
		
   public static void Add_Conta() throws FindFailed, InterruptedException,IOException{
		Pattern conta = new Pattern("D:\\LearnSelenium\\Atlys\\Adiconta.png");
		s.wait(conta.similar((float) 0.80), 30).click();
		Pattern ref2 = new Pattern("D:\\LearnSelenium\\Atlys\\refconta.png");
		s.wait(ref2.similar((float) 0.80), 180);
		Region reg6 = s.find(ref2).grow(1, 950, 5, 600);
		reg6.highlight(1);

		Pattern funcoes = new Pattern("D:\\LearnSelenium\\Atlys\\funcoesassinatura.png");
		s.wait(funcoes.similar((float) 0.70), 60).click();
		Thread.sleep(3000);
		s.type(Key.DOWN);
		s.type(Key.ENTER);
	}
		
	public static void Add_Plan(String PLAN_TYPE, String PLAN) throws FindFailed, InterruptedException,IOException{
		
		Pattern refplan = new Pattern("D:\\LearnSelenium\\Atlys\\refplan.png");
		s.wait(refplan.similar((float) 0.90), 180);
		s.type(PLAN_TYPE);
		Thread.sleep(5000);
		s.type(Key.TAB);
		s.type(PLAN);
		s.type(Key.TAB);
		s.type(Key.DOWN);
		s.type(Key.TAB);
		// s.type(Key.TAB);
		s.type(Key.ENTER);
		Pattern selectplan = new Pattern("D:\\LearnSelenium\\Atlys\\selectplan.png");
		s.wait(selectplan.similar((float) 0.70), 10);
		Region plan1 = s.find(selectplan).offset(9, 68);
		plan1.highlight(2);
		Thread.sleep(3000);
		plan1.click();
		Thread.sleep(2000);
		Pattern addplan = new Pattern("D:\\LearnSelenium\\Atlys\\addplan.png");
		s.wait(addplan.similar((float) 0.70), 30).click();
		Pattern ref14 = new Pattern("D:\\LearnSelenium\\Atlys\\ref14.png");
		if (s.exists(ref14, 60) != null) {
			Region regx = s.find(ref14).grow(1, 100, 1, 300);
			regx.highlight(1);
			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
			regx.wait(ok2.similar((float) 0.90), 90).click();
		} else {
			System.out.println("Pattern not found");
		}

		
		s.wait(ref8.similar((float) 0.70), 120);
		Region reg8 = s.find(ref8).grow(1, 200, 1, 300);
		reg8.highlight(1);
		 Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
		reg8.wait(ok2.similar((float) 0.90), 90).click();
		Thread.sleep(5000);
		if (s.exists(ref8, 3) != null) {
			Thread.sleep(7000);

		}
          
		Pattern reftipo = new Pattern("D:\\LearnSelenium\\Atlys\\reftipo.png");
		s.wait(reftipo.similar((float) 0.80), 30);
		Region fatura = s.find(reftipo).offset(60, 30);
		// fatura.highlight(1);
		fatura.doubleClick();
		s.type("Tipo De Fatura");

		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		Thread.sleep(2000);
		s.type(Key.ENTER);
		Thread.sleep(3000);
		// plan1.highlight(1);
		// Thread.sleep(2000);
		plan1.click();
		Thread.sleep(1000);
		s.wait(addplan.similar((float) 0.70), 30).click();
		Thread.sleep(2000);
		s.wait(ok2.similar((float) 0.90), 30).click();
		Thread.sleep(5000);
		// Pattern cmparef = new
		// Pattern("D:\\LearnSelenium\\Atlys\\cmparef.png");
		// s.dragDrop(cmparef, plan1);

		Pattern cmpa = new Pattern("D:\\LearnSelenium\\Atlys\\cmpa.png");
		s.wait(cmpa.similar((float) 0.70), 40).click();
		s.type(Key.TAB);
		Thread.sleep(3000);
		s.type(Key.ENTER);
		Thread.sleep(5000);
	}
		
	public static void Habiliticao_Line(String ICCID, String LINHA) throws FindFailed, InterruptedException,IOException{
			
			Pattern ref3 = new Pattern("D:\\LearnSelenium\\Atlys\\configuracaoref.png");
			s.wait(ref3.similar((float) 0.90), 180);
			s.wait(ok2.similar((float) 0.50), 30).click();
		//	Thread.sleep(2000);
			Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
			/*try {
				s.wait(continuar.similar((float) 0.70), 5);
			} catch (Exception e) {
				System.out.println("warning statement in try block");
			}
			if (s.exists(continuar, 7) != null) {
				s.type(Key.ENTER);
			}
*/
			Pattern Nao = new Pattern("D:\\LearnSelenium\\Atlys\\Nao.png");
			s.wait(Nao.similar((float) 0.80), 90).click();
			Pattern Servicoref = new Pattern("D:\\LearnSelenium\\Atlys\\Servicoref.png");
			s.wait(Servicoref.similar((float) 0.80), 150);
			Pattern iccid = new Pattern("D:\\LearnSelenium\\Atlys\\iccid.png");
			s.wait(iccid.similar((float) 0.80), 90).click();
			s.type(ICCID);
			Thread.sleep(2000);
			s.type(Key.TAB);
			s.type(Key.ENTER);
			Pattern ref13 = new Pattern("D:\\LearnSelenium\\Atlys\\ref13.png");
			s.wait(ref13.similar((float) 0.80), 180);
			s.wait(ok2.similar((float) 0.50), 30).click();
			//Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
			s.wait(continuar.similar((float) 0.80), 90).click();
			Pattern lineref = new Pattern("D:\\LearnSelenium\\Atlys\\lineref.png");
			s.wait(lineref.similar((float) 0.80), 180);
			Thread.sleep(1000);
			s.type(LINHA);
			s.type(Key.TAB);
			s.wait(ok2.similar((float) 0.50), 30).click();

			if (s.exists(ref8, 20) != null) {
				Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
				reg8a.highlight(1);
				reg8a.wait(ok2.similar((float) 0.90), 30).click();
			}
			Pattern ref19 = new Pattern("D:\\LearnSelenium\\Atlys\\ref19.png");
			s.wait(ref19.similar((float) 0.80), 180);
			Region reg9 = s.find(ref19).grow(1, 100, 1, 330);
			reg9.highlight(1);
			Pattern getconta = new Pattern("D:\\LearnSelenium\\Atlys\\conta1.png");
			s.wait(getconta.similar((float) 0.70), 30);
			// Region reg = s.find(getconta).grow(-10, 190, 1, 8);
			// reg.highlight(1);
			String Conta = s.find(getconta).right(65).text();
			System.out.println(Conta);
			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
			reg9.wait(ok2.similar((float) 0.70), 30).click();
			Pattern ref20 = new Pattern("D:\\LearnSelenium\\Atlys\\ref20.png");
			s.wait(ref20.similar((float) 0.80), 180);
			Region reg9a = s.find(ref20).grow(1, 100, 1, 150);
			reg9a.highlight(1);
			reg9a.wait(ok2.similar((float) 0.70), 30).click();
			Pattern ref17 = new Pattern("D:\\LearnSelenium\\Atlys\\ref17.png");
			s.wait(ref17.similar((float) 0.80), 180);

			Region reg10 = s.find(ref17).grow(1, 100, 1, 200);
			reg10.highlight(1);
			Pattern getline = new Pattern("D:\\LearnSelenium\\Atlys\\getline.png");
			s.wait(getline.similar((float) 0.90), 10);
			// Region regz = s.find(getline).grow(-10, 135, 1, 10);
			// regz.highlight(1);
			String Linha = s.find(getline).right(100).text();
			System.out.println(Linha);
			Pattern ok5 = new Pattern("D:\\LearnSelenium\\Atlys\\ok5.png");
			reg10.wait(ok5.similar((float) 0.70), 30).click();
			DataProviderClient.writeDataInExcel1(Linha, Conta, i);
			Pattern refx = new Pattern("D:\\LearnSelenium\\Atlys\\refx.png");
			s.wait(refx.similar((float) 0.90), 60);
			//s.type(Key.TAB);
		}
	
	public static void Habilitacao_Multi_Line(String ICCID, String LINHA) throws FindFailed, InterruptedException, IOException{
		Pattern ref3 = new Pattern("D:\\LearnSelenium\\Atlys\\configuracaoref.png");
		s.wait(ref3.similar((float) 0.90), 180);
		s.wait(ok2.similar((float) 0.50), 30).click();
		Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
		try {
			s.wait(continuar.similar((float) 0.70), 5);
		} catch (Exception e) {
			System.out.println("warning statement in try block");
		}
		if (s.exists(continuar, 7) != null) {
			s.type(Key.ENTER);
		}

		Pattern Nao = new Pattern("D:\\LearnSelenium\\Atlys\\Nao.png");
		s.wait(Nao.similar((float) 0.80), 90).click();
		Pattern Servicoref = new Pattern("D:\\LearnSelenium\\Atlys\\Servicoref.png");
		s.wait(Servicoref.similar((float) 0.80), 150);
		Pattern iccid = new Pattern("D:\\LearnSelenium\\Atlys\\iccid.png");
		s.wait(iccid.similar((float) 0.80), 90).click();
		s.type(ICCID);
		Thread.sleep(2000);
		s.type(Key.TAB);
		s.type(Key.ENTER);
		Pattern ref13 = new Pattern("D:\\LearnSelenium\\Atlys\\ref13.png");
		s.wait(ref13.similar((float) 0.80), 180);
		s.wait(ok2.similar((float) 0.50), 30).click();
	//	Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
		s.wait(continuar.similar((float) 0.80), 90).click();
		Pattern lineref = new Pattern("D:\\LearnSelenium\\Atlys\\lineref.png");
		s.wait(lineref.similar((float) 0.80), 180);
		Thread.sleep(1000);
		s.type(LINHA);
		s.type(Key.TAB);
		s.wait(ok2.similar((float) 0.50), 30).click();

		if (s.exists(ref8, 20) != null) {
			Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
			reg8a.highlight(1);
			reg8a.wait(ok2.similar((float) 0.90), 30).click();
		}
		Pattern ref19 = new Pattern("D:\\LearnSelenium\\Atlys\\ref19.png");
		s.wait(ref19.similar((float) 0.80), 180);
		Region reg9 = s.find(ref19).grow(1, 100, 1, 330);
		reg9.highlight(1);
		Pattern getconta = new Pattern("D:\\LearnSelenium\\Atlys\\conta1.png");
		s.wait(getconta.similar((float) 0.70), 30);
		// Region reg = s.find(getconta).grow(-10, 190, 1, 8);
		// reg.highlight(1);
		String Conta = s.find(getconta).right(65).text();
		System.out.println(Conta);
		// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
		reg9.wait(ok2.similar((float) 0.70), 30).click();
		Pattern ref20 = new Pattern("D:\\LearnSelenium\\Atlys\\ref20.png");
		s.wait(ref20.similar((float) 0.80), 180);
		Region reg9a = s.find(ref20).grow(1, 100, 1, 150);
		reg9a.highlight(1);
		reg9a.wait(ok2.similar((float) 0.70), 30).click();
		Pattern ref17 = new Pattern("D:\\LearnSelenium\\Atlys\\ref17.png");
		s.wait(ref17.similar((float) 0.80), 180);

		Region reg10 = s.find(ref17).grow(1, 100, 1, 200);
		reg10.highlight(1);
		Pattern getline = new Pattern("D:\\LearnSelenium\\Atlys\\getline.png");
		s.wait(getline.similar((float) 0.90), 10);
		// Region regz = s.find(getline).grow(-10, 135, 1, 10);
		// regz.highlight(1);
		String Linha = s.find(getline).right(100).text();
		System.out.println(Linha);
		Pattern ok5 = new Pattern("D:\\LearnSelenium\\Atlys\\ok5.png");
		reg10.wait(ok5.similar((float) 0.70), 30).click();
		DataProviderMultivivo.writeDataInExcel1(Linha, Conta, i); 
		Pattern refx = new Pattern("D:\\LearnSelenium\\Atlys\\refx.png");
		s.wait(refx.similar((float) 0.90), 60);
	}
	
	public static void Multivivo_Plan(String PLAN_TYPE, String PLAN) throws InterruptedException, FindFailed{
		Pattern refplan = new Pattern("D:\\LearnSelenium\\Atlys\\refplan.png");
		s.wait(refplan.similar((float) 0.90), 180);
		s.type(PLAN_TYPE);
		Thread.sleep(5000);
		s.type(Key.TAB);
		s.type(PLAN);
		s.type(Key.TAB);
		s.type(Key.DOWN);
		s.type(Key.TAB);
		// s.type(Key.TAB);
		s.type(Key.ENTER);
		Pattern selectplan = new Pattern("D:\\LearnSelenium\\Atlys\\selectplan.png");
		s.wait(selectplan.similar((float) 0.70), 10);
		Region plan1 = s.find(selectplan).offset(9, 68);
		plan1.highlight(2);
		Thread.sleep(3000);
		plan1.click();
		Thread.sleep(2000);
		Pattern addplan = new Pattern("D:\\LearnSelenium\\Atlys\\addplan.png");
		s.wait(addplan.similar((float) 0.70), 30).click();
		Pattern ref14 = new Pattern("D:\\LearnSelenium\\Atlys\\ref14.png");
		if (s.exists(ref14, 60) != null) {
			Region regx = s.find(ref14).grow(1, 100, 1, 300);
			regx.highlight(1);
			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
			regx.wait(ok2.similar((float) 0.90), 90).click();
		} else {
			System.out.println("Pattern not found");
		}

		
		s.wait(ref8.similar((float) 0.70), 120);
		Region reg8 = s.find(ref8).grow(1, 200, 1, 300);
		reg8.highlight(1);
		 Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
		reg8.wait(ok2.similar((float) 0.90), 90).click();
		Thread.sleep(5000);
		if (s.exists(ref8, 3) != null) {
			Thread.sleep(7000);

		}
          
		Pattern reftipo = new Pattern("D:\\LearnSelenium\\Atlys\\reftipo.png");
		s.wait(reftipo.similar((float) 0.80), 30);
		Region fatura = s.find(reftipo).offset(60, 30);
		// fatura.highlight(1);
		fatura.doubleClick();
		s.type("DADOS");
		s.type(Key.TAB);
		s.type("SMART INTERNET COMPARTILHADA");
		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.ENTER);
		Thread.sleep(3000);
		plan1.click();
		Thread.sleep(1000);
		s.wait(addplan.similar((float) 0.70), 4).click();
		Thread.sleep(1000);
		fatura.doubleClick();
		s.type("Tipo De Fatura");
	    s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		Thread.sleep(2000);
		s.type(Key.ENTER);
		Thread.sleep(3000);
		// plan1.highlight(1);
		// Thread.sleep(2000);
		plan1.click();
		Thread.sleep(1000);
		s.wait(addplan.similar((float) 0.70), 30).click();
		Thread.sleep(2000);
		s.wait(ok2.similar((float) 0.90), 30).click();
		Thread.sleep(5000);
		// Pattern cmparef = new
		// Pattern("D:\\LearnSelenium\\Atlys\\cmparef.png");
		// s.dragDrop(cmparef, plan1);

		Pattern cmpa = new Pattern("D:\\LearnSelenium\\Atlys\\cmpa.png");
		s.wait(cmpa.similar((float) 0.70), 40).click();
		s.type(Key.TAB);
		Thread.sleep(3000);
		s.type(Key.ENTER);
		Thread.sleep(7000);
	}

    public static void Add_Dependente() throws FindFailed, InterruptedException{
    	
    	Pattern visualizar = new Pattern("D:\\LearnSelenium\\Atlys\\visualizar.png");
		s.wait(visualizar.similar((float) 0.80), 40).click();
		Pattern ref2 = new Pattern("D:\\LearnSelenium\\Atlys\\refconta.png");
		s.wait(ref2.similar((float) 0.90), 180);
		Pattern dependent = new Pattern("D:\\LearnSelenium\\Atlys\\dependent.png");
		s.wait(dependent.similar((float) 0.80), 30).click();
		Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
		s.wait(continuar.similar((float) 0.80), 90);
		s.type(Key.ENTER);
		Pattern depcheck = new Pattern("D:\\LearnSelenium\\Atlys\\depcheck.png");
		s.wait(depcheck.similar((float) 0.90), 30);
		Region reg6 = s.find(ref2).grow(1, 950, 5, 600);
		Pattern assinaturas = new Pattern("D:\\LearnSelenium\\Atlys\\assinaturas.png");
		reg6.wait(assinaturas.similar((float) 0.80), 30).click();
		Pattern ref21 = new Pattern("D:\\LearnSelenium\\Atlys\\ref21.png");
		s.wait(ref21.similar((float) 0.90), 180);
		s.type(Key.TAB);
		s.type(Key.ENTER);
		Pattern funcoes = new Pattern("D:\\LearnSelenium\\Atlys\\funcoesassinatura.png");
		s.wait(funcoes.similar((float) 0.70), 90).click();
		Thread.sleep(3000);
		s.type(Key.DOWN);
		s.type(Key.ENTER);
    	
    	
    }

      public static void Multi_Dependent_Plan(String Plan_2) throws FindFailed, InterruptedException{
    	  Pattern refplan = new Pattern("D:\\LearnSelenium\\Atlys\\refplan.png");
  		s.wait(refplan.similar((float) 0.90), 180);
  		s.type("NOVOS PLANOS E VANTAGENS POS");
  		Thread.sleep(3000);
  		s.type(Key.TAB);
  		s.type(Plan_2);
  		s.type(Key.TAB);
  		s.type(Key.DOWN);
  		s.type(Key.TAB);
  		// s.type(Key.TAB);
  		s.type(Key.ENTER);
  		Pattern selectplan = new Pattern("D:\\LearnSelenium\\Atlys\\selectplan.png");
  		s.wait(selectplan.similar((float) 0.70), 10);
  		Region plan1 = s.find(selectplan).offset(9, 68);
  		plan1.highlight(2);
  		Thread.sleep(3000);
  		plan1.click();
  		Thread.sleep(2000);
  		Pattern addplan = new Pattern("D:\\LearnSelenium\\Atlys\\addplan.png");
  		s.wait(addplan.similar((float) 0.70), 30).click();
  		s.wait(ref8.similar((float) 0.70), 120);
  		Region reg8 = s.find(ref8).grow(1, 200, 1, 300);
  		reg8.highlight(1);
  		 Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
  		reg8.wait(ok2.similar((float) 0.90), 90).click();
  		Thread.sleep(5000);
  		if (s.exists(ref8, 3) != null) {
  			Thread.sleep(7000);

  		}
            
  		Pattern reftipo = new Pattern("D:\\LearnSelenium\\Atlys\\reftipo.png");
  		s.wait(reftipo.similar((float) 0.80), 30);
  		Region fatura = s.find(reftipo).offset(60, 30);
  		// fatura.highlight(1);
  		fatura.doubleClick();
  		s.type("Tipo De Fatura");

  		s.type(Key.TAB);
  		s.type(Key.TAB);
  		s.type(Key.TAB);
  		Thread.sleep(2000);
  		s.type(Key.ENTER);
  		Thread.sleep(3000);
  		
  		plan1.click();
  		Thread.sleep(1000);
  		s.wait(addplan.similar((float) 0.70), 30).click();
  		Thread.sleep(2000);
  		s.wait(ok2.similar((float) 0.90), 30).click();
  		Thread.sleep(5000);
  		
          Pattern cmpa = new Pattern("D:\\LearnSelenium\\Atlys\\cmpa.png");
  		s.wait(cmpa.similar((float) 0.70), 40).click();
  		s.type(Key.TAB);
  		Thread.sleep(3000);
  		s.type(Key.ENTER);
  		Thread.sleep(5000);
      }

      public static void Habiliticao_Multivivo_Line(String ICCID_2) throws FindFailed, InterruptedException, IOException{
    	  Pattern ref3 = new Pattern("D:\\LearnSelenium\\Atlys\\configuracaoref.png");
			s.wait(ref3.similar((float) 0.90), 180);
			s.wait(ok2.similar((float) 0.50), 30).click();
			Pattern detalhada = new Pattern("D:\\LearnSelenium\\Atlys\\detalhada.png");
			try {
				s.wait(detalhada.similar((float) 0.70), 5);
			} catch (Exception e) {
				System.out.println("warning statement in try block");
			}
			if (s.exists(detalhada, 7) != null) {
				s.type(Key.ENTER);
			}

			Pattern Nao = new Pattern("D:\\LearnSelenium\\Atlys\\Nao.png");
			s.wait(Nao.similar((float) 0.80), 90).click();
			Pattern Servicoref = new Pattern("D:\\LearnSelenium\\Atlys\\Servicoref.png");
			s.wait(Servicoref.similar((float) 0.80), 150);
			Pattern iccid = new Pattern("D:\\LearnSelenium\\Atlys\\iccid.png");
			s.wait(iccid.similar((float) 0.80), 90).click();
			s.type(ICCID_2);
			Thread.sleep(2000);
			s.type(Key.TAB);
			s.type(Key.ENTER);
			Pattern ref13 = new Pattern("D:\\LearnSelenium\\Atlys\\ref13.png");
			s.wait(ref13.similar((float) 0.80), 180);
			s.wait(ok2.similar((float) 0.50), 30).click();
			Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
			s.wait(continuar.similar((float) 0.80), 90).click();
			Pattern lineref = new Pattern("D:\\LearnSelenium\\Atlys\\lineref.png");
			s.wait(lineref.similar((float) 0.80), 180);
			Thread.sleep(1000);
			//s.type("");
			s.type(Key.TAB);
			s.wait(ok2.similar((float) 0.50), 30).click();

			if (s.exists(ref8, 20) != null) {
				Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
				reg8a.highlight(1);
				reg8a.wait(ok2.similar((float) 0.90), 30).click();
			}
			Pattern ref19 = new Pattern("D:\\LearnSelenium\\Atlys\\ref19.png");
			s.wait(ref19.similar((float) 0.80), 180);
			Region reg9 = s.find(ref19).grow(1, 100, 1, 330);
			reg9.highlight(1);
			Pattern getconta = new Pattern("D:\\LearnSelenium\\Atlys\\conta1.png");
			s.wait(getconta.similar((float) 0.70), 30);
			// Region reg = s.find(getconta).grow(-10, 190, 1, 8);
			// reg.highlight(1);
			//String Conta = s.find(getconta).right(65).text();
			//System.out.println(Conta);
			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
			reg9.wait(ok2.similar((float) 0.70), 30).click();
			/*Pattern ref20 = new Pattern("D:\\LearnSelenium\\Atlys\\ref20.png");
			s.wait(ref20.similar((float) 0.80), 180);
			Region reg9a = s.find(ref20).grow(1, 100, 1, 150);
			reg9a.highlight(1);
			reg9a.wait(ok2.similar((float) 0.70), 30).click();*/
			Pattern ref17 = new Pattern("D:\\LearnSelenium\\Atlys\\ref17.png");
			s.wait(ref17.similar((float) 0.80), 180);

			Region reg10 = s.find(ref17).grow(1, 100, 1, 200);
			reg10.highlight(1);
			Pattern getline = new Pattern("D:\\LearnSelenium\\Atlys\\getline.png");
			s.wait(getline.similar((float) 0.90), 10);
			// Region regz = s.find(getline).grow(-10, 135, 1, 10);
			// regz.highlight(1);
			String Linha_2 = s.find(getline).right(100).text();
			System.out.println(Linha_2);
			Pattern ok5 = new Pattern("D:\\LearnSelenium\\Atlys\\ok5.png");
			reg10.wait(ok5.similar((float) 0.70), 30).click();
			DataProviderMultivivo.writeDependent(Linha_2, i);
			Pattern refx = new Pattern("D:\\LearnSelenium\\Atlys\\refx.png");
			s.wait(refx.similar((float) 0.90), 60);
      }

      
      public static void Client_Funcionario(String TYPE,String CPF, String PRENOME,String SOBERNOME, String CSA) throws FindFailed, InterruptedException{
    	  Pattern Adicionar = new Pattern("D:\\LearnSelenium\\Atlys\\Adicionarcliente.png");
  		s.wait(Adicionar.similar((float) 0.90), 100).click();
  		Pattern ref1 = new Pattern("D:\\LearnSelenium\\Atlys\\ref1.png");
  		s.wait(ref1.similar((float) 0.90), 30);
  		Region reg1 = s.find(ref1).grow(5, 700, 5, 1000);
  		reg1.highlight(2);
  		Pattern cpf = new Pattern("D:\\LearnSelenium\\Atlys\\cpf.png");
  		reg1.wait(cpf.similar((float) 0.90), 5).click();
  		// Thread.sleep(5000);
  		reg1.type(CPF);
  		Thread.sleep(2000);
  		 reg1.type(TYPE);
  		
  		if (TYPE.equalsIgnoreCase("CONTROLE PF")) {
  			// reg1.type(TYPE);
  			Pattern controlepf = new Pattern(
  					"D:\\LearnSelenium\\Atlys\\controlepf.png");
  			reg1.wait(controlepf.similar((float) 0.80), 180);
  			Thread.sleep(2000);
  		}

  		else if (TYPE.equalsIgnoreCase("PESSOA FISICA")) {
  			// reg1.type(TYPE);
  			Pattern pessoafisica = new Pattern("D:\\LearnSelenium\\Atlys\\pessoafisica.png");
  			reg1.wait(pessoafisica.similar((float) 0.80), 290);
  			Thread.sleep(2000);
  		}
  		
  		else if (TYPE.equalsIgnoreCase("FUNCIONARIO VIVO")){
  			
  			Pattern funcionario = new Pattern("D:\\LearnSelenium\\Atlys\\funcionario.png");
  			reg1.wait(funcionario.similar((float) 0.70), 290);
  			Thread.sleep(2000);
  			
  		}

  		s.type(Key.TAB);
  		s.type(Key.TAB);
  		s.type(Key.TAB);
  		reg1.type(CSA);

  		Pattern csa = new Pattern("D:\\LearnSelenium\\Atlys\\csa.png");
  		reg1.wait(csa.similar((float) 0.50), 30);
  		reg1.type(Key.TAB);
  		reg1.type(Key.TAB);
  		reg1.type(Key.TAB);
  		reg1.type(PRENOME);
  		reg1.type(Key.TAB);
  		reg1.type(Key.TAB);
  		reg1.type(SOBERNOME);
  		Pattern cep = new Pattern("D:\\LearnSelenium\\Atlys\\Adicionarcep.png");
  		reg1.wait(cep.similar((float) 0.80), 10).click();
  		Pattern cep2 = new Pattern("D:\\LearnSelenium\\Atlys\\cep2.png");
  		reg1.wait(cep2.similar((float) 0.80), 30);
  		reg1.type("06278300");
  		reg1.type(Key.TAB);
  		reg1.type(Key.ENTER);
  		Thread.sleep(4000);
  		reg1.type("12");
  		reg1.type(Key.TAB);
  		reg1.type(Key.TAB);
  		reg1.type(Key.TAB);
  		reg1.type(Key.ENTER);
  		Pattern adicionar = new Pattern("D:\\LearnSelenium\\Atlys\\adicionar.png");
  		s.wait(adicionar.similar((float) 0.80), 20).click();
  		Pattern wait = new Pattern("D:\\LearnSelenium\\Atlys\\wait.png");
  		s.wait(wait.similar((float) 0.80), 20);
  		s.type(Key.TAB);
  		s.type("0000000000");
  		s.type(Key.TAB);
  		s.type(Key.ENTER);
  		
  		Thread.sleep(4000);
  		Pattern Avaliar = new Pattern("D:\\LearnSelenium\\Atlys\\Avaliarcredito.png");
  		reg1.wait(Avaliar.similar((float) 0.90), 20).click();
  		Pattern duplicate = new Pattern("D:\\LearnSelenium\\Atlys\\duplicate.png");
  		// reg1.wait(duplicate.similar((float) 0.90), 5);

  		if (reg1.exists(duplicate, 5) != null) {
  			Pattern ignorar = new Pattern(
  					"D:\\LearnSelenium\\Atlys\\ignorar.png");
  			reg1.wait(ignorar.similar((float) 0.90), 20).click();
  		} else {
  			System.out.println("Name is ok");
  		}
  		Pattern suspender = new Pattern(
  				"D:\\LearnSelenium\\Atlys\\suspenderverificao.png");
  		reg1.wait(suspender.similar((float) 0.80), 30).click();
  		reg1.type(Key.TAB);
  		reg1.type(Key.ENTER);
  		Thread.sleep(4000);
  		Pattern Demograficos = new Pattern(
  				"D:\\LearnSelenium\\Atlys\\Demograficos.png");
  		reg1.wait(Demograficos.similar((float) 0.90), 90).click();
  		Pattern ref = new Pattern("D:\\LearnSelenium\\Atlys\\ref2.png");
  		reg1.wait(ref.similar((float) 0.90), 30);
  		Region reg2 = s.find(ref).grow(10, 330, 5, 350);
  		reg2.highlight(2);
  		Pattern nascimento = new Pattern(
  				"D:\\LearnSelenium\\Atlys\\nascimento.png");
  		reg2.wait(nascimento.similar((float) 0.90), 50).click();
  		reg2.type("17031996");
  		Thread.sleep(1000);
  		
  		reg2.wait(ok2.similar((float) 0.90), 30).click();
  		Pattern Attributos = new Pattern(
  				"D:\\LearnSelenium\\Atlys\\Attributos.png");
  		s.wait(Attributos.similar((float) 0.90), 60).click();
  		// Thread.sleep(5000);
  		Pattern pesquisar = new Pattern(
  				"D:\\LearnSelenium\\Atlys\\pesquisar.png");
  		s.wait(pesquisar.similar((float) 0.60), 60).click();
  		Thread.sleep(2000);
  		Pattern ref9 = new Pattern("D:\\LearnSelenium\\Atlys\\ref9.png");
  		s.wait(ref9.similar((float) 0.90), 30);
  		Region reg3 = s.find(ref9).grow(1, 430, 5, 250);

  		reg3.highlight(1);
  		reg3.type(Key.TAB);
  		// Pattern nome = new Pattern("D:\\LearnSelenium\\Atlys\\nome.png");
  		// reg3.wait(nome.similar((float) 0.90), 30).click();
  		reg3.type("ATLYS");
  		reg3.type(Key.TAB);
  		reg3.type(Key.TAB);
  		reg3.type(Key.ENTER);
  		Pattern ref10 = new Pattern("D:\\LearnSelenium\\Atlys\\ref10.png");
  		s.wait(ref10.similar((float) 0.90), 30);
  		Region reg4 = s.find(ref10).grow(1, 430, 5, 250);
  		reg4.highlight(2);
  		reg4.wait(ok2.similar((float) 0.70), 30).click();
  		Pattern ref11 = new Pattern("D:\\LearnSelenium\\Atlys\\ref11.png");
  		s.wait(ref11.similar((float) 0.90), 30);
  		Region reg5 = s.find(ref11).grow(1, 80, 5, 100);
  		reg5.highlight(2);
  		reg5.wait(ok2.similar((float) 0.70), 30).click();
  		// s.wait(ok2.similar((float) 0.80), 30).click();
  		// Pattern ok3 = new Pattern("D:\\LearnSelenium\\Atlys\\ok3.png");
  		reg1.wait(ok2.similar((float) 0.90), 30).click();
  		
    	  
      }

     public static void Plano_Funcionario(String PLAN_TYPE, String PLAN) throws FindFailed, InterruptedException{
    	 Pattern refplan = new Pattern("D:\\LearnSelenium\\Atlys\\refplan.png");
 		s.wait(refplan.similar((float) 0.90), 180);
 		s.type(PLAN_TYPE);
 		Thread.sleep(5000);
 		s.type(Key.TAB);
 		s.type(PLAN);
 		s.type(Key.TAB);
 		s.type(Key.DOWN);
 		s.type(Key.TAB);
 		// s.type(Key.TAB);
 		s.type(Key.ENTER);
 		Pattern selectplan = new Pattern("D:\\LearnSelenium\\Atlys\\selectplan.png");
 		s.wait(selectplan.similar((float) 0.70), 10);
 		Region plan1 = s.find(selectplan).offset(9, 68);
 		plan1.highlight(2);
 		Thread.sleep(3000);
 		plan1.click();
 		Thread.sleep(2000);
 		Pattern addplan = new Pattern("D:\\LearnSelenium\\Atlys\\addplan.png");
 		s.wait(addplan.similar((float) 0.70), 30).click();
 		/*Pattern ref14 = new Pattern("D:\\LearnSelenium\\Atlys\\ref14.png");
 		if (s.exists(ref14, 60) != null) {
 			Region regx = s.find(ref14).grow(1, 100, 1, 300);
 			regx.highlight(1);
 			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
 			regx.wait(ok2.similar((float) 0.90), 90).click();
 		} else {
 			System.out.println("Pattern not found");
 		}*/

 		
 		s.wait(ref8.similar((float) 0.70), 120);
 		Region reg8 = s.find(ref8).grow(1, 200, 1, 300);
 		reg8.highlight(1);
 		 Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
 		reg8.wait(ok2.similar((float) 0.90), 90).click();
 		Thread.sleep(5000);
 		if (s.exists(ref8, 3) != null) {
 			Thread.sleep(7000);

 		}
           
 		Pattern reftipo = new Pattern("D:\\LearnSelenium\\Atlys\\reftipo.png");
 		s.wait(reftipo.similar((float) 0.80), 30);
 		Region fatura = s.find(reftipo).offset(60, 30);
 		// fatura.highlight(1);
 		fatura.doubleClick();
 		s.type("SERVICOS EVENTUAIS");
 		s.type(Key.DOWN);
 		s.type(Key.DOWN);
 		s.type(Key.TAB);
 		s.type("BLOQ-INTERNACIONAL");
 		s.type(Key.TAB);
 		s.type(Key.TAB);
 		s.type(Key.ENTER);
 		Thread.sleep(3000);
 		plan1.click();
 		Thread.sleep(1000);
 		s.wait(addplan.similar((float) 0.70), 4).click();
 		Thread.sleep(1000);
 		fatura.doubleClick();
 		s.type(Key.DOWN);
 		s.type(Key.DOWN);
 		s.type(Key.DOWN);
 		s.type(Key.DOWN);
 		s.type(Key.DOWN);
 		s.type(Key.TAB);
 		s.type("COL");
 		s.type(Key.TAB);
 		s.type(Key.TAB);
 		s.type(Key.ENTER);
 		Thread.sleep(5000);
 		plan1.click();
 		Thread.sleep(1000);
 		s.wait(addplan.similar((float) 0.70), 4).click();
 		Thread.sleep(4000);
 		fatura.doubleClick();
 		s.type("Tipo De Fatura");
 	    s.type(Key.TAB);
 		s.type(Key.TAB);
 		s.type(Key.TAB);
 		Thread.sleep(2000);
 		s.type(Key.ENTER);
 		Thread.sleep(3000);
 		// plan1.highlight(1);
 		// Thread.sleep(2000);
 		plan1.click();
 		Thread.sleep(1000);
 		s.wait(addplan.similar((float) 0.70), 30).click();
 		Thread.sleep(2000);
 		s.wait(ok2.similar((float) 0.90), 30).click();
 		Thread.sleep(5000);
 		// Pattern cmparef = new
 		// Pattern("D:\\LearnSelenium\\Atlys\\cmparef.png");
 		// s.dragDrop(cmparef, plan1);

 		Pattern cmpa = new Pattern("D:\\LearnSelenium\\Atlys\\cmpa.png");
 		s.wait(cmpa.similar((float) 0.70), 40).click();
 		s.type(Key.TAB);
 		Thread.sleep(3000);
 		s.type(Key.ENTER);
 		Thread.sleep(7000);
    	 
     }

      public static void Habilitar_Funcionario(String ICCID, String LINHA) throws FindFailed, InterruptedException, IOException{
    	  Pattern ref3 = new Pattern("D:\\LearnSelenium\\Atlys\\configuracaoref.png");
			s.wait(ref3.similar((float) 0.90), 180);
			s.wait(ok2.similar((float) 0.50), 30).click();
			Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
			try {
				s.wait(continuar.similar((float) 0.70), 5);
			} catch (Exception e) {
				System.out.println("warning statement in try block");
			}
			if (s.exists(continuar, 7) != null) {
				s.type(Key.ENTER);
			}

			Pattern Nao = new Pattern("D:\\LearnSelenium\\Atlys\\Nao.png");
			s.wait(Nao.similar((float) 0.80), 90).click();
			Pattern Servicoref = new Pattern("D:\\LearnSelenium\\Atlys\\Servicoref.png");
			s.wait(Servicoref.similar((float) 0.80), 150);
			Pattern iccid = new Pattern("D:\\LearnSelenium\\Atlys\\iccid.png");
			s.wait(iccid.similar((float) 0.80), 90).click();
			s.type(ICCID);
			Thread.sleep(2000);
			s.type(Key.TAB);
			s.type(Key.ENTER);
			Pattern ref13 = new Pattern("D:\\LearnSelenium\\Atlys\\ref13.png");
			s.wait(ref13.similar((float) 0.80), 180);
			s.wait(ok2.similar((float) 0.50), 30).click();
			//Pattern continuar = new Pattern("D:\\LearnSelenium\\Atlys\\continuar.png");
			s.wait(continuar.similar((float) 0.80), 90).click();
			Pattern lineref = new Pattern("D:\\LearnSelenium\\Atlys\\lineref.png");
			s.wait(lineref.similar((float) 0.80), 180);
			Thread.sleep(1000);
			s.type(LINHA);
			s.type(Key.TAB);
			s.wait(ok2.similar((float) 0.50), 30).click();

			if (s.exists(ref8, 20) != null) {
				Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
				reg8a.highlight(1);
				reg8a.wait(ok2.similar((float) 0.90), 30).click();
			}
			Pattern ref19 = new Pattern("D:\\LearnSelenium\\Atlys\\ref19.png");
			s.wait(ref19.similar((float) 0.80), 180);
			Region reg9 = s.find(ref19).grow(1, 100, 1, 330);
			reg9.highlight(1);
			Pattern getconta = new Pattern("D:\\LearnSelenium\\Atlys\\conta1.png");
			s.wait(getconta.similar((float) 0.70), 30);
			// Region reg = s.find(getconta).grow(-10, 190, 1, 8);
			// reg.highlight(1);
			String Conta = s.find(getconta).right(65).text();
			System.out.println(Conta);
			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
			reg9.wait(ok2.similar((float) 0.70), 30).click();
			Pattern ref20 = new Pattern("D:\\LearnSelenium\\Atlys\\ref20.png");
			s.wait(ref20.similar((float) 0.80), 180);
			Region reg9a = s.find(ref20).grow(1, 100, 1, 150);
			reg9a.highlight(1);
			reg9a.wait(ok2.similar((float) 0.70), 30).click();
			Pattern ref17 = new Pattern("D:\\LearnSelenium\\Atlys\\ref17.png");
			s.wait(ref17.similar((float) 0.80), 180);

			Region reg10 = s.find(ref17).grow(1, 100, 1, 200);
			reg10.highlight(1);
			Pattern getline = new Pattern("D:\\LearnSelenium\\Atlys\\getline.png");
			s.wait(getline.similar((float) 0.90), 10);
			// Region regz = s.find(getline).grow(-10, 135, 1, 10);
			// regz.highlight(1);
			String Linha = s.find(getline).right(100).text();
			System.out.println(Linha);
			Pattern ok5 = new Pattern("D:\\LearnSelenium\\Atlys\\ok5.png");
			reg10.wait(ok5.similar((float) 0.70), 30).click();
			DataProviderFuncionario.writeDataInExcel1(Linha, Conta, i);
			Pattern refx = new Pattern("D:\\LearnSelenium\\Atlys\\refx.png");
			s.wait(refx.similar((float) 0.90), 60);
    	  
      }
}


	

	


