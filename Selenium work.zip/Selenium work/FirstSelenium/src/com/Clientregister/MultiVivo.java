package com.Clientregister;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.DataDriven.DataProviderFuncionario;
import com.DataDriven.DataProviderMultivivo;

import OopsConcept.DataProviderClient;

public class MultiVivo {
	  public static Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
	public  static Pattern ref8 = new Pattern("D:\\LearnSelenium\\Atlys\\ref8.png");
	  public static Screen s = new Screen();
	
	  @BeforeMethod
		public void increment(){
			Testing.increment();
		}	
	  
	  @DataProvider
		public Iterator<Object[]> getTestData() throws IOException {
		//	ArrayList<Object[]> testData = DataProviderClient.getClientFromExcel();
		ArrayList<Object[]> testData = DataProviderMultivivo.getClientFromExcel();
		//	ArrayList<Object[]> testData = DataProviderFuncionario.getClientFromExcel();
			return testData.iterator();
		}
	  
		@Test(dataProvider = "getTestData")
	  public void LineCreation(String CPF, String TYPE, String PRENOME, String SOBERNOME, String CSA,String PLAN,String Plan_2, String PLAN_TYPE,String ICCID,String ICCID_2, String LINHA) throws FindFailed,InterruptedException, IOException{
		  
			//Client Registeration
			Testing.Client_Register(TYPE, CPF, PRENOME, SOBERNOME, CSA);
			
			
			// Adding Conta
			Testing.Add_Conta();
			
			//Add Plan_Multivivo Line
			Testing.Multivivo_Plan(PLAN_TYPE, PLAN);
			
			
			// Habiliticao Line
		//	Testing.Habiliticao_Line(ICCID, LINHA);
			
			//Habiliticao Multivivo Line
			Testing.Habilitacao_Multi_Line(ICCID, LINHA);
		
			//Add Dependente
			Testing.Add_Dependente();
			
			//Add Multi_Dependente Plan
			Testing.Multi_Dependent_Plan(Plan_2);
			
			//Habiliticao Dependent Line
			Testing.Habiliticao_Multivivo_Line(ICCID_2);
			
			
		//Testing.Client_Funcionario(TYPE, CPF, PRENOME, SOBERNOME, CSA);
		
	//	Testing.Add_Conta();
		
	//	Testing.Plano_Funcionario(PLAN_TYPE, PLAN);
		
	//	Testing.Habilitar_Funcionario(ICCID, LINHA);
		

		

	}

}
