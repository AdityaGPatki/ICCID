package com.Clientregister;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.By;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class AddConta {

	public static void main(String[] args) throws FindFailed,
			InterruptedException, IOException {
		Screen s = new Screen();
		Properties prop = new Properties();
		FileInputStream ip = new FileInputStream(
				"D:\\Selenium work\\FirstSelenium\\src\\OopsConcept\\configAtlysproperties");
		prop.load(ip);
		/*
		 * DesktopOptions obj = new DesktopOptions();
		 * obj.setApplicationPath(prop.getProperty("path")); WiniumDriver driver
		 * = new WiniumDriver(new URL("http://localhost:9999"), obj);
		 * Thread.sleep(10000);
		 * driver.findElement(By.id("1002")).sendKeys(prop.getProperty
		 * ("username"));
		 * driver.findElement(By.id("1003")).sendKeys(prop.getProperty
		 * ("password")); driver.findElement(By.id("1")).click();
		 * Thread.sleep(25000); driver.findElement(By.name("Fechar")).click();
		 * 
		 * Pattern ok = new Pattern("D:\\LearnSelenium\\Atlys\\ok.png");
		 * s.wait(ok.similar((float) 0.80), 400).click(); Thread.sleep(5000);
		 * driver.findElement(By.name("Maximizar")).click(); s.type(Key.F4);
		 * Pattern maximizeatlys = new
		 * Pattern("D:\\LearnSelenium\\Atlys\\maximizeatlys.png");
		 * s.wait(maximizeatlys.similar((float) 0.90), 5).click(); Pattern
		 * maximize = new Pattern("D:\\LearnSelenium\\Atlys\\maximize.png");
		 * s.wait(maximize.similar((float) 0.90), 5).click();
		 */
		Pattern Adicionar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Adicionarcliente.png");
		s.wait(Adicionar.similar((float) 0.90), 5).click();
		Pattern ref1 = new Pattern("D:\\LearnSelenium\\Atlys\\ref1.png");
		s.wait(ref1.similar((float) 0.90), 30);
		Region reg1 = s.find(ref1).grow(5, 1000, 5, 1000);
		reg1.highlight(3);
		Pattern cpf = new Pattern("D:\\LearnSelenium\\Atlys\\cpf.png");
		reg1.wait(cpf.similar((float) 0.90), 5).click();
		// Thread.sleep(5000);
		reg1.type(prop.getProperty("cpf"));
		Thread.sleep(3000);
		// s.type(Key.TAB);
		reg1.type("PESSOA FISICA");
		Pattern pessoafisica = new Pattern(
				"D:\\LearnSelenium\\Atlys\\pessoafisica.png");
		reg1.wait(pessoafisica.similar((float) 0.80), 180);
		Thread.sleep(2000);
		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		reg1.type("SPOCENTRO");
		Pattern csa = new Pattern("D:\\LearnSelenium\\Atlys\\csa.png");
		reg1.wait(csa.similar((float) 0.50), 100);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(prop.getProperty("nome"));
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(prop.getProperty("sobernome"));
		Pattern cep = new Pattern("D:\\LearnSelenium\\Atlys\\Adicionarcep.png");
		reg1.wait(cep.similar((float) 0.80), 10).click();
		Pattern cep2 = new Pattern("D:\\LearnSelenium\\Atlys\\cep2.png");
		reg1.wait(cep2.similar((float) 0.80), 20).click();
		reg1.type(prop.getProperty("cep"));
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(5000);
		reg1.type(prop.getProperty("doorno"));
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(2000);
		Pattern Avaliar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Avaliarcredito.png");
		reg1.wait(Avaliar.similar((float) 0.90), 20).click();
		Pattern suspender = new Pattern(
				"D:\\LearnSelenium\\Atlys\\suspenderverificao.png");
		reg1.wait(suspender.similar((float) 0.80), 30).click();
		reg1.type(Key.TAB);
		reg1.type(Key.ENTER);
		Thread.sleep(5000);
		Pattern Demograficos = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Demograficos.png");
		reg1.wait(Demograficos.similar((float) 0.90), 90).click();
		Pattern ref = new Pattern("D:\\LearnSelenium\\Atlys\\ref2.png");
		reg1.wait(ref.similar((float) 0.90), 30);
		Region reg2 = s.find(ref).grow(10, 330, 5, 350);
		reg2.highlight(3);
		Pattern nascimento = new Pattern(
				"D:\\LearnSelenium\\Atlys\\nascimento.png");
		reg2.wait(nascimento.similar((float) 0.90), 50).click();
		reg2.type(prop.getProperty("DOB"));
		Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
		reg2.wait(ok2.similar((float) 0.90), 30).click();
		Pattern Attributos = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Attributos.png");
		reg1.wait(Attributos.similar((float) 0.90), 60).click();
		Thread.sleep(5000);
		Pattern pesquisar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\pesquisar.png");
		s.wait(pesquisar.similar((float) 0.60), 60).click();
		Thread.sleep(2000);
		Pattern ref9 = new Pattern("D:\\LearnSelenium\\Atlys\\ref9.png");
		s.wait(ref9.similar((float) 0.90), 30);
		Region reg3 = s.find(ref9).grow(1, 430, 5, 350);
		reg3.highlight(3);
		Pattern nome = new Pattern("D:\\LearnSelenium\\Atlys\\nome.png");
		reg3.wait(nome.similar((float) 0.90), 30).click();
		reg3.type("ATLYS");
		reg3.type(Key.TAB);
		reg3.type(Key.TAB);
		reg3.type(Key.ENTER);
		Pattern ref10 = new Pattern("D:\\LearnSelenium\\Atlys\\ref10.png");
		s.wait(ref10.similar((float) 0.90), 30);
		Region reg4 = s.find(ref10).grow(1, 430, 5, 250);
		reg4.highlight(3);
		reg4.wait(ok2.similar((float) 0.70), 30).click();
		Pattern ref11 = new Pattern("D:\\LearnSelenium\\Atlys\\ref11.png");
		s.wait(ref11.similar((float) 0.90), 30);
		Region reg5 = s.find(ref11).grow(1, 80, 5, 100);
		reg5.highlight(3);
		reg5.wait(ok2.similar((float) 0.70), 30).click();
		// s.wait(ok2.similar((float) 0.80), 30).click();
		// Pattern ok3 = new Pattern("D:\\LearnSelenium\\Atlys\\ok3.png");
		reg1.wait(ok2.similar((float) 0.90), 30).click();
		Pattern conta = new Pattern("D:\\LearnSelenium\\Atlys\\Adiconta.png");
		s.wait(conta.similar((float) 0.80), 30).click();
		Pattern ref2 = new Pattern("D:\\LearnSelenium\\Atlys\\refconta.png");
		s.wait(ref2.similar((float) 0.80), 180);
		Region reg6 = s.find(ref2).grow(1, 950, 5, 600);
		reg6.highlight(3);
		// Pattern ciclo = new Pattern("D:\\LearnSelenium\\Atlys\\ciclo.png");
		// reg6.wait(ciclo.similar((float) 0.80), 10).click();
		// Pattern ref5 = new Pattern("D:\\LearnSelenium\\Atlys\\ref7.png");
		// s.wait(ref5.similar((float) 0.90), 30);
		// Region reg7 =s.find(ref5).grow(1, 450, 5, 350);
		/*
		 * reg7.highlight(4); reg7.type(Key.TAB); reg7.type(Key.ENTER);
		 * Thread.sleep(2000); reg6.type(Key.TAB); Thread.sleep(3000);
		 * reg6.type(Key.TAB); reg6.type(Key.TAB); reg6.type(Key.TAB);
		 */
		Pattern funcoes = new Pattern(
				"D:\\LearnSelenium\\Atlys\\funcoesassinatura.png");
		s.wait(funcoes.similar((float) 0.70), 60).click();
		Thread.sleep(3000);
		s.type(Key.DOWN);
		s.type(Key.ENTER);
		Pattern refplan = new Pattern("D:\\LearnSelenium\\Atlys\\refplan.png");
		s.wait(refplan.similar((float) 0.90), 180);
		s.type("NOVOS PLANOS E VANTAGENS POS");
		Thread.sleep(7000);
		s.type(Key.TAB);
		s.type("VIVO POS_10GB");
		s.type(Key.TAB);
		s.type(Key.DOWN);
		s.type(Key.TAB);
		// s.type(Key.TAB);
		s.type(Key.ENTER);
		Pattern selectplan = new Pattern(
				"D:\\LearnSelenium\\Atlys\\selectplan.png");
		s.wait(selectplan.similar((float) 0.70), 10);
		Region plan1 = s.find(selectplan).offset(9, 69);
		plan1.highlight(2);
		Thread.sleep(5000);
		plan1.click();
		Thread.sleep(2000);
		Pattern addplan = new Pattern("D:\\LearnSelenium\\Atlys\\addplan.png");
		s.wait(addplan.similar((float) 0.70), 30).click();
		Pattern ref14 = new Pattern("D:\\LearnSelenium\\Atlys\\ref14.png");
		if (s.exists(ref14, 90) != null) {
			Region regx = s.find(ref14).grow(1, 100, 1, 300);
			regx.highlight(1);
			// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
			regx.wait(ok2.similar((float) 0.90), 90).click();
		} else {
			System.out.println("Pattern not found");
		}

		Pattern ref8 = new Pattern("D:\\LearnSelenium\\Atlys\\ref8.png");
		s.wait(ref8.similar((float) 0.70), 120);
		Region reg8 = s.find(ref8).grow(1, 200, 1, 300);
		reg8.highlight(1);
		// Pattern ok2 = new Pattern("D:\\LearnSelenium\\Atlys\\ok2.png");
		reg8.wait(ok2.similar((float) 0.90), 90).click();
		Thread.sleep(3000);

		Pattern reftipo = new Pattern("D:\\LearnSelenium\\Atlys\\reftipo.png");
		s.wait(reftipo.similar((float) 0.80), 30);
		Region fatura = s.find(reftipo).offset(60, 30);
		// fatura.highlight(1);
		fatura.doubleClick();
		s.type("Tipo De Fatura");

		s.type(Key.TAB);
		s.type(Key.TAB);
		s.type(Key.TAB);
		Thread.sleep(2000);
		s.type(Key.ENTER);
		Thread.sleep(4000);
		// plan1.highlight(1);
		// Thread.sleep(2000);
		plan1.click();
		// Thread.sleep(2000);
		s.wait(addplan.similar((float) 0.70), 30).click();
		Thread.sleep(2000);
		s.wait(ok2.similar((float) 0.90), 30).click();
		Thread.sleep(5000);
		// Pattern cmparef = new
		// Pattern("D:\\LearnSelenium\\Atlys\\cmparef.png");
		// s.dragDrop(cmparef, plan1);

		Pattern cmpa = new Pattern("D:\\LearnSelenium\\Atlys\\cmpa.png");
		s.wait(cmpa.similar((float) 0.70), 40).click();
		s.type(Key.TAB);
		Thread.sleep(3000);
		s.type(Key.ENTER);

		Pattern ref3 = new Pattern(
				"D:\\LearnSelenium\\Atlys\\configuracaoref.png");
		s.wait(ref3.similar((float) 0.90), 180);
		s.wait(ok2.similar((float) 0.50), 30).click();
		/*
		 * Pattern ref15 = new Pattern("D:\\LearnSelenium\\Atlys\\ref15.png");
		 * if(s.exists(ref15, 10)!= null){ s.type(Key.ENTER); }
		 */
		Pattern continuar = new Pattern(
				"D:\\LearnSelenium\\Atlys\\continuar.png");
		s.wait(continuar.similar((float) 0.50), 180);
		// Region reg15 = s.find(ref15).grow(1, 450, 1, 150);

		Pattern Nao = new Pattern("D:\\LearnSelenium\\Atlys\\Nao.png");
		s.wait(Nao.similar((float) 0.80), 90).click();
		Pattern Servicoref = new Pattern(
				"D:\\LearnSelenium\\Atlys\\Servicoref.png");
		s.wait(Servicoref.similar((float) 0.80), 150);
		Pattern iccid = new Pattern("D:\\LearnSelenium\\Atlys\\iccid.png");
		s.wait(iccid.similar((float) 0.80), 90).click();
		s.type("89551010102000548899");
		Thread.sleep(2000);
		s.type(Key.TAB);
		s.type(Key.ENTER);
		Pattern ref13 = new Pattern("D:\\LearnSelenium\\Atlys\\ref13.png");
		s.wait(ref13.similar((float) 0.80), 180);
		s.wait(ok2.similar((float) 0.50), 30).click();

		s.wait(continuar.similar((float) 0.80), 90).click();
		Pattern lineref = new Pattern("D:\\LearnSelenium\\Atlys\\lineref.png");
		s.wait(lineref.similar((float) 0.80), 180);
		s.type(Key.TAB);
		s.wait(ok2.similar((float) 0.50), 30).click();

		s.wait(ref8.similar((float) 0.70), 30);
		Region reg8a = s.find(ref8).grow(1, 200, 1, 300);
		reg8a.highlight(1);
		reg8a.wait(ok2.similar((float) 0.90), 30).click();
		Pattern ref16 = new Pattern("D:\\LearnSelenium\\Atlys\\ref16.png");
		s.wait(ref16.similar((float) 0.80), 180);
		Region reg9 = s.find(ref16).grow(1, 100, 1, 500);
		reg9.highlight(1);
		reg9.wait(ok2.similar((float) 0.70), 30).click();
		Pattern ref18 = new Pattern("D:\\LearnSelenium\\Atlys\\ref18.png");
		s.wait(ref18.similar((float) 0.80), 180);
		s.wait(ok2.similar((float) 0.60), 30).click();
		Pattern ref17 = new Pattern("D:\\LearnSelenium\\Atlys\\ref17.png");
		s.wait(ref17.similar((float) 0.80), 180);
		Pattern ref19 = new Pattern("D:\\LearnSelenium\\Atlys\\ref19.png");
		s.wait(ref19.similar((float) 0.80), 180);
		Region reg10 = s.find(ref19).grow(1, 100, 1, 350);
		reg9.highlight(1);
		Pattern ok5 = new Pattern("D:\\LearnSelenium\\Atlys\\ok5.png");
		reg10.wait(ok5.similar((float) 0.80), 180).click();

	}

}
