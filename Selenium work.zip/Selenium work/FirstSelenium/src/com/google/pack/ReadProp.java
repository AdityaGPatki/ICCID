package com.google.pack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadProp {
	static WebDriver driver;

	public static void main(String[] args) throws IOException {
		// how to read properties file
		Properties prop = new Properties();
		// we need to create another object of FileInputStream class
		FileInputStream ip = new FileInputStream(
				"D:/Selenium work/FirstSelenium/src/com/google/pack/configProperties");
		// now we need to give path of the property file.
		prop.load(ip); // this is making a connection between java code and
						// config file.
		System.out.println(prop.getProperty("browser"));
		String browser = prop.getProperty("browser");

		if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"D:\\Jagdeep\\Selenium\\chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.out.println("I will come again");
		}

		driver.get(prop.getProperty("url"));

	}

}
