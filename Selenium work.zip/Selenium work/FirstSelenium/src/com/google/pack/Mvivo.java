package com.google.pack;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Mvivo {
      static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver",
				"D:\\Jagdeep\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.get("http://vivo360-preprod-qa.redecorp.br/vivo360/pages/crux/login/login.html");
		Thread.sleep(5000);
		driver.findElement(By.id("usuarioTextBox")).sendKeys("c_qneto"); // c_lpinho
		driver.findElement(By.id("senhaTextBox")).sendKeys("jogador252"); // Vivo@15
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(8000);
		driver.switchTo().frame(1);
		WebElement ele2 = driver.findElement(By
				.xpath("//button[@id='continuarButton']"));
		// button[contains(@id,'continuarButton'
		ele2.click();
		// clickElementByJS(driver, ele2);
		driver.navigate().refresh();
		Thread.sleep(30000);
		WebElement ele = driver.findElement(By
				.xpath("//select[@id='grupoListBox']"));
		Select sel = new Select(ele);
		sel.selectByVisibleText("GERENTE_PRE_VIVO360");
		WebElement ele1 = driver.findElement(By
				.xpath("//select[@id='codigoCanalListBox']"));
		Select sel1 = new Select(ele1);
		sel1.selectByVisibleText("99937");
		Thread.sleep(8000);
		driver.findElement(By.xpath("//img[contains(@id,'changePerfilImage')]"))
				.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//input[@class='portalLojaHeaderListBox' and @id ='_mask_1']")).sendKeys("11996856330");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@id='buscarButton']")).click();
		Thread.sleep(20000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("MAIN_TAB_RESUMO_CLIENTE.window");
		driver.findElement(By.xpath("//*[@id='_consultaclientedynatabs_idtabdetalhes']/tbody/tr/td[2]/table/tbody/tr/td/div")).click();
		Thread.sleep(20000);
		driver.switchTo().frame("idTabDetalhes.window");
		driver.findElement(By.xpath("//*[@id='alterarDadosGeraisButton']")).click();
	    Thread.sleep(5000);
	    driver.findElement(By.xpath("//*[@id='gwt-uid-1']")).click();
		// TODO Auto-generated method stub
		

	}

}
