package com.google.pack;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class VivoPassFail {
	static WebDriver driver;
	public static String status = "failed";

	public static void main(String[] args) throws InterruptedException {
		int i = 8;

		System.setProperty("webdriver.chrome.driver",
				"D:\\Jagdeep\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://vivo360-preprod-qa.redecorp.br/vivo360/pages/crux/login/login.html");
		Thread.sleep(5000);
		driver.findElement(By.id("usuarioTextBox")).sendKeys("c_qneto"); // c_lpinho
		driver.findElement(By.id("senhaTextBox")).sendKeys("jogador252"); // Vivo@15
		driver.findElement(By.id("loginButton")).click();
		Thread.sleep(8000);
		driver.switchTo().frame(1);
		WebElement ele2 = driver.findElement(By
				.xpath("//button[@id='continuarButton']"));
		// button[contains(@id,'continuarButton'
		ele2.click();
		// clickElementByJS(driver, ele2);
		driver.navigate().refresh();
		Thread.sleep(15000);
		WebElement ele = driver.findElement(By
				.xpath("//select[@id='grupoListBox']"));
		Select sel = new Select(ele);
		sel.selectByVisibleText("GERENTE_PRE_VIVO360");
		WebElement ele1 = driver.findElement(By
				.xpath("//select[@id='codigoCanalListBox']"));
		Select sel1 = new Select(ele1);
		sel1.selectByVisibleText("99937");
		Thread.sleep(8000);
		driver.findElement(By.xpath("//img[contains(@id,'changePerfilImage')]"))
				.click();
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		Thread.sleep(8000);
		driver.findElement(
				By.xpath("//input[@class='portalLojaHeaderListBox' and @id ='_mask_1']"))
				.sendKeys("11999209854");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@id='buscarButton']")).click();
		Thread.sleep(20000);
		if (i > 0) {
			{
				WebElement table = driver.findElement(By
						.xpath("/html/body/div[4]/div/table"));
				WebElement table1 = table.findElement(By.tagName("table"));
				String actualTitle = table1
						.findElement(
								By.xpath("//div[contains(text(),'nenhum registro correspondente')]"))
						.getText();
				System.out.println("Title is" + actualTitle);
				if (actualTitle
						.equalsIgnoreCase("N�o foi poss�vel localizar nenhum registro correspondente ao crit�rio de pesquisa informado.")) {
					// String status = failed;
					System.out.println(status);
					table1.findElement(
							By.xpath("//button[@id='_crux_msgbox_ok_n_o_foi_poss_vel_localizar_nenhum_registro_correspondente_ao_crit_rio_de_pesquisa_in']"))
							.click();

				} else {

					System.out.println("Passed");
				}
			}
			System.out.println("We came out of loop sucessfully");

		}
		// driver.switchTo().frame("lojas");
		// List<WebElement> size = driver.findElements(By.tagName("table"));
		// System.out.println(size.size());

	}

}
