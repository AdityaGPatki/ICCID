package com.google.pack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadProper {
	public static WebDriver driver;
	public static Properties prop; // global variable

	public ReadProper() throws IOException {
		Properties prop = new Properties();
		FileInputStream ip = new FileInputStream(
				"D:/Selenium work/FirstSelenium/src/com/google/pack/configProperties");
		prop.load(ip);

	}

	public static void LaunchBrowser() {
		String browserValue = prop.getProperty("browser");

		if (browserValue.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"D:\\Jagdeep\\Selenium\\chromedriver.exe");
			driver = new ChromeDriver();

		} else {
			System.out.println("Please enter a browser value");
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

	}

}
