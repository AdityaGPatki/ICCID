package com.google.pack;

public class Jjava {

 

	public int salary() {
		int jaggisalary = 4000 + 2000 + 1200 + 1800;
	//	System.out.println(jaggisalary);
		return jaggisalary;

	}

	public static void main(String[] args) {
		int a = 12+165+10+20;
		int c = 9, b = 12;
		int y;
		Jjava x = new Jjava();

		y = x.salary();

		System.out.println( b + c +a);// doubt

		// TODO Auto-generated method stub

	}

}
