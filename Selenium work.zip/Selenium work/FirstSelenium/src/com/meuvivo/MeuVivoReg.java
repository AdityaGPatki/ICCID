package com.meuvivo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MeuVivoReg {
   static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		/*System.setProperty("webdriver.chrome.driver","D:\\Jagdeep\\Selenium\\chromedriver.exe");
		driver = new ChromeDriver();

		//driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Thread.sleep(3000);
		String OTP = driver.findElement(By.xpath("//label[contains(text(),'C�digo OTP')]")).getText();
		System.out.println(OTP);*/
		
		String x = "C�digo OTP: eu0brf";
		
	String y =x.split(": ")[1];
	
	System.out.println(y);
		
		
		

	}

}
