package com.DataDriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataProviderMultivivo {
	
	static int rowCount;

	public static ArrayList<Object[]> getClientFromExcel() throws IOException {
		ArrayList<Object[]> myData = new ArrayList<Object[]>();

		File src = new File("D:/Selenium work/FirstSelenium/src/OopsConcept/Atlys_Line.xlsx");

		FileInputStream fis = new FileInputStream(src);
		// FileOutputStream fos= new FileOutputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheet("Multivivo");

		DataFormatter formatter = new DataFormatter();

		rowCount = sheet1.getLastRowNum();
		System.out.println("Total rows are " + rowCount);

		// FileOutputStream fos= new FileOutputStream(src);
		// wb.write(fos);

		for (int i = 1; i <= rowCount; i++) {

			String CPF = formatter.formatCellValue(sheet1.getRow(i).getCell(0));
			String TYPE = formatter.formatCellValue(sheet1.getRow(i).getCell(1));
			String PRENOME = formatter.formatCellValue(sheet1.getRow(i).getCell(2));
			String SOBERNOME = formatter.formatCellValue(sheet1.getRow(i).getCell(3));
			String CSA = formatter.formatCellValue(sheet1.getRow(i).getCell(4));
			String PLAN = formatter.formatCellValue(sheet1.getRow(i).getCell(5));
			String PLAN_2 = formatter.formatCellValue(sheet1.getRow(i).getCell(6));
			String PLAN_TYPE = formatter.formatCellValue(sheet1.getRow(i).getCell(7));
			String ICCID = formatter.formatCellValue(sheet1.getRow(i).getCell(8));
			String ICCID_2 = formatter.formatCellValue(sheet1.getRow(i).getCell(9));
			String LINHA = formatter.formatCellValue(sheet1.getRow(i).getCell(10));
			// String PATH=
			// formatter.formatCellValue(sheet1.getRow(i).getCell(9));
			// x System.out.println(Linha);
			// String Type =
			// formatter.formatCellValue(sheet1.getRow(i).getCell(1));
			// Object ob[]={Username,Password,Linha};
			Object ob[] = { CPF, TYPE, PRENOME, SOBERNOME, CSA, PLAN,PLAN_2,PLAN_TYPE, ICCID,ICCID_2, LINHA };

			myData.add(ob);

		}
		fis.close();
		return myData;
	}

	public static String getPathFromExcel() throws IOException {

		File src = new File("D:/Selenium work/FirstSelenium/src/OopsConcept/Atlys_Line.xlsx");

		FileInputStream fis = new FileInputStream(src);
		// FileOutputStream fos= new FileOutputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheet("Path");

		DataFormatter formatter = new DataFormatter();

		rowCount = sheet1.getLastRowNum();
		System.out.println("Total rows are " + rowCount);

		// FileOutputStream fos= new FileOutputStream(src);
		// wb.write(fos);

		String PATH = formatter.formatCellValue(sheet1.getRow(1).getCell(0));

		fis.close();
		return PATH;
	}

	public static void writeDataInExcel1(String Linha,String Conta, int i)
			throws IOException {

		File src = new File("D:/Selenium work/FirstSelenium/src/OopsConcept/Atlys_Line.xlsx");
		FileInputStream fis = new FileInputStream(src);
		// FileOutputStream fos= new FileOutputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheet("Multivivo");

		// DataFormatter formatter = new DataFormatter();

		rowCount = sheet1.getLastRowNum();
		// fis.close();

		sheet1.getRow(0).createCell(11).setCellValue("TITULAR");
        sheet1.getRow(0).createCell(12).setCellValue("Conta_T");
        
        //sheet1.getRow(0).createCell(14).setCellValue("Conta_D");
		FileOutputStream fos = new FileOutputStream(src);
		// wb.write(fos);

		for (i = i; i <= rowCount; i++) {
			if (sheet1.getRow(i).createCell(13).getCellType() == CellType.BLANK) {
				sheet1.getRow(i).createCell(11).setCellValue(Linha);
				sheet1.getRow(i).createCell(12).setCellValue(Conta);
			
				break;
			}

			//
		}

		wb.write(fos);
		fos.close();
		return;

	}
	
	public static void writeDependent(String Linha_2, int i)throws IOException {

		File src = new File("D:/Selenium work/FirstSelenium/src/OopsConcept/Atlys_Line.xlsx");
		FileInputStream fis = new FileInputStream(src);
		// FileOutputStream fos= new FileOutputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheet("Multivivo");

		// DataFormatter formatter = new DataFormatter();

		rowCount = sheet1.getLastRowNum();
		// fis.close();

		
        sheet1.getRow(0).createCell(13).setCellValue("DEPENDENTE");
        //sheet1.getRow(0).createCell(14).setCellValue("Conta_D");
		FileOutputStream fos = new FileOutputStream(src);
		// wb.write(fos);

		for (i = i; i <= rowCount; i++) {
			if (sheet1.getRow(i).createCell(13).getCellType() == CellType.BLANK) {
				//sheet1.getRow(i).createCell(11).setCellValue(Linha);
			//	sheet1.getRow(i).createCell(12).setCellValue(Conta);
				sheet1.getRow(i).createCell(13).setCellValue(Linha_2);
				break;
			}

			//
		}

		wb.write(fos);
		fos.close();
		return;

	}


}
