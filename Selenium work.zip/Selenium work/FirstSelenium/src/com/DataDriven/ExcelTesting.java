package com.DataDriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class ExcelTesting {
	static int rowCount;
	static Screen s = new Screen();
	public static void main(String[] args) throws IOException, FindFailed {
		// TODO Auto-generated method stub
		Pattern reftipo = new Pattern("D:\\LearnSelenium\\Atlys\\reftipo.png");
 		s.wait(reftipo.similar((float) 0.80), 30);
 		Region fatura = s.find(reftipo).offset(60, 30);
 		// fatura.highlight(1);
 		fatura.doubleClick();
 		s.type("SERVICOS EVENTUAIS");
 		s.type(Key.DOWN);
 		s.type(Key.DOWN);
 		s.type(Key.TAB);
 		s.type("BLOQ-INTERNACIONAL");
 		s.type(Key.TAB);
 		s.type(Key.TAB);
 		s.type(Key.ENTER);
		
}}
