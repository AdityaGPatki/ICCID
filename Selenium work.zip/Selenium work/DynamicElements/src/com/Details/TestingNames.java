package com.Details;

import io.codearte.jfairy.Fairy;
import io.codearte.jfairy.producer.BaseProducer;
import io.codearte.jfairy.producer.person.Person;

import java.util.ArrayList;
import java.util.List;

public class TestingNames {
public static int i;
	public static List<String> generateStories(){
	    Fairy fairy = Fairy.create();
	   Person person =fairy.person();
	   // BaseProducer baseProducer = fairy.baseProducer();
	    List<String> stories = new ArrayList<>();
	    BaseProducer baseProducer = fairy.baseProducer();
	    for( i=1; i<=baseProducer.randomBetween(1, 50); i++){
	        stories.add(person.getFullName());
	     //   stories.add(person.getNationalIdentificationNumber());
	    }

	    return stories;
	}
	
	public static void main(String[] args){
		List<String> testData =	TestingNames.generateStories();
		
		System.out.println(testData);
		System.out.println(testData.get(i));
		
	}

}
