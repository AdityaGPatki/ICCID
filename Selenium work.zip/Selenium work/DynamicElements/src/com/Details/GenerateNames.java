package com.Details;

import io.codearte.jfairy.Fairy;
import io.codearte.jfairy.producer.person.Person;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;



public class GenerateNames {
	public static Fairy fairy = Fairy.create(Locale.forLanguageTag("pl"));
	public static Person person =fairy.person();
	public static String out;
public static List<String> genratenames(){
	List<String> names = new ArrayList<String>();
	//List<String> names = Arrays.asList(person.getFirstName());
	 int i =10;
	 for( i=0; i<12; i++){
		 
		 names.add(person.getFirstName());
		 names.add(person.getLastName());
	     //   names.get(i);
	//	 String firstname =	person.getFirstName();
	//		String lastname =	person.getLastName();
			//String cpf =	person.getNationalIdentificationNumber().toString();
			//	
			//Object ob[] = { firstname, lastname};
			//myData.add(ob);
	//		System.out.println(firstname +" "+ lastname);
	 }
		
	return names;
		
	}
public static void main(String[] args) {
	List<String> testData=GenerateNames.genratenames();
	System.out.println(testData);
	

	

	// TODO Auto-generated method stub

}


}
