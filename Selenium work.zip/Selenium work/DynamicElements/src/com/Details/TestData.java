package com.Details;

import java.util.Locale;
import java.util.Random;

import com.arakelian.faker.model.Person;
import com.arakelian.faker.service.RandomPerson;
import com.github.javafaker.Faker;


public class TestData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Faker faker = new Faker(new Locale("hi_IN"));
		
		String Firstname = faker.name().firstName();
		String Lastname = faker.name().lastName();
		
	//	System.out.println(Firstname +"  "+ Lastname);
		 
		//String cpf = faker.idNumber().ssnValid();
	
	   for(int i=1; i<20;i++){
		   String number =	faker.number().digits(6);
		//   String number1 =	faker.phoneNumber().phoneNumber();
		   System.out.println("11999"+number);
		//   System.out.println(number1);
			}
		
		//System.out.println(cpf);
		
	}
	
	

	

}
