package com.Details;



import java.util.Locale;

import io.codearte.jfairy.Fairy;
import io.codearte.jfairy.producer.BaseProducer;
import io.codearte.jfairy.producer.DateProducer;
import io.codearte.jfairy.producer.person.Person;

public class ClientDetails {

	public static void main(String[] args) {
	//	Fairy fairy = Fairy.create(Locale.forLanguageTag("en"));
	//Fairy fairy = Fairy.create();
	//Fairy fairy = Fairy.create(Locale.forLanguageTag("en"));
		Fairy fairy = Fairy.create(Locale.forLanguageTag("pl"));
		Person person =fairy.person();
		 DateProducer dp = fairy.dateProducer();
         BaseProducer bp = fairy.baseProducer();
         
	//String firstname =	person.getFirstName();
	//String lastname =	person.getLastName();
	//String cpf =	person.getNationalIdentificationNumber().toString();
	//String cpo = person.getNationalIdentityCardNumber();
		for(int i=1; i<20;i++){
		String number = person.getTelephoneNumber().substring(7);
		System.out.println("1199505"+number);
		}
	//System.out.println(firstname +"  "+ lastname);
//	System.out.println(cpf);
	
		// TODO Auto-generated method stub

	}

}
