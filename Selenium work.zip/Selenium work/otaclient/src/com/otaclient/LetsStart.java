package com.otaclient;

import com.hp.alm.otaclient.ClassFactory;
import com.hp.alm.otaclient.ITDConnection;

public class LetsStart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String url="http://10.28.33.45/qcbin/start_a.jsp";
	    String domain="QA_QA";
	    String project="2019_REGRESSAO_V2";
	    String username="ft.techmahindra.gkaur";
	    String password="qa1010";
	    
	    try{
	        ITDConnection itd=ClassFactory.createTDConnection();
	        itd.initConnectionEx(url);
	        System.out.println("Test1:"+ itd.connected());

	        itd.connectProjectEx(domain,project,username,password);

	        System.out.println(itd.connected());
	    }catch(Exception e){

	        e.printStackTrace();
	    }
	}

	}


