package com.AddLines;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;



public class AddLinesToPool {
	public static String strURL = "http://10.129.177.185:8086/xml/";
	
	@DataProvider
			public Iterator<Object[]> getTestData() throws IOException {
				
				ArrayList<Object[]> testData =DataDriven.getLineFromExcel();
				return testData.iterator();
			}
		@Test(dataProvider = "getTestData")
		public void AddingLines(String Linha) throws ParserConfigurationException, SAXException, IOException, TransformerException{
			
			Library.ModifyXML(Linha); //This will append line numbers in text file
			
			
			
			
		}
	//	 @Parameters({"in"})
		@AfterTest
		public void teardown() throws IOException{
			
			

			Library.readfile(); // File will be loaded in Memory
		//	Library.readXMLRPCResponse(in);// Response will be read here.
			
			Library.PostXML(); // Request will be sent over http server
			
			
			
			
		}
		

}
