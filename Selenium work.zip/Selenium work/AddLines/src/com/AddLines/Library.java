package com.AddLines;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class Library {
	public static String filepath = "D:\\Selenium work\\AddLines\\src\\com\\AddLines\\AddLines.txt";
	public static String strURL = "http://10.129.177.185:8086/xml/";
	public static String readfile() throws IOException{
		FileReader fr = new FileReader(filepath);
		  
		  
		  BufferedReader br= new BufferedReader(fr);
		try{  
		  StringBuilder sb = new StringBuilder();
	        String line = br.readLine();
	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        
	        return sb.toString();
	} finally{
		br.close();
		
	}}

	
	  public static String readXMLRPCResponse(InputStream in) throws IOException, NumberFormatException,
			   StringIndexOutOfBoundsException {

			    StringBuffer sb = new StringBuffer();
			    Reader reader = new InputStreamReader(in, "UTF-8");
			    int c;
			    while ((c = in.read()) != -1) sb.append((char) c);

			    String document = sb.toString();
			    String startTag = "<envelope>";
			    String endTag = "</envelope>";
			   
			    int start = document.indexOf(startTag) + startTag.length();
			    int end = document.indexOf(endTag);
			    String result = document.substring(start, end);
			    return new String(result);
	  }

	  public static void PostXML() throws IOException{
		    String y = Library.readfile();
			 URL obj = new URL(strURL);
			 //opening connection
			  HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			  //setting request
			  postConnection.setRequestMethod("POST");
			 postConnection.setRequestProperty("Content-Type", "application/xml");
			  postConnection.setDoOutput(true);
			  postConnection.setDoInput(true);
			  OutputStream os = postConnection.getOutputStream();
			  //setting request
			  os.write(y.getBytes());
			    os.flush();
			    os.close();
			    //Get response code
			    int responseCode = postConnection.getResponseCode();
			
			    System.out.println("POST Response Code :  " + responseCode);
			    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
			    InputStream in = postConnection.getInputStream();
			      String result = readXMLRPCResponse(in);
			//      System.out.println(result);
			      DataDriven.writeDataInNotePad(result);
			 
			      in.close();
			      postConnection.disconnect();
		  
	  }

	  public static void ModifyXML(String Linha) throws ParserConfigurationException, SAXException, IOException, TransformerException{
		  
		  DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			doc.setXmlVersion("1.0");
			Node number =  doc.getElementsByTagName("inputAddAccessNumber").item(0);
			
			Element Line = doc.createElement("addAcsNbrList");
			Attr acsNbr = doc.createAttribute("acsNbr");
			acsNbr.setValue(Linha);
			Attr nbrCatgry = doc.createAttribute("nbrCatgry");
			nbrCatgry.setValue("05");
			((Element) Line).setAttributeNode(acsNbr);
			((Element) Line).setAttributeNode(nbrCatgry);
		     number.appendChild(Line);

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new File(filepath));
				transformer.transform(source, result);
				
				System.out.println("Done");
	  }





}


