package com.domParser;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DomParser {
	public static String filepath = "D:/Work/DomParser/Postpaid_Titular.xml";
 /*public String filereader() throws ParserConfigurationException, SAXException, IOException{
	 
	 DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		
		Node n = doc.getFirstChild();
		Node record = doc.getElementsByTagName("record").item(0);
		NodeList list = record.getChildNodes();
	return list.toString();
	 
 }*/
 
 public static void main (String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException, TransformerException{
	 
	// DomParser dp =new DomParser();
	 DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		doc.setXmlVersion("1.0");
		XPathFactory xpf = XPathFactory.newInstance();
        XPath xpath = xpf.newXPath();
		Node n = doc.getFirstChild();
		Node record = doc.getElementsByTagName("record").item(0);
		//NodeList list = record.getChildNodes();
	NodeList list = (NodeList) xpath.evaluate("/request/record/field", doc, XPathConstants.NODESET);
		System.out.println(list.getLength());
		//for(int i=0; i<=list.getLength();i++){
			Node node = list.item(0);
			//System.out.println(node.getNodeName());
			//System.out.println(node.getNodeType());
			System.out.println(((Element) node).getAttribute("name"));
			System.out.println(((Element) node).getAttribute("value"));
			System.out.println("---------------");
			//System.out.println(node.getNamespaceURI());
			
			Node field = doc.getElementsByTagName("field").item(0);
			Element e = (Element)field;
			String name = e.getAttribute("value");
			System.out.println(name);
			e.setAttribute("value", "8950578825");
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);
			
			System.out.println("Done");

			
			

	 
 }

}
