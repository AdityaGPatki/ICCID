package com.domParser;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Soap {
  public static String filepath ="D:/Work/DomParser/Soap.xml";
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException, TransformerException {
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		//doc.setXmlVersion("1.0");
		XPathFactory xpf = XPathFactory.newInstance();
        XPath xpath = xpf.newXPath();
	//	Node n = doc.getFirstChild();
        
		Node cellnumber = doc.getElementsByTagName("ngin:inCellNumber").item(0);
		String x = cellnumber.getTextContent();
		System.out.println(x);
		cellnumber.setTextContent("7015667532");
		
		
		Node iccid = doc.getElementsByTagName("ngin:inICCID").item(0);
		String iccid1 = iccid.getTextContent();
		System.out.println(iccid1);
		iccid.setTextContent("89551010102000521599");
		
		Node imsi = doc.getElementsByTagName("ngin:inIMSI").item(0);
		String imsival = imsi.getTextContent();
		System.out.println(imsival);
		imsi.setTextContent("77777010102000521599");
		
		Node operation = doc.getElementsByTagName("ngin:inOperation").item(0);
		String opn = operation.getTextContent();
		System.out.println(opn);
		operation.setTextContent("0");
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);
		System.out.println("Roger");
		/*NodeList list = (NodeList) xpath.evaluate("/soapenv/ngin:inCellNumber", doc, XPathConstants.NODESET);
		System.out.println(list.getLength());
		Node node = list.item(0);
		
		NodeList list1 = record.getChildNodes();
		System.out.println(list1.getLength());
		//System.out.println(((Element) node).getAttribute("inCellNumber"));
	//	System.out.println(((Element) node).getAttribute("value"));
		System.out.println("---------------");
		*/
		/*Node field = doc.getElementsByTagName("field").item(0);
		Element e = (Element)field;
		String name = e.getAttribute("value");
		System.out.println(name);*/
	}

}
