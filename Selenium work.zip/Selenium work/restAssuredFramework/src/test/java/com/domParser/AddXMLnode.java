package com.domParser;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class AddXMLnode {
	public static String filepath = "C:\\Users\\js00570831\\Desktop\\Nova pasta\\AddLines.txt";
	
	
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerException {
		// TODO Auto-generated method stub
		 DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			doc.setXmlVersion("1.0");
			Node number =  doc.getElementsByTagName("inputAddAccessNumber").item(0);
		//	Element e = (Element)number;
		//	String name = e.getAttribute("acsNbr");
		//	System.out.println(name);
			/*Node Line = doc.createElement("addAcsNbrList");
			number.appendChild(Line);
			Attr acsNbr = doc.createAttribute("acsNbr");
			acsNbr.setValue("11999001511");
			Attr nbrCatgry = doc.createAttribute("nbrCatgry");
			nbrCatgry.setValue("05");
			((Element) Line).setAttributeNode(acsNbr);
			((Element) Line).setAttributeNode(nbrCatgry);*/
			Element Line = doc.createElement("addAcsNbrList");
			Attr acsNbr = doc.createAttribute("acsNbr");
			acsNbr.setValue("11999001511");
			Attr nbrCatgry = doc.createAttribute("nbrCatgry");
			nbrCatgry.setValue("05");
			((Element) Line).setAttributeNode(acsNbr);
			((Element) Line).setAttributeNode(nbrCatgry);
		     number.appendChild(Line);
			
			
			
			
			/*Element e1 = (Element)Line;
			Line.setAttribute("acsNbr", "11999001511");
			Line.setAttribute("nbrCatgry", "05");
			number.appendChild(Line);*/
			
			
		
			
			
		

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);
		
		System.out.println("Done");

	}

}
