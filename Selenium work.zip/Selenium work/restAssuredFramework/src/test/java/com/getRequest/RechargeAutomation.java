package com.getRequest;

public class RechargeAutomation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
		
		public void post(String url){

	}

}
