package com.getRequest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class TestingPostman {
	public static String strURL = "http://10.129.229.185:8090/rs/recharge/execute-event";
	public String readfile() throws IOException{
		FileReader fr = new FileReader("D:\\Selenium work\\restAssuredFramework\\src\\test\\java\\com\\getRequest\\sample.txt");
		  
		  
		  BufferedReader br= new BufferedReader(fr);
		try{  
		  StringBuilder sb = new StringBuilder();
	        String line = br.readLine();
	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        
	        return sb.toString();
	} finally{
		br.close();
		
	}}
	
	


	public static void main(String[] args) throws  IOException {
		// TODO Auto-generated method stub
		
		/*File file = new File("C:\\Users\\js00570831\\Desktop\\sample.xml");
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse(file);
		document.getDocumentElement().normalize();
		System.out.println(document.getDocumentElement().getNodeName());
*/
		 TestingPostman String = new TestingPostman();
		 
		 String y = String.readfile();
		 System.out.println(y);
		 URL obj = new URL(strURL);
		 //opening connection
		  HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
		  //setting request
		  postConnection.setRequestMethod("POST");
		  //Setting header
		  postConnection.setRequestProperty("X-QNT-Cid", "7060");
		  postConnection.setRequestProperty("X-QNT-Rqts", "2015-09-04T12:23:00.000-0300");
		  postConnection.setRequestProperty("X-QNT-Rqid", "20150904122300");
		  postConnection.setRequestProperty("Content-Type", "application/xml");
		  postConnection.setDoOutput(true);
		  OutputStream os = postConnection.getOutputStream();
		  //setting request
		  os.write(y.getBytes());
		    os.flush();
		//    os.close();
		    //Get response code
		    int responseCode = postConnection.getResponseCode();
		    System.out.println("POST Response Code :  " + responseCode);
		    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
		 
		  postConnection.disconnect();
		  System.out.println("Connection Disconnected");
		  
	       
		  
	}
	
	

}
