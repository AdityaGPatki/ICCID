package com.getRequest;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.httpclient.methods.PostMethod;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Postman {
	
	public static String strURL = "http://10.129.229.185:8090/rs/recharge/execute-event";
	public static String x;
	@Test
	public void testResponsecode() throws IOException
	{
		
		
		//PostMethod post = new PostMethod(strURL);
		
		 FileReader fr = new FileReader("C:\\Users\\js00570831\\Desktop\\sample.xml");
		  
		  
		  BufferedReader br= new BufferedReader(fr);
		  
		  
		  while((x=br.readLine()) != null) 
		  { 
			  System.out.println(x); 
				//post.setRequestBody(x);
			  
			  Postman_write(x);
			  
		  }
		  br.close();
		  System.out.println("XML code is "+ x);
	}
		  public void Postman_write(String x) throws IOException
		  {
		  URL obj = new URL(strURL);
		  HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
		  postConnection.setRequestMethod("POST");
		  postConnection.setRequestProperty("Content-Type", "application/xml");
		  postConnection.setDoOutput(true);
		  OutputStream os = postConnection.getOutputStream();
		  os.write(x.getBytes());
		    os.flush();
		    os.close();
		    int responseCode = postConnection.getResponseCode();
		    System.out.println("POST Response Code :  " + responseCode);
		    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
		  }
}
	/*
		 HttpClient httpclient = new HttpClient();

	        int result = httpclient.executeMethod(post);
	        System.out.println("Response status code: " + result);*/
	/*Response result =	RestAssured.get("http://10.129.229.185:8090/rs/recharge/execute-event");
	int code = result.getStatusCode();
	
	System.out.println("Status code is "+ code);
	
	Assert.assertEquals(code, 200);
	*/


