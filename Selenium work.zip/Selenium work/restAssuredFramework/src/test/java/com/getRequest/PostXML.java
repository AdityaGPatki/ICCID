package com.getRequest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostXML {
	
	public static String strURL = "http://10.129.177.185:8086/xml/";
	public static String readfile() throws IOException{
		FileReader fr = new FileReader("C:\\Users\\js00570831\\Desktop\\Nova pasta\\Line_Creation codes\\AddLines.txt");
		  
		  
		  BufferedReader br= new BufferedReader(fr);
		try{  
		  StringBuilder sb = new StringBuilder();
	        String line = br.readLine();
	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        
	        return sb.toString();
	} finally{
		br.close();
		
	}}
	
	
	  private static String readXMLRPCResponse(InputStream in) throws IOException, NumberFormatException,
			   StringIndexOutOfBoundsException {
		 
			    StringBuffer sb = new StringBuffer();
			    Reader reader = new InputStreamReader(in, "UTF-8");
			    int c;
			    while ((c = in.read()) != -1) sb.append((char) c);

			    String document = sb.toString();
			    String startTag = "<envelope>";
			    String endTag = "</envelope>";
			   
			    int start = document.indexOf(startTag) + startTag.length();
			    int end = document.indexOf(endTag);
			    String result = document.substring(start, end);
			    return new String(result);
	  }

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		PostXML String = new PostXML();
		
		String y = String.readfile();
		 System.out.println(y);
		 URL obj = new URL(strURL);
		 //opening connection
		  HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
		  //setting request
		  postConnection.setRequestMethod("POST");
		 postConnection.setRequestProperty("Content-Type", "application/xml");
		  postConnection.setDoOutput(true);
		  postConnection.setDoInput(true);
		  OutputStream os = postConnection.getOutputStream();
		  //setting request
		  os.write(y.getBytes());
		    os.flush();
		    os.close();
		    //Get response code
		    int responseCode = postConnection.getResponseCode();
		
		    System.out.println("POST Response Code :  " + responseCode);
		    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
		    InputStream in = postConnection.getInputStream();
		      String result = readXMLRPCResponse(in);
		      System.out.println(result);
		      PostXML.writeDataInNotePad(result);
		     in.close();
		      postConnection.disconnect();

	}
	
	public static void writeDataInNotePad(String result)throws IOException {

		FileWriter fr=new FileWriter("C:\\Users\\js00570831\\Desktop\\Nova pasta\\Result.txt");
		BufferedWriter br=new BufferedWriter(fr);

		br.write(result);
		br.newLine();
	

		br.close();
		return;

			//
		}
	

}
