package com.iccid;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class BuscarIccidDBConnection extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	// static String region;
	Statement smt;
	
	ArrayList<String> dataValue = new ArrayList<>();

	public BuscarIccidDBConnection() throws ClassNotFoundException, SQLException {
	    Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded...");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//10.129.179.49:1521/GSIMQA", "hml_vivo", "vivo2012");
		System.out.println("Connected....");
		smt = conn.createStatement();
	        
	}
      
	public ResultSet getBuscalccid(int regional_Name) throws SQLException {

		ResultSet resultsetIccid = smt.executeQuery("select ICCID,IMSI from GSIM.SIMCARD where status_code ='07'and ID_HLR=" + regional_Name +"");
		return resultsetIccid;
		
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}
	  
}


