package com.API;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import net.sf.expectit.Expect;
import net.sf.expectit.ExpectBuilder;
import net.sf.expectit.matcher.Matchers;



public class LineCreation {
	
	
	public static String strURL = "http://10.129.174.29:8004/generic_http_xml_interface/";
	public String readfile() throws IOException{
		FileReader fr = new FileReader("C:\\Users\\js00570831\\Desktop\\NGIN_Line.txt");
		  
		
		  BufferedReader br= new BufferedReader(fr);
		try{  
		  StringBuilder sb = new StringBuilder();
	        String line = br.readLine();
	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        
	        return sb.toString();
	} finally{
		br.close();
		
	}}
	
	public String readfile2() throws IOException {
		FileReader fr1 = new FileReader("C:\\Users\\js00570831\\Desktop\\NGIN_Line2.txt");
		  BufferedReader br1= new BufferedReader(fr1);
			try{  
			  StringBuilder sb1 = new StringBuilder();
		        String line1 = br1.readLine();
		        while (line1 != null) {
		            sb1.append(line1);
		            sb1.append("\n");
		            line1 = br1.readLine();
		        }
		        
		        return sb1.toString();
		} finally{
			br1.close();
			
		}
		
	}

	public static void main(String[] args) throws IOException, JSchException, InterruptedException {
		// TODO Auto-generated method stub
		LineCreation String = new LineCreation();
		 
		 String y = String.readfile();
		 System.out.println(y);
		 URL obj = new URL(strURL);
		 //opening connection
		  HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
		  //setting request
		  postConnection.setRequestMethod("POST");
		  postConnection.setRequestProperty("Content-Type", "text/xml");
		  postConnection.setDoInput(true);
		  postConnection.setDoOutput(true);
		 
		  
		  OutputStream os = postConnection.getOutputStream();
		  //setting request
		  os.write(y.getBytes());
		    os.flush();
		    os.close();
		    //Get response code
		    int responseCode = postConnection.getResponseCode();
		    System.out.println("POST Response Code :  " + responseCode);
		    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
		    
		    InputStream in = postConnection.getInputStream();
		    String result = readXMLRPCResponse(in);
		    System.out.println(result);
		    // I am doing changes from here
		    String y1 = String.readfile2();
			 System.out.println(y1);
			 postConnection.disconnect();
			  System.out.println("Connection Disconnected");
			  //open connection again
			  URL obj1 = new URL(strURL);
				 //opening connection
				  HttpURLConnection postConnection1 = (HttpURLConnection) obj1.openConnection();
			 System.out.println("connected again");
		    postConnection1.setRequestMethod("POST");
			  postConnection1.setRequestProperty("Content-Type", "text/xml");
			  postConnection1.setDoInput(true);
			  postConnection1.setDoOutput(true);
			  OutputStream os1 = postConnection1.getOutputStream();
			  //setting request
			  os1.write(y1.getBytes());
			    os1.flush();
			    os1.close();
			    //Get response code
			    int responseCode1 = postConnection1.getResponseCode();
			    System.out.println("POST Response Code :  " + responseCode1);
			    System.out.println("POST Response Message : " + postConnection1.getResponseMessage());
		    InputStream in1 = postConnection1.getInputStream();
		    String result1 = readXMLRPCResponse1(in1);
		    System.out.println(result1);
		 
		  postConnection1.disconnect();
		  System.out.println("Connection Disconnected");
		 
		  
		//  Activation();
		
		  

	}
	
	public static void Activation() throws JSchException, IOException, InterruptedException {
		
		JSch jsch = new JSch();
		String user = "techteste";
		String password = "Ready4All";
		String host = "10.129.180.233";
		int port =22;
		
		Session session = jsch.getSession(user, host, port);
		System.out.println("Session created");
		
		session.setPassword(password);
		session.setConfig("StrictHostKeyChecking", "no");
		session.connect();
		System.out.println("Connected");
		
		Channel channel = session.openChannel("shell");
		
		 Expect expect = new ExpectBuilder().withOutput(channel.getOutputStream())
         .withInputs(channel.getInputStream(), channel.getExtInputStream())
         .withEchoOutput(System.out)
         .withEchoInput(System.err)
 //        .withInputFilters(removeColors(), removeNonPrintable())
         .withExceptionOnFailure()
         .build();
		 
		// InputStream in = channel.getInputStream();
	//	 OutputStream out = channel.getOutputStream();
		 channel.connect();
		 expect.sendLine("ssh techteste@10.129.230.5");
		 Thread.sleep(2000);
		 expect.sendLine("sudo su - mediation");
		 System.out.println("Session Connected");
		 expect.sendLine("./consumo.sh");
		 expect.expect(Matchers.contains("ESCOLHA UMA"));
		 expect.sendLine("1");
		 
		 expect.expect(Matchers.contains("chamadas a serem processadas"));
		 expect.sendLine("1");
		
		 
		 expect.expect(Matchers.contains("Numero de A"));
		 expect.sendLine("11996019929");
		 
		 expect.expect(Matchers.contains("(Y,N)"));
		 expect.sendLine("N");

		 expect.expect(Matchers.contains("Numero de B"));
		 expect.sendLine("11995859022");
		 
		 expect.expect(Matchers.contains("tipo da chamada"));
		 expect.sendLine("1");
		
		 expect.expect(Matchers.contains("duracao"));
		 expect.sendLine("60");
		 Thread.sleep(2000);
		
		 expect.expect(Matchers.contains("Originador"));
		 expect.sendLine("11");
		 
		 expect.expect(Matchers.contains("EOT do"));
		 expect.sendLine("");
		 
		 expect.expect(Matchers.contains("utilizado"));
		 expect.sendLine("");
		 
		 System.out.println("Call successfull");
		 
		 expect.expect(Matchers.contains("PRE-PROD"));
		 
		 
		 channel.disconnect();
		 session.disconnect();
		 
		 
		 System.out.println("Channel Disconnected");
		
		
	}
	
	  public static String readXMLRPCResponse(InputStream in) throws IOException, NumberFormatException,
	   StringIndexOutOfBoundsException {

	    StringBuffer sb = new StringBuffer();
	    Reader reader = new InputStreamReader(in, "UTF-8");
	    int c;
	    while ((c = in.read()) != -1) sb.append((char) c);

	    String document = sb.toString();
	    String startTag = "<response>";
	    String endTag = "</response>";
	   
	    int start = document.indexOf(startTag) + startTag.length();
	    int end = document.indexOf(endTag);
	    String result = document.substring(start, end);
	    return new String(result);
}
	  
	  public static String readXMLRPCResponse1(InputStream in1) throws IOException {
		  StringBuffer sb1 = new StringBuffer();
		    Reader reader1 = new InputStreamReader(in1, "UTF-8");
		    int c1;
		    while ((c1 = in1.read()) != -1) sb1.append((char) c1);

		    String document1 = sb1.toString();
		    String startTag1 = "<response>";
		    String endTag1 = "</response>";
		   
		    int start1 = document1.indexOf(startTag1) + startTag1.length();
		    int end1 = document1.indexOf(endTag1);
		    String result1 = document1.substring(start1, end1);
		    return new String(result1);
	  }

}
