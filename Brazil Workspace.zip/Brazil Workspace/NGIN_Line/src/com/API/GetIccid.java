package com.API;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;



public class GetIccid {
	static int y=11;
	static int x;

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded");
			
		//Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.28.33.33:1521/pcdba", "adminprov2_10", "adminpro");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.129.229.178:1521/slrc", "cpm", "7aveiro");
		System.out.println("Connected");
		PreparedStatement smt= conn.prepareStatement("SELECT ICCID, IMSI FROM GSIM.SIMCARD@GSIM G WHERE 1=1 AND ID_HLR =" + y + " AND STATUS_CODE = '07' AND KIT_TYPE = 0 AND MSISDN = '000000000000' AND NOT EXISTS (SELECT IMSI FROM slr_clients S WHERE S.IMSI = G.IMSI) AND ROWNUM <= 1");
		ResultSet resultsetIccid = smt.executeQuery();
		
    ResultSetMetaData rsmd = resultsetIccid.getMetaData();
		
		int columnCount = rsmd.getColumnCount();
		
		System.out.println(columnCount);
		while(resultsetIccid.next()){
			for (int i = 1; i <=columnCount ; i++ ) {
				if (i > 1) 
				System.out.print("  ");
				String columnValue = resultsetIccid.getString(i);
				System.out.print(columnValue);
				//System.out.println(iccid.getString(i));
				//rsmd.getColumnName(i) + " "+
			}
			//i
      System.out.println("");
	}

		
	}

}
