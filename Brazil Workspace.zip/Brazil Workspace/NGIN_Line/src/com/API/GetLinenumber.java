package com.API;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class GetLinenumber {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Class.forName("oracle.jdbc.OracleDriver");
		System.out.println("Driver Loaded");
			
		//Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.28.33.33:1521/pcdba", "adminprov2_10", "adminpro");
		Connection conn = DriverManager.getConnection ("jdbc:oracle:thin:@//10.129.230.7:1521/pcdba", "adminprov2_10", "adminpro");
		System.out.println("Connected");
		PreparedStatement smt= conn.prepareStatement("SELECT a.msisdn FROM adminprov2_10.inv_nbr_pool a, adminprov2_10.inv_nbr_msisdn_status b where a.status_number = b.cod_status_msisdn and a.msisdn like '1199601%'and STATUS_NUMBER in ('0','3') and date_reserved is null and a.CATEGORY_MSISDN = 3 AND ROWNUM <=1");
		ResultSet resultsetLinenumber = smt.executeQuery();
		
    ResultSetMetaData rsmd = resultsetLinenumber.getMetaData();
		
		int columnCount = rsmd.getColumnCount();
		
		//System.out.println(columnCount);
		while(resultsetLinenumber.next()){
			for (int i = 1; i <=columnCount ; i++ ) {
				if (i > 1) 
				System.out.print("  ");
				String columnValue = resultsetLinenumber.getString(i);
				System.out.print(columnValue);
				//System.out.println(iccid.getString(i));
				//rsmd.getColumnName(i) + " "+
			}
			//i
      System.out.println("");
	}

	}

}
